# Backlog: Project Architect

Ideas, experiments, future features.

---

## v2.2.0 — Integrations

| Item | Priority | Effort | Notes |
|------|----------|--------|-------|
| GitHub repo sync | P1 | L | Push/pull YAML data to repo |
| Notion import | P2 | M | Parse Notion pages → modules |
| Google Docs import | P2 | M | Parse GDocs → modules |

---

## v2.3.0 — Extensions

| Item | Priority | Effort | Notes |
|------|----------|--------|-------|
| Template packs (industry-specific) | P2 | L | SaaS, E-commerce, Agency templates |
| Multi-language module support | P3 | M | Data in multiple languages |
| Export to Notion/Coda | P3 | M | Export project data to other tools |

---

## v2.4.0 — Advanced Features

| Item | Priority | Effort | Notes |
|------|----------|--------|-------|
| "Person as Project" mode | P2 | L | Personal brand skill |
| Virtual assistant mode | P3 | XL | Secretary-like project management |
| Auto-update reminders | P3 | M | "Your metrics are 30 days old" |
| Portfolio mode | P3 | L | Link multiple projects |

---

## v3.0.0 — AI-Native

| Item | Priority | Effort | Notes |
|------|----------|--------|-------|
| Embeddings for semantic search | P1 | XL | RAG-optimize the data |
| Auto-enrichment | P2 | XL | Background data collection |
| Anomaly detection | P3 | L | "Metrics dropped 30%" |
| Competitor monitoring | P3 | XL | Track competitor changes |

---

## Ideas Parking

| Idea | Source | Status |
|------|--------|--------|
| Content Formula integration | v2.1.0 research | Partially done (filters concept) |
| Investor CRM module | User request | Evaluate demand |
| Meeting notes → module updates | AI idea | Prototype needed |
| Voice input for updates | AI idea | Platform dependent |

---

## Experiments

| Experiment | Hypothesis | Status |
|------------|------------|--------|
| Haiku compatibility | Can Haiku follow SKILL.md? | To test |
| Generated skill size | Optimal number of modules for context | To measure |
| YAML vs JSON | User preference and error rates | YAML chosen |

---

## Declined

| Item | Reason |
|------|--------|
| Built-in document templates | Dynamic generation is better |
| Full business plan generation | Out of scope, use dedicated tools |
| Code architecture module | Different domain, separate skill |

---

*Last updated: 2025-12-01*
