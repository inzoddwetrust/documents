# CHANGELOG: skill-architect

All notable changes to Skill Architect.

Format: [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)

---

## [8.7.0] - 2025-12-12 "Lean Flow"

### Changed — MAJOR RESTRUCTURE

**Protocols reduced: 8 → 5**

| Old | New | Change |
|-----|-----|--------|
| P01-activation + P02-config | P01-init | Merged |
| P03-planning | P02-plan | Renumbered |
| P04-build + P05-validate | P03-build | Merged |
| P06-delivery + P07-closure | P04-deliver | Merged |
| P08-simulation | P05-simulation | Renumbered |
| P09-full-audit | P06-audit | Renumbered |

**Stops reduced: 4 → 2**
- Removed: between activation/config, build/validate, skill/docs delivery
- Kept: P02-plan (before work), P04-deliver (after delivery)

### Removed

| File | Reason |
|------|--------|
| P02-config.md | Merged into P01-init |
| P05-validate.md | Merged into P03-build |
| P07-closure.md | Merged into P04-deliver |

### Technical

- SKILL.md: 167 → 104 lines (-38%)
- Protocol files: 10 → 7 (-30%)
- Flow steps: 8 → 5 (-38%)
- Blocking points: 4 → 2 (-50%)

---

## [8.6.0] - 2025-12-12 "NEVER DEGRADE"

### Added
- **scripts/validate-degrade.sh v1.0**: Automated NEVER DEGRADE enforcement
  - PHASE 1: File deletion check
  - PHASE 2: Content volume check (>30% loss = violation)
  - PHASE 3: Key sections check
  - BLOCKING: Exit 1 stops delivery
- **P06**: ⛔ NEVER DEGRADE Check section (BLOCKING)
- **P07**: ⛔ NEVER DEGRADE Check — Docs section
- **P08**: Create PATCH Document step (when issues found)
- **generate-docs.sh v2.0**: Update mode with mandatory prev docs

### Changed
- **SKILL.md**: Rules 9-10 enforcement → validate-degrade.sh ⛔
- **SKILL.md**: Context Anchor simplified (removed 📋 line)
- **P04-build.md**: NEVER DEGRADE → reminder only (check moved to P06/P07)
- **All protocols**: Footer v8.4.0 → v8.6.0

### Fixed
- NEVER DEGRADE now has automated enforcement (was text-only)
- generate-docs.sh can't overwrite detailed docs with templates (requires prev docs for update)
- Footer version sync across all protocols

### Technical
- Source: PATCH-skill-architect-v8.6.0.md (from P08 simulation of v8.5.0)
- 12 scripts total (+1 validate-degrade.sh)
- ~6000 lines total

---

## [8.5.0] - 2025-12-12 "Docs Architect"

### Added
- **scripts/generate-docs.sh**: Auto-generate 7 versioned documents
- **scripts/validate-docs.sh v2.0**: Validate documentation naming convention
- **reference/docs-system.md**: Complete documentation system reference
- **quality-checklist.md**: L9 Documentation quality gate
- **docs/**: Version archive directory structure

### Changed
- **README.md** → **README-skill-architect.md** (naming convention)
- **CHANGELOG.md** → **CHANGELOG-skill-architect.md** (naming convention)
- **P07-closure.md**: Added documentation generation workflow
- **templates.md**: Added documentation naming section
- **SKILL.md**: Updated Lean Principle with 3-layer architecture

### Technical
- 47 files total (+2 new scripts, +1 reference)
- ~5800 lines total
- New naming: `{TYPE}-{skill-name}[-v{X.Y.Z}].md`

---

## [8.4.0] - 2025-12-12 "Golden Standard"

### Added
- **SKILL.md**: ⛔ PRE-BUILD CHECKPOINT section (context drift protection)
- **SKILL.md**: ⚠️ Common Mistakes table
- **SKILL.md**: Enhanced Context Anchor with rule reminder line
- **retrospective.md**: Evolution history from 18+ versions (from V1 docs)
- **All protocols**: Self-Check section before next protocol
- **P00-router.md**: Enhanced Recovery Protocol for context loss

### Changed
- **Context Anchor**: Now includes rule reminder `📋 SKILL.md=EN | README=[LANG] | <300 lines`
- **Blocking markers**: Visual enhancement `════ ⛔ BLOCKING ════`
- **templates.md**: Updated Context Anchor template with rule reminder
- **evaluations.md**: Added inline example output for E-001

### Fixed
- All footers synced to v8.4.0
- P01-activation version updated to v8.4.0

### Technical
- Base: V2 (v8.3.0 full version with 12 rules, L1-L8, all 5 principles)
- Added: V1 retrospective.md
- New: Context drift protection mechanisms
- 45 files total (+1 retrospective.md)
- ~5500 lines total

---

## [8.3.0] - 2025-12-12 "Restoration+"

### Added
- **diff-report.md**: Restored Diff Report format (was lost in v5→v8)
- **evaluations.md**: E-001 to E-008 test scenarios (was deleted)
- **update-version.sh**: Footer sync automation script
- **quality-checklist.md**: L8 Version Integrity layer
- **validate-skill.sh**: L8 Version Integrity check
- **P02-config.md**: "Questions to Ask" section
- **SKILL.md**: Quick Activation reference

### Fixed
- **P01-activation.md**: Active "Purpose?" prompt (was passive)
- **P04-build.md**: Restored Clean Skill Principle #3 "Chat = 2-4 sentences"
- **P06-delivery-skill.md**: Explicit reference to diff-report.md
- **SKILL.md**: Consolidated 12 Critical Rules in one table

### Restored (from v3.9.0-v4.1.0)
- Diff Report format with metrics table
- Active Purpose? question on activation
- Full 5 Clean Skill Principles
- evaluations.md with test scenarios

### Technical
- All footers synced to v8.3.0
- 44 files total (+3 new)
- ~5200 lines total

---

## [8.2.2] - 2025-12-12 "Package Guard"

### Added
- **packaging.md**: ⛔ BEFORE PACKAGING — MANDATORY section
- **packaging.md**: Post-packaging verify commands (file + unzip -t)
- **validate-skill.sh**: ZIP format validation (prevents tar+gzip mistake)
- **P06-delivery-skill.md**: Pre-packaging checklist

### Fixed
- Prevented "Invalid zip file" errors from tar+gzip usage
- Prevented wrong folder names (without version) in archives
- Prevented temp files (DIFF-REPORT) in .skill packages

### Technical
- validate-skill.sh v1.6 → v1.7
- packaging.md v2.0.0 → v2.1.0
- P06-delivery-skill.md v1.3.0 → v1.4.0

---

## [8.2.1] - 2025-12-11

### Added
- Frontmatter key validation in validate-skill.sh
- SSOT check script

### Fixed
- Version sync validation

---

## [8.2.0] - 2025-12-10 "Lean Core"

### Added
- L7 Knowledge Redundancy checks
- Aggressive pruning protocols
- Frontmatter validation

---

*CHANGELOG-skill-architect.md | skill-architect v8.7.0*
