# LOGIC-TREE: skill-architect v8.7.0

Business logic flow.

---

## Main Flow

```
[START]
    ↓
[STEP 1]
    ↓
[DECISION?] → YES → [ACTION A]
            → NO  → [ACTION B]
    ↓
[END]
```

---

## Blocking Points (⛔)

| Protocol | Gate | Requires |
|----------|------|----------|
| | | |

---

## Quality Gates

| Phase | Check |
|-------|-------|
| | |

---

*LOGIC-TREE-skill-architect-v8.7.0.md | skill-architect v8.7.0*
