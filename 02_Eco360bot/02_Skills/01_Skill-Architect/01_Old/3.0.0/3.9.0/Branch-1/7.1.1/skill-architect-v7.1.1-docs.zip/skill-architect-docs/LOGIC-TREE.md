# Logic Tree

Decision flow for skill-architect.

---

## Main Flow

```
[START]
    ↓
[P01: Activation]
    ↓
    ├─→ Read clean-protocol
    ├─→ Detect mode (Tool/Project)
    └─→ Show Standard Activation Menu
    ↓
[P02: Config]
    ↓
    ├─→ Gather requirements
    └─→ Confirm scope
    ↓
[P03: Planning] ⛔
    ↓
    ├─→ Create plan document
    ├─→ List changes
    └─→ Wait for confirmation
    ↓
[P04: Build]
    ↓
    ├─→ Execute plan
    └─→ Check NEVER DEGRADE
    ↓
[P05: Validate]
    ↓
    ├─→ [+vt] Virtual Testing
    ├─→ validate-skill.sh
    ├─→ validate-naming.sh
    ├─→ [+full] Deep Testing L4-L6
    └─→ Generate MANIFEST, DIFF
    ↓
[P06: Delivery — Skill] ⛔
    ↓
    ├─→ Package .skill
    ├─→ Provide download
    └─→ Wait for docs confirmation
    ↓
[P07: Delivery — Docs] ⛔
    ↓
    ├─→ Create 7 doc files
    └─→ Package docs.zip
    ↓
[P08: Scan]
    ↓
    └─→ Final summary
    ↓
[END]
```

---

## Decision Points

### D1: Mode Detection (P01)

| Condition | Result |
|-----------|--------|
| "project" in request | Project Mode |
| "skill" or default | Tool Mode |

### D2: Validation Flags (P05)

| Flag | Layers |
|------|--------|
| (none) | L1 + L3 |
| +vt | L0 + L1 + L3 |
| +full | L1 + L2 + L3 |
| +vt +full | All |

### D3: Docs Decision (P06)

| User says | Next |
|-----------|------|
| да/yes/docs | → P07 |
| skip/готово | → P08 |

---

## Blocking Points

| Protocol | Requires |
|----------|----------|
| P03 → P04 | Explicit "да/yes/go/делай" |
| P06 → P07 | Docs confirmation |
| P07 | Must create ALL 7 files |

---

## Response Structure

Every response ends with:

```
`skill-architect: file_read → P00-router.md`
🟢 ~[remaining] | ~[cost] 🟡
```

---

*LOGIC-TREE v1.1.0 | skill-architect v7.1.1*
