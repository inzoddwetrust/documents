# Backlog

Future improvements and known issues for skill-architect.

---

## Active

### v7.2.0 "Docs Reorder" — Next Release

| # | Task | Priority | Source |
|---|------|----------|--------|
| B-012 | Swap P07↔P08 (Scan before Docs) | High | v7.1.1 chat |
| B-013 | Flat numbered docs structure (8 files) | High | v7.1.1 chat |
| B-014 | Add 06-SCAN.md to docs | High | v7.1.1 chat |
| B-015 | Remove decisions/ subfolder | Medium | v7.1.1 chat |
| B-016 | Create validate-docs.sh | Medium | v7.1.1 chat |
| B-017 | Fix Context Anchor format (code block, not inline) | High | v7.1.1 chat |

### Backlog (no version assigned)

| # | Task | Priority | Source |
|---|------|----------|--------|
| B-001 | Auto-detect protocol from context | Medium | v6.2.0 |
| B-002 | Protocol execution logging | Low | v6.2.0 |
| B-003 | Template generator script | Low | v6.2.0 |
| B-004 | MANIFEST.md generation — add descriptions | Medium | v6.2.0 |

---

## Known Issues

| # | Issue | Severity | Workaround |
|---|-------|----------|------------|
| I-001 | validate-skill.sh warns on "." folder | Low | Use full path |
| I-002 | MANIFEST check looks for files without paths | Low | Cosmetic, ignore |

---

## Done

### v7.1.1

| # | Task | Implemented |
|---|------|-------------|
| B-010 | Dynamic token counter colors | templates.md, SKILL.md |
| B-011 | Context Anchor for recovery | templates.md, quality-checklist.md |
| FIX | P01 Standard Activation Response | P01-activation.md |

### v7.1.0

| # | Task | Implemented |
|---|------|-------------|
| B-007 | Geo-bias rule | templates.md, quality-checklist.md |
| B-008 | Token counter sync | 5 templates |
| B-009 | Standard Activation template | templates.md |

### v7.0.1

| # | Task | Implemented |
|---|------|-------------|
| B-005 | Footer version drift | All 21 files |
| B-006 | self-diagnostic.sh false negative | Pattern fixed |

### v7.0.0

| # | Task | Implemented |
|---|------|-------------|
| — | skill-tester integration | P05-validate |
| — | Virtual Testing engine | virtual-testing.md |

---

*BACKLOG v1.4.0 | skill-architect v7.1.1*
