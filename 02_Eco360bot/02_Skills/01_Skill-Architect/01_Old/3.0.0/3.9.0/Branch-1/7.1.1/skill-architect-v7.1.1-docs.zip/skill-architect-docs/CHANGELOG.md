# Changelog

All notable changes to skill-architect.

---

## [v7.1.1] - 2025-12-07

**Type:** PATCH — "Self-Heal"

### Added
- Context Anchor section in templates.md
- Dynamic Token Counter section in templates.md
- Context Anchor checks in quality-checklist.md
- Missing Context Anchor anti-pattern

### Changed
- P01-activation.md: Standard Activation Response (menu on startup)
- SKILL.md: Context Tracking with anchor + dynamic colors
- 5 templates: Context Tracking includes anchor
- Template Checklist: +2 items (anchor, counter)
- Quality checklist: +2 critical items

### Fixed
- skill-architect now uses its own activation template

---

## [v7.1.0] - 2025-12-07

**Type:** MINOR — "Standardization"

### Added
- Localization Rules section in templates.md (geo-bias prohibition)
- Standard Activation Response template in templates.md
- Geo-Bias anti-pattern in quality-checklist.md

### Changed
- Token counter format in 5 templates (sync with clean-protocol)
- All footer versions v7.0.1 → v7.1.0

---

## [v7.0.1] - 2025-12-05

**Type:** PATCH

### Fixed
- Footer version drift in 21 files
- self-diagnostic.sh false negative
- self-diagnostic.md SSOT sync

---

## [v7.0.0] - 2025-12-05

**Type:** MINOR — "Unified Ecosystem"

### Added
- Virtual Testing engine (+vt flag)
- Deep Testing (L4-L6, +full flag)
- 6 new reference files

### Changed
- P05-validate.md: Validation Layers architecture

### Absorbed
- skill-tester functionality merged into skill-architect

---

## [v6.2.0] - 2025-12-04

**Type:** PATCH — "Self-Compliance"

### Fixed
- Explicit FIRST STEP in SKILL.md
- Absolute paths in protocols
- Naming convention enforcement

---

*CHANGELOG v1.2.0 | skill-architect v7.1.1*
