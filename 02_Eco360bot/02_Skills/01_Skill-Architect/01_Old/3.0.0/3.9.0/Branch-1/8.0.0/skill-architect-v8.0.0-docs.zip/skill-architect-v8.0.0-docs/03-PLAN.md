# PLAN

## skill-architect v7.2.0 → v8.0.0 "Testing Evolution"

---

## Context

Self-audit session revealed:
- 58% genetic inheritance (parent genes not passed to children)
- Broken link in self-diagnostic after v7.2.0 refactor
- False positives in validation scripts
- 8 testing files could be consolidated to 4

---

## Goals

1. Fix all bugs from v7.2.0 refactor
2. Consolidate testing files (8 → 4)
3. Create Genetic Audit capability
4. Improve "eat your own dog food" compliance

---

## Scope

### In Scope
- Critical bug fixes (self-diagnostic, MANIFEST)
- Testing file consolidation
- New genetic-audit protocol and script
- Script improvements (smarter checks)
- DNA updates (quality-checklist)

### Out of Scope
- Project Mode changes
- New features beyond testing
- Breaking changes

---

## Phases

### Phase 1: Critical Fixes
- [x] Fix self-diagnostic.sh:164
- [x] Regenerate MANIFEST.md

### Phase 2: Create New
- [x] genetic-audit.md
- [x] genetic-audit.sh
- [x] testing-framework.md

### Phase 3: Consolidate
- [x] Merge personas, adversarial, expert-panel → virtual-testing.md
- [x] Merge test-levels, test-cases, evaluations → testing-framework.md
- [x] Remove old files

### Phase 4: Update Scripts
- [x] audit-skill.sh (Cyrillic, size threshold)
- [x] ssot-check.sh (SSOT Note)
- [x] self-diagnostic.sh (genetic link)

### Phase 5: Update Core
- [x] SKILL.md (Output, triggers)
- [x] quality-checklist.md (DNA rules)
- [x] P04-build.md (NEVER DEGRADE)

### Phase 6: Validate & Deliver
- [x] All scripts pass
- [x] Package .skill
- [x] Create docs

---

## Decisions Made

| Decision | Rationale |
|----------|-----------|
| Merge Plans A+B | Same files affected, single release |
| 250KB threshold | Modular architecture allows larger total |
| Keep protocol_first internal | Too complex for child skills |
| Modular file structure | ## sections = modules, efficient reading |

---

## Risks Mitigated

| Risk | Mitigation |
|------|------------|
| Content loss during merge | Careful diff review |
| Broken references | grep all mentions |
| Over-consolidation | Keep logical separation |

---

*03-PLAN.md v1.0.0 | skill-architect v8.0.0*
