# BACKLOG

## skill-architect v8.0.0

---

## Active

| ID | Item | Priority | Status |
|----|------|----------|--------|
| B-002 | Fix ssot-check.sh integer expression bug (lines 55, 58) | Medium | Open |
| B-003 | Add tips/warnings section to SKILL.md (BP 87% → 100%) | Low | Open |

---

## Ideas

| ID | Item | Priority | Notes |
|----|------|----------|-------|
| B-001 | Document protocol_first gene for complex children | Low | Maybe in templates.md |
| B-004 | Create full-audit.sh (single script for all checks) | Low | Convenience feature |
| B-005 | Add --fast/expert mode for blocking points bypass | Low | UX improvement for experts |
| B-006 | Automated VT scoring script | Low | Currently manual |
| B-007 | Integration tests for protocol flow | Low | E2E validation |

---

## Completed (v8.0.0)

| ID | Item | Completed |
|----|------|-----------|
| — | Fix self-diagnostic.sh P07 link | 2025-12-07 |
| — | Genetic Audit protocol + script | 2025-12-07 |
| — | Testing file consolidation | 2025-12-07 |
| — | Script improvements (audit, ssot) | 2025-12-07 |
| — | DNA updates (quality-checklist) | 2025-12-07 |
| — | NEVER DEGRADE checklist in P04 | 2025-12-07 |

---

## Rejected

| ID | Item | Reason |
|----|------|--------|
| — | Split engines.md into multiple files | Modular ## structure sufficient |
| — | Remove Cyrillic from examples | Cyrillic OK in examples for RU users |

---

*05-BACKLOG.md v1.0.0 | skill-architect v8.0.0*
