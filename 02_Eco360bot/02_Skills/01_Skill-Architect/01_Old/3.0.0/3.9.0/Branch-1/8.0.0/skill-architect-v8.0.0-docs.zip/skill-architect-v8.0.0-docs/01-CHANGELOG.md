# CHANGELOG

All notable changes to skill-architect.

---

## [8.0.0] "Testing Evolution" — 2025-12-07

### Added
- **Genetic Audit** — new protocol and script for inheritance verification
  - `reference/genetic-audit.md`
  - `scripts/genetic-audit.sh`
- **Testing Framework** — consolidated L1-L6, test-cases, evaluations
  - `reference/testing-framework.md`
- **Self-Audit Flow** — integrated diagnostic command
- `## Output` section in SKILL.md
- File Size & Structure Rules in quality-checklist
- Modular File Structure pattern
- SSOT Note pattern
- Update Safety rules (inherited from NEVER DEGRADE)

### Changed
- `virtual-testing.md` — integrated personas, adversarial, expert-panel
- `P04-build.md` — expanded NEVER DEGRADE checklist
- `audit-skill.sh` — smarter Cyrillic check (uses `\p{Cyrillic}`)
- `ssot-check.sh` — SSOT Note awareness
- Size threshold: 200KB → 250KB
- SKILL.md triggers: added `self-audit`, `genetic audit`

### Fixed
- `self-diagnostic.sh:164` — broken link P07-delivery-docs.md → P07-scan.md
- False positive Cyrillic detection in audit-skill.sh

### Removed (Merged)
- `test-levels.md` → testing-framework.md
- `test-cases.md` → testing-framework.md
- `evaluations.md` → testing-framework.md
- `personas.md` → virtual-testing.md
- `adversarial.md` → virtual-testing.md
- `expert-panel.md` → virtual-testing.md

### Metrics
| Metric | v7.2.0 | v8.0.0 |
|--------|--------|--------|
| Files | 45 | 39 |
| Scripts | 7 | 8 |
| Self-diagnostic | 35/36 | 36/36 |
| Best Practices | 75% | 87% |
| Genetic Inheritance | 58% | 87% |

---

## [7.2.0] "Docs Reorder" — 2025-12-01

### Changed
- P07↔P08 swap (Scan before Docs)
- Flat numbered docs structure
- Code block anchor format

---

## [7.1.0] — 2025-11-28

### Added
- Protocol-First architecture
- P00-P08 protocol chain
- Clean-protocol integration

---

*01-CHANGELOG.md v1.0.0 | skill-architect v8.0.0*
