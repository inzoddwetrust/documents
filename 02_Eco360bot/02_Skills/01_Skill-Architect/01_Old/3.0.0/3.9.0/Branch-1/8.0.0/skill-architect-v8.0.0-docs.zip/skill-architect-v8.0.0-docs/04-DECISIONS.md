# DECISIONS

Architectural Decision Records for skill-architect v8.0.0.

---

## ADR-001: Genetic Audit as Core Capability

**Status:** Accepted

**Context:**
Self-audit revealed skill-architect doesn't follow its own standards (58% inheritance). Need mechanism to verify parent-child gene transmission.

**Decision:**
Create dedicated protocol (genetic-audit.md) and script (genetic-audit.sh) for inheritance verification.

**Consequences:**
- (+) Can verify "eat your own dog food"
- (+) Quantifiable inheritance metric
- (-) Additional maintenance

---

## ADR-002: Testing File Consolidation (8 → 4)

**Status:** Accepted

**Context:**
8 separate testing files (personas, adversarial, expert-panel, test-levels, test-cases, evaluations, virtual-testing, self-diagnostic) were fragmented and hard to navigate.

**Decision:**
Consolidate to 4 files:
- testing-framework.md (L1-L6, test-cases, evaluations)
- virtual-testing.md (+ personas, adversarial, expert-panel)
- genetic-audit.md (new)
- self-diagnostic.md (unchanged)

**Consequences:**
- (+) Easier navigation
- (+) Logical grouping
- (+) Less duplication
- (-) Larger individual files (mitigated by ## modular structure)

---

## ADR-003: Modular File Structure Pattern

**Status:** Accepted

**Context:**
Audit flagged files >300 lines as issues. But splitting into many small files creates navigation overhead.

**Decision:**
Allow files up to 500 lines IF they have ## modular structure. Claude reads specific sections, not entire files.

**Consequences:**
- (+) Fewer files to manage
- (+) Efficient partial reading
- (-) Requires discipline in section organization

---

## ADR-004: Size Threshold 200KB → 250KB

**Status:** Accepted

**Context:**
skill-architect at 218KB was flagged as "too large" by its own audit. But modular architecture means Claude loads ~10-15KB per request, not full 218KB.

**Decision:**
Increase threshold to 250KB for skills with:
- SKILL.md < 300 lines (entry point small)
- reference/ with modular structure
- Progressive disclosure

**Consequences:**
- (+) Allows ecosystem skills like skill-architect
- (+) Aligns with actual usage patterns
- (-) May encourage bloat if abused

---

## ADR-005: SSOT Note Pattern

**Status:** Accepted

**Context:**
ssot-check.sh flagged `zip -r` appearing 13 times as violation. But some are examples in context, not duplication.

**Decision:**
Allow command examples outside commands.md IF marked with "SSOT Note" pointing to canonical source.

**Consequences:**
- (+) Examples stay in context
- (+) Clear source of truth
- (+) Scripts can distinguish violations from examples

---

## ADR-006: protocol_first Gene as Internal Only

**Status:** Accepted

**Context:**
Genetic audit shows protocol_first (P00-P08 architecture) not documented for children. Should it be inherited?

**Decision:**
Keep as internal only. Protocol-First is complex architecture suitable for ecosystem skills, not typical children.

**Consequences:**
- (+) Simpler child skill requirements
- (-) 87% inheritance instead of 100%
- (Note) Can recommend for complex skills in templates.md

---

*04-DECISIONS.md v1.0.0 | skill-architect v8.0.0*
