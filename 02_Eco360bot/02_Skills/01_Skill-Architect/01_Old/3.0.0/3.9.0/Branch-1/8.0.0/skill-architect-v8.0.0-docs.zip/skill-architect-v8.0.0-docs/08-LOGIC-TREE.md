# LOGIC TREE

## skill-architect v8.0.0 — Decision Flow

---

## Main Flow

```
USER INPUT
    │
    ▼
┌─────────────────────────────────┐
│ P00-ROUTER                      │
│ What type of request?           │
└─────────────────────────────────┘
    │
    ├─► "create skill" ──────► P01 → P02 → P03 → P04 → P05 → P06 → P07 → P08
    │
    ├─► "create project" ────► P01 → P02 → P03 → P04 → P05 → P06 → P07 → P08
    │
    ├─► "update" + file ─────► P02 → P03 → P04 → P05 → P06 → P07 → P08
    │
    ├─► "refactor" + file ───► P02 → P03 → P04 → P05 → P06 → P07 → P08
    │
    ├─► "self-audit" ────────► Run diagnostics → Report
    │
    ├─► "genetic audit" ─────► Run genetic-audit.sh → Report
    │
    └─► "validate +vt" ──────► P05 with VT flag → Report
```

---

## Protocol Chain

```
P01-activation
    │ Clarify purpose
    ▼
P02-config
    │ Determine mode, settings
    ▼
P03-planning ⛔
    │ Create plan, WAIT for confirmation
    │ "да/yes/go" required
    ▼
P04-build
    │ Implement changes
    │ Check NEVER DEGRADE
    ▼
P05-validate
    │ Run all validation scripts
    │ Optional: +vt, +full
    ▼
P06-delivery-skill ⛔
    │ Package .skill
    │ WAIT for confirmation
    ▼
P07-scan
    │ Scan chat for items
    │ Prepare backlog
    ▼
P08-docs-closure ⛔
    │ Create 8 doc files
    │ Final delivery
    ▼
END
```

---

## Testing Flow

```
self-audit / diagnose
    │
    ▼
┌─────────────────────────────────┐
│ 1. STRUCTURE                    │
│    validate-skill.sh            │
│    validate-naming.sh           │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ 2. GENETIC                      │
│    genetic-audit.sh             │
│    (inheritance check)          │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ 3. QUALITY                      │
│    audit-skill.sh               │
│    ssot-check.sh                │
└─────────────────────────────────┘
    │
    ▼ [if +vt flag]
┌─────────────────────────────────┐
│ 4. VIRTUAL TESTING              │
│    Personas → Adversarial →     │
│    Expert Panel → Score         │
└─────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────┐
│ 5. REPORT                       │
│    Consolidated findings        │
└─────────────────────────────────┘
```

---

## NEVER DEGRADE Check

```
Before ANY change:
    │
    ├─► Removes functionality? ──► ⛔ STOP
    │
    ├─► Less specific? ──────────► ⛔ STOP
    │
    ├─► Deleting without move? ──► ⛔ STOP
    │
    └─► Replacing vs adding? ────► ⚠️ Confirm with user
```

---

## Blocking Points

```
P03-planning:
    └─► Wait for "да/yes/go/делай"
        Invalid: "ок", "понял", "хорошо"

P06-delivery-skill:
    └─► Wait for confirmation before docs

P08-docs-closure:
    └─► Must create ALL 8 files
```

---

## Genetic Audit Flow

```
genetic-audit.sh
    │
    ├─► Extract Parent Genes
    │   (from SKILL.md, protocols)
    │
    ├─► Extract Child Requirements
    │   (from quality-checklist, templates)
    │
    ├─► Build Inheritance Matrix
    │
    ├─► Classify: ✅ Inherited / ❌ Lost / ⚠️ Mutation
    │
    └─► Report with percentage
```

---

## File Reading Pattern

```
SKILL.md (entry point, <300 lines)
    │
    └─► Protocol Router
        │
        └─► file_read P0X-name.md
            │
            └─► [if needed] file_read reference/specific.md
                │
                └─► Read specific ## section
```

---

*08-LOGIC-TREE.md v1.0.0 | skill-architect v8.0.0*
