# LOGIC-TREE: skill-architect v5.0.0

Пайплайн логики в формате numbered tree + mermaid визуализация.

---

## Numbered Tree (source of truth)

```
1. ACTIVATION
   1.1. Триггер: "create skill", "create project", "import project", "refactor"
   1.2. Загрузка: SKILL.md
   1.3. Init: token counter active
   1.4. → 2.

2. INIT (Quick Config)
   2.1. Проверка: purpose определён?
      2.1.1. НЕТ → Спросить: "Purpose? Triggers?"
      2.1.2. ДА → 2.2
   2.2. Определение MODE:                          ← NEW in v5.0.0
      2.2.1. "project" keyword → Project Mode
      2.2.2. Otherwise → Tool Mode
   2.3. Определение type: CREATE | UPDATE | REFACTOR | IMPORT
   2.4. Определение complexity: simple | standard | complex
   2.5. → 3.

3. RESEARCH
   3.1. IF type=UPDATE|REFACTOR:
      3.1.1. Snapshot: cp -r source /home/claude/skill-ORIGINAL
      3.1.2. IF REFACTOR: bash scripts/audit-skill.sh
      3.1.3. Анализ текущего состояния
   3.2. IF type=CREATE:
      3.2.1. Исследование домена (web_search если нужно)
      3.2.2. IF Tool Mode: reference/templates.md
      3.2.3. IF Project Mode: reference/project-mode.md
   3.3. IF type=IMPORT:                            ← NEW in v5.0.0
      3.3.1. Загрузка: reference/project-import.md
      3.3.2. Анализ документа (Phase 1)
      3.3.3. Определение stage
   3.4. → 4.

4. DESIGN
   4.1. IF Tool Mode:
      4.1.1. Загрузка: reference/templates.md
      4.1.2. Выбор шаблона по ключевым словам purpose
      4.1.3. IF complex: выбор движков из reference/engines.md
   4.2. IF Project Mode:                           ← NEW in v5.0.0
      4.2.1. Определение stage (idea/mvp/growth/scale)
      4.2.2. Загрузка: reference/project-modules.md
      4.2.3. Определение required modules для stage
   4.3. → 5.

5. PLAN (BLOCKING)
   5.1. Загрузка: reference/planning-document.md
   5.2. Создание Planning Document:
      5.2.1. Контекст (источники, цели)
      5.2.2. Constraints таблица (copy from template)
      5.2.3. Секция KEEP (что сохраняем)
      5.2.4. Секция REMOVE (что удаляем + причины)
      5.2.5. Секция ADD (что добавляем)
   5.3. Chat Verification:
      5.3.1. Сканирование всего разговора
      5.3.2. Список обсуждённых пунктов
      5.3.3. Проверка против плана
      5.3.4. Отчёт: "Verified: N items. Missing: [list]"
   5.4. Ожидание подтверждения
   5.5. → 6.

6. CONFIRM (BLOCKING)
   6.1. Представление плана пользователю
   6.2. Проверка ответа:
      6.2.1. Валидный ("да", "yes", "делай", "go", "proceed") → 7.
      6.2.2. Невалидный ("ок", "понял") → Переспросить
      6.2.3. Запрос изменений → 5.2
   6.3. → 7.

7. PRE-BUILD CHECKPOINT
   7.1. Верификация:
      7.1.1. □ SKILL.md = English only
      7.1.2. □ README.md = User's language
      7.1.3. □ SKILL.md < 300 lines
      7.1.4. □ Frontmatter: name + description (version in description)
      7.1.5. □ Plan confirmed with explicit confirmation
   7.2. IF любой пункт под вопросом → re-read SKILL.md
   7.3. → 8.

8. BUILD
   8.1. Создание структуры: mkdir /home/claude/skill-name/
   8.2. IF Tool Mode:
      8.2.1. Создание SKILL.md (English, <300 lines)
      8.2.2. Создание README.md (user language)
      8.2.3. Создание reference/ (если нужны)
      8.2.4. Создание scripts/ (если нужны)
   8.3. IF Project Mode:                           ← NEW in v5.0.0
      8.3.1. Создание SKILL.md (English, <300 lines)
      8.3.2. Создание README.md (user language)
      8.3.3. Создание data/ структуры
      8.3.4. Создание YAML модулей по stage
      8.3.5. IF IMPORT: заполнение из source document
   8.4. → 9.

9. VALIDATE
   9.1. Запуск: bash scripts/validate-skill.sh
   9.2. Запуск: bash scripts/validate-naming.sh    ← NEW in v5.0.0
   9.3. Проверка результатов:
      9.3.1. PASS → 9.4
      9.3.2. FAIL → Исправить → 9.1
   9.4. Генерация: bash scripts/generate-manifest.sh
   9.5. → 10.

10. DIFF REPORT (BLOCKING)
    10.1. Создание Diff Report:
       10.1.1. Метрики до/после
       10.1.2. Добавленное
       10.1.3. Удалённое + причины
       10.1.4. Сохранённое
    10.2. Ожидание подтверждения
    10.3. → 11.

11. DELIVER SKILL (Step 1)
    11.1. Упаковка: zip -r skill-name-vX.Y.Z.skill skill-name/
    11.2. Проверка: unzip -l (структура)
    11.3. Копирование в /mnt/user-data/outputs/
    11.4. Ссылка пользователю
    11.5. Ожидание: explicit confirmation → 12.

12. DELIVER DOCS (Step 2)
    12.1. Создание docs/:
       12.1.1. vX.Y.Z-PLAN.md
       12.1.2. vX.Y.Z-DIFF.md
       12.1.3. CHANGELOG.md (append)
       12.1.4. BACKLOG.md (update)
       12.1.5. README.md (full docs RU)
       12.1.6. LOGIC-TREE.md (if changed)
       12.1.7. decisions/vX.Y.Z-decisions.md
       12.1.8. development-guide.md (if relevant)  ← NEW in v5.0.0
    12.2. Упаковка: zip -r skill-name-vX.Y.Z-docs.zip docs/
    12.3. Ссылка пользователю
    12.4. Ожидание: explicit confirmation → 13.

13. FINAL SCAN (Step 3)
    13.1. Полный скан чата
    13.2. Сверка: обсуждали vs сделали
    13.3. IF упущено:
       13.3.1. Добавить в BACKLOG
       13.3.2. Перепаковать docs.zip
    13.4. Отчёт пользователю
    13.5. → END

14. PER-RESPONSE (на каждом ответе)
    14.1. Token counter в конце: 🟡 -[cost] | ~[remaining] 🟢
```

---

## Mermaid (визуализация)

```mermaid
flowchart TD
    A[1. ACTIVATION] --> B[2. INIT]
    B --> |unclear| B1[Ask: Purpose?]
    B1 --> B
    B --> |clear| B2{Mode?}
    
    B2 --> |Tool| C1[3. RESEARCH Tool]
    B2 --> |Project| C2[3. RESEARCH Project]
    
    C1 --> D1[4. DESIGN Tool]
    C2 --> D2[4. DESIGN Project]
    
    D1 --> E[5. PLAN]
    D2 --> E
    
    E --> F{6. CONFIRM}
    F --> |invalid| F1[Ask Again]
    F1 --> F
    F --> |changes| E
    F --> |confirmed| G[7. PRE-BUILD CHECK]
    
    G --> |verify failed| G1[Re-read]
    G1 --> G
    G --> |verified| H{8. BUILD}
    
    H --> |Tool| H1[reference/]
    H --> |Project| H2[data/]
    
    H1 --> I[9. VALIDATE]
    H2 --> I
    
    I --> |fail| I1[Fix]
    I1 --> I
    I --> |pass| J[10. DIFF REPORT]
    
    J --> K{11. SKILL}
    K --> |confirm| L{12. DOCS}
    L --> |confirm| M[13. SCAN]
    M --> |missing| M1[BACKLOG]
    M1 --> M2[Repack]
    M2 --> N((END))
    M --> |complete| N
```

---

## Mode Detection (NEW in v5.0.0)

```
User Input Analysis:
├── Contains "project" → Project Mode
│   ├── "create project: X" → CREATE
│   ├── "import project" → IMPORT
│   └── "update module" → UPDATE (inside project)
└── Otherwise → Tool Mode
    ├── "create skill: X" → CREATE
    ├── "update: X" → UPDATE
    └── "refactor" → REFACTOR
```

---

## 3-Step Delivery

```
┌─────────────────────────────────────────────────────┐
│  STEP 1: SKILL                                      │
│  → Package .skill → Link → Wait explicit confirm    │
├─────────────────────────────────────────────────────┤
│  STEP 2: DOCS                                       │
│  → Package docs.zip → Link → Wait explicit confirm  │
├─────────────────────────────────────────────────────┤
│  STEP 3: FINAL SCAN                                 │
│  → Scan chat → Compare → BACKLOG → Repack if needed │
└─────────────────────────────────────────────────────┘
```

---

## Diff: v4.1.0 → v5.0.0

### Добавлено
- 2.2: Mode detection (Tool vs Project)
- 3.3: IMPORT type handling
- 4.2: Project Mode design
- 8.3: Project Mode build (data/)
- 9.2: validate-naming.sh
- 12.1.8: development-guide.md

### Изменено
- 2.3: +IMPORT type
- 3.2: Split by mode
- 4: Split by mode

### Удалено
- Ничего

---

*LOGIC-TREE v1.2.0 | skill-architect v5.0.0 | 2025-12-01*
