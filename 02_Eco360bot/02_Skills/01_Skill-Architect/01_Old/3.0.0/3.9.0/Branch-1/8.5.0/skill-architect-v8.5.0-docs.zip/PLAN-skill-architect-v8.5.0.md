# PLAN: skill-architect v8.4.0 → v8.5.0 "Docs Architect"

**Date:** 2025-12-12  
**Context:** Self-audit v8.4.0 выявил проблемы с документацией, naming conventions  
**Sources:** recursive checkup, docs audit (85/100)

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | User's language (RU) |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

### Почему v8.5.0?

Self-audit v8.4.0 выявил:
- **README.md** устарел (показывает v8.2.1 вместо v8.4.0)
- **Нет naming convention** для документов
- **Нет версионного архива** (docs теряются между версиями)
- **08-LOGIC-TREE** и другие docs не версионированы

### Цель v8.5.0 "Docs Architect"

Создать **систему документации**:
1. Naming convention для всех docs
2. Версионный архив docs/vX.Y.Z/
3. Автоматизация через generate-docs.sh
4. Валидация через validate-docs.sh v2.0
5. L9 quality gate для документации

---

## 2. Проблемы / Задачи

### 🔴 Критические

| # | Проблема | Impact |
|---|----------|--------|
| P-001 | README.md показывает v8.2.1 | User confusion |
| P-002 | Нет naming convention | Multi-skill confusion |
| P-003 | Docs теряются между версиями | History loss |

### 🟡 Важные

| # | Проблема | Impact |
|---|----------|--------|
| P-004 | PLAN 639 строк (41% всех docs) | Bloat |
| P-005 | Нет automation для docs | Manual work |
| P-006 | Нет validation для docs | Inconsistency |

---

## 3. План изменений

### 3.1 Добавляем (NEW)

| Файл | Что | Строки |
|------|-----|--------|
| **scripts/generate-docs.sh** | Auto-generate 7 docs | ~180 |
| **reference/docs-system.md** | Documentation system reference | ~120 |
| **docs/v8.5.0/** | Version archive | 7 files |
| **quality-checklist.md** L9 | Documentation quality gate | +35 |
| **templates.md** docs section | Naming convention | +30 |
| **P07-closure.md** docs section | Docs generation workflow | +25 |

### 3.2 Изменяем (UPDATE)

| Файл | Было | Стало |
|------|------|-------|
| README.md | README.md | README-skill-architect.md |
| CHANGELOG.md | CHANGELOG.md | CHANGELOG-skill-architect.md |
| validate-docs.sh | v1.x | v2.0 (naming validation) |
| validate-skill.sh | v1.8 | v1.9 (README-{name}.md support) |

### 3.3 Удаляем

| Что | Причина |
|-----|---------|
| ❌ Ничего | NEVER DEGRADE |

---

## 4. Naming Convention

```
{TYPE}-{skill-name}[-v{X.Y.Z}].md

Root (unversioned):
  README-skill-architect.md
  CHANGELOG-skill-architect.md

Version archive (versioned):
  docs/v8.5.0/
    INDEX-skill-architect-v8.5.0.md
    DIFF-skill-architect-v8.5.0.md
    SCAN-skill-architect-v8.5.0.md
    ...
```

---

## 5. Three-Layer Architecture

| Layer | Contains | Audience |
|-------|----------|----------|
| SKILL.md | Minimal instructions | Claude |
| README-{name}.md | User documentation | Human |
| docs/vX.Y.Z/ | Version archives | Reference |

---

## Chat Verification

| # | Topic | Status |
|---|-------|--------|
| 1 | Documentation system design | ✅ |
| 2 | Naming convention | ✅ |
| 3 | generate-docs.sh | ✅ |
| 4 | validate-docs.sh v2.0 | ✅ |
| 5 | L9 quality gate | ✅ |

---

**Confirmation required:** "да", "yes", "go"

---

*PLAN-skill-architect-v8.5.0.md | skill-architect v8.5.0*
