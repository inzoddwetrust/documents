# Backlog

## skill-architect v8.2.0

---

## Current Sprint: Complete ✅

| ID | Item | Status |
|----|------|--------|
| BUG-001 | Frontmatter key validation | ✅ Done |
| OPT-001 | Aggressive pruning | ✅ Done |
| NEW-001 | Knowledge Redundancy Check | ✅ Done |
| NEW-002 | L7 Redundancy in checklist | ✅ Done |

---

## Backlog: Next

### Priority HIGH

| ID | Item | Effort | Notes |
|----|------|--------|-------|
| FEAT-001 | Ecosystem skill audit | M | Run redundancy check on all Thor skills |
| FEAT-002 | Auto-pruning suggestions | L | Generate specific "delete this" recommendations |
| BUG-002 | Footer version sync check | S | Automate version detection in footers |

### Priority MEDIUM

| ID | Item | Effort | Notes |
|----|------|--------|-------|
| FEAT-003 | skill-tester extraction | XL | Separate P08, P09, VT into standalone skill |
| FEAT-004 | Project mode templates | M | Quick-start templates for common project types |
| FEAT-005 | Skill dependency graph | M | Visualize skill ecosystem connections |

### Priority LOW

| ID | Item | Effort | Notes |
|----|------|--------|-------|
| DOC-001 | Video walkthrough | L | Screen recording of skill creation flow |
| DOC-002 | Best practices guide | M | Lean skill development guidelines |
| TECH-001 | Shell script linting | S | Add shellcheck to CI |

---

## Ideas (Unrefined)

- [ ] Skill composition (combining multiple skills)
- [ ] Version migration assistant
- [ ] Skill marketplace integration
- [ ] A/B testing for skill variants
- [ ] Skill usage analytics

---

## Technical Debt

| Item | Severity | Notes |
|------|----------|-------|
| Scripts not unified | Low | Different output formats |
| Protocols verbose | Medium | P07, P08 could be leaner |
| No automated CI | Low | Manual validation only |

---

## Effort Scale

| Size | Hours |
|------|-------|
| XS | <1 |
| S | 1-2 |
| M | 2-4 |
| L | 4-8 |
| XL | 8+ |

---

*05-BACKLOG.md v1.0.0 | skill-architect v8.2.0*
