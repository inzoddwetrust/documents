# Skill Architect v8.2.0 "Lean Core"

Создание скиллов и проектов по протоколам с проверкой на избыточность.

---

## Быстрый старт

```
create skill: [назначение]
create project: [название]
чекап
```

---

## Команды

| Команда | Действие |
|---------|----------|
| `create skill: [цель]` | Новый скилл |
| `create project: [имя]` | Новый проект |
| `update: [изменения]` | Обновить скилл |
| `refactor` | Рефакторинг |
| `чекап` / `full-audit` | Полный аудит |
| `validate +vt` | Виртуальное тестирование |

---

## Что нового в v8.2.0

### Lean Core
- **-58% размер** (6,845 → 2,868 строк)
- Убраны примеры которые Claude и так знает
- Таблицы вместо verbose prose

### Knowledge Redundancy Check
- Phase 2.5 в аудите: проверка на "раздутость"
- L7 в quality-checklist: тест на избыточность
- Автоматическое определение LLM-native контента

### Frontmatter Validation
- Валидация ключей при сборке
- Только: name, description, license, allowed-tools, compatibility, metadata
- version/ecosystem/type → в description

---

## Протоколы

| Протокол | Назначение | Блок |
|----------|------------|------|
| P01 | Активация | |
| P02 | Конфигурация | |
| P03 | Планирование | ⛔ |
| P04 | Сборка | |
| P05 | Валидация | |
| P06 | Доставка | ⛔ |
| P07 | Закрытие | ⛔ |
| P08 | Симуляция | опц |
| P09 | Полный аудит | |

---

## Режимы

- **Tool Mode:** Инструменты для Claude (скиллы)
- **Project Mode:** Базы знаний (проекты)

---

## Принцип Lean

Claude знает:
- Общие концепции (API, REST, SOLID)
- Стандартные паттерны (OWASP, design patterns)
- Форматы (JSON, YAML, markdown)

Скилл содержит ТОЛЬКО:
- Кастомные workflow
- Blocking points
- Platform constraints
- Ecosystem rules

---

## Changelog

### v8.2.0 (2024-12-12)
- ADD: Phase 2.5 Knowledge Redundancy Check
- ADD: L7 Redundancy в quality-checklist
- ADD: Frontmatter key validation
- ADD: Platform constraints в SKILL.md
- CHANGE: Aggressive pruning всех файлов (-58%)
- CHANGE: Концепции вместо примеров

### v8.1.0
- ADD: P09-full-audit
- ADD: context-management.md

### v8.0.3
- Base version

---

*07-README.md v1.0.0 | skill-architect v8.2.0*
