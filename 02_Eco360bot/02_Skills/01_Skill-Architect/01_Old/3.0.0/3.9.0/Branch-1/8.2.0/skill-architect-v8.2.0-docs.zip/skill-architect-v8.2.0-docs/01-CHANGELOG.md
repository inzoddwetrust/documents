# CHANGELOG

## skill-architect

---

## v8.2.0 "Lean Core" (2025-12-12)

### Added
- **Phase 2.5: Knowledge Redundancy Check** in P09-full-audit
- **L7: Knowledge Redundancy** in quality-checklist
- **Redundancy Gene Check** in genetic-audit
- **Frontmatter key validation** in validate-skill.sh
- **Platform Constraints** section in SKILL.md
- **Protocols section** support in MANIFEST parsing

### Changed
- **Aggressive pruning** of all reference files (-60% total size)
- SKILL.md: 240 → 133 lines (-45%)
- engines.md: 484 → 77 lines (-84%)
- templates.md: 431 → 127 lines (-70%)
- project-modules.md: 391 → 60 lines (-85%)
- virtual-testing.md: 359 → 99 lines (-72%)
- All other reference files similarly compressed
- Concept-based approach instead of full examples
- Tables over verbose prose

### Removed
- XML templates for INoT, Multi-Perspective, Security engines
- Full YAML schema examples in project-modules
- Persona card examples in virtual-testing
- Verbose checkpoint examples in context-management
- Redundant explanations of LLM-native concepts

### Fixed
- Frontmatter validation (BUG-001: invalid keys caused upload failure)
- MANIFEST.md protocols section parsing

---

## v8.1.0 "Full Audit" (2025-12-10)

### Added
- P09-full-audit protocol
- context-management.md
- "Protocol First, Always" section
- Iteration Principles section

### Changed
- Protocols P00-P08 → P00-P09

---

## v8.0.3 "Closure & Simulation" (2025-12-08)

### Added
- P07-closure protocol
- P08-simulation protocol
- Optional simulation mode

### Changed
- Restructured P07 and P08

---

*01-CHANGELOG.md v1.0.0 | skill-architect v8.2.0*
