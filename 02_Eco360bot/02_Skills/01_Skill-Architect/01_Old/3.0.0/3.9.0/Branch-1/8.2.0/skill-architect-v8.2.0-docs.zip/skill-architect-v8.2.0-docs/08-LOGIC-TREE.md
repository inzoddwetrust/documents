# Logic Tree

## skill-architect v8.2.0

Business logic flow and decision points.

---

## Main Flow

```
[USER INPUT]
     │
     ▼
┌─────────────────┐
│ P00: Router     │ ← Determine current state
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P01: Activation │ ← Detect mode (tool/project)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P02: Config     │ ← Define purpose, triggers
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P03: Planning   │ ⛔ BLOCKING
└────────┬────────┘
         │ "да/yes/go"
         ▼
┌─────────────────┐
│ P04: Build      │ ← Create/update files
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P05: Validate   │ ← L1-L7 checks
└────────┬────────┘
         │ Pass
         ▼
┌─────────────────┐
│ P06: Delivery   │ ⛔ BLOCKING
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P07: Closure    │ ⛔ BLOCKING
└────────┬────────┘
         │
         ▼
    [P08: Simulation?]
         │
         ▼
       [END]
```

---

## Mode Detection (P01-P02)

```
INPUT
  │
  ├── "create skill" ──────► Tool Mode
  │                              │
  ├── "create project" ────► Project Mode
  │                              │
  ├── "update" + file ─────► Update Mode
  │                              │
  ├── "refactor" + file ───► Refactor Mode
  │                              │
  └── "чекап/full-audit" ──► P09 (any time)
```

---

## Validation Flow (P05)

```
P05: Validate
     │
     ├── L1: Structure
     │   └── SKILL.md, README.md, size, frontmatter
     │
     ├── L2: Content
     │   └── Purpose, triggers, version
     │
     ├── L3: Logic
     │   └── State machine, blocking points
     │
     ├── L4: Naming
     │   └── Kebab-case, semver
     │
     ├── L5: Integration
     │   └── MANIFEST, scripts, footers
     │
     ├── L6: Execution
     │   └── Flow test
     │
     └── L7: Redundancy ← NEW
         └── LLM-native content check
```

---

## Full Audit Flow (P09)

```
"чекап" / "full-audit"
         │
         ▼
┌─────────────────────┐
│ Phase 1: Structure  │ ← validate-skill.sh
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ Phase 2: Genetics   │ ← genetic-audit.sh
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ Phase 2.5:          │ ← NEW
│ Redundancy Check    │
└─────────┬───────────┘
          │
          ├── [+web] ──► Phase 3: Industry
          │
          ├── [+vt] ───► Phase 4: Virtual Testing
          │
          └── [+full] ─► Both Phase 3 + 4
                │
                ▼
         [CONSOLIDATED REPORT]
```

---

## Redundancy Decision Tree

```
For each content block:
     │
     ├── "Would Claude know this without the skill?"
     │   │
     │   ├── YES ──► LLM-Native ──► DELETE
     │   │
     │   └── NO ───► Check next
     │
     ├── "Is this teaching or configuring Claude?"
     │   │
     │   ├── Teaching ──► Redundant ──► DELETE
     │   │
     │   └── Configuring ──► KEEP
     │
     └── "General concept or skill-specific rule?"
         │
         ├── General ──► Redundant ──► DELETE
         │
         └── Specific ──► KEEP
```

---

## Blocking Points

| Point | Condition | Action |
|-------|-----------|--------|
| P03 → P04 | Explicit "да/yes/go" | Wait for confirmation |
| P06 → P07 | Skill delivered | Verify receipt |
| P07 → P08 | User choice | Offer simulation |

---

## Error Recovery

```
State unclear?
     │
     ├── Check /home/claude/ ──► Artifacts
     │
     ├── Check /mnt/user-data/outputs/ ──► Deliverables
     │
     ├── Ask user "Where were we?"
     │
     └── Resume from last confirmed state
```

---

*08-LOGIC-TREE.md v1.0.0 | skill-architect v8.2.0*
