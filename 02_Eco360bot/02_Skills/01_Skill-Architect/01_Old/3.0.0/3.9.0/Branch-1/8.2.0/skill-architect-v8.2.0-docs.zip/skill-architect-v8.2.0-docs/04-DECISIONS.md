# Architectural Decisions

## skill-architect v8.2.0

---

## ADR-001: Aggressive Pruning over Decomposition

**Date:** 2025-12-12  
**Status:** Accepted

### Context
Skill-architect v8.1.0 reached 6,845 lines with SKILL.md at 240/300 (80% of limit). Two options considered:
1. Decompose into multiple skills (skill-forge, project-forge, skill-tester)
2. Aggressive pruning of existing files

### Decision
**Chose Option 2: Aggressive Pruning**

### Rationale
- Core workflow remains unified (tool + project modes share 90% logic)
- Lower sync overhead (one skill vs three)
- Faster implementation (4h vs 8h)
- Testing isolated to future skill if needed

### Consequences
- Reduced from 6,845 to 2,771 lines (-60%)
- SKILL.md from 240 to 133 lines (56% of limit)
- Future decomposition possible if needed

---

## ADR-002: Concept-Based over Example-Based

**Date:** 2025-12-12  
**Status:** Accepted

### Context
Files like engines.md (484 lines) contained full XML templates that LLM already knows conceptually.

### Decision
Replace full templates with concept references and presets.

### Rationale
- Claude knows INoT (agent debate), OWASP, design patterns natively
- Full examples = teaching LLM what it knows
- Skill should configure, not teach

### Consequences
- engines.md: 484 → 77 lines (-84%)
- Risk: edge cases may need explicit handling
- Mitigation: keep reference links, test flows

---

## ADR-003: Knowledge Redundancy Check

**Date:** 2025-12-12  
**Status:** Accepted

### Context
Manual pruning showed 40%+ content was LLM-native knowledge. Need systematic detection.

### Decision
Add redundancy checks to audit flow:
- Phase 2.5 in P09-full-audit
- L7 in quality-checklist
- Redundancy Gene in genetic-audit

### Rationale
- Prevent future bloat
- Applicable to ALL skills in ecosystem
- Quick test: "Delete this. Would skill work?" → YES = redundant

### Consequences
- All future skills will be leaner
- Audit catches redundancy early
- Ecosystem-wide benefit

---

## ADR-004: Frontmatter Validation

**Date:** 2025-12-12  
**Status:** Accepted

### Context
Skills with invalid frontmatter keys (version, ecosystem, type) failed Claude.ai upload silently.

### Decision
- Add validation to validate-skill.sh
- Document allowed keys in templates.md
- Add platform constraints to SKILL.md

### Rationale
- Fail fast at build time, not upload time
- Clear documentation prevents errors
- PATCH-frontmatter integration

### Consequences
- Invalid keys caught during validation
- Developers know allowed keys upfront
- BUG-001 resolved

---

## ADR-005: Protocol-Based Not Mode-Based

**Date:** 2025-12-12  
**Status:** Retained (from v8.0.3)

### Context
Tool mode and Project mode share 90% of protocol flow (P01-P09).

### Decision
Keep single protocol chain, branch at config (P02).

### Rationale
- Avoids duplication
- Easier maintenance
- Clear extension point

### Consequences
- P02 determines mode
- Same protocols, different configs
- Single SKILL.md handles both

---

*04-DECISIONS.md v1.0.0 | skill-architect v8.2.0*
