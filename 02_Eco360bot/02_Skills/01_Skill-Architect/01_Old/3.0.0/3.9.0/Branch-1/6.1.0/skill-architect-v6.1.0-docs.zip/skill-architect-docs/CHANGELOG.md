# Changelog

All notable changes to skill-architect.

---

## [6.1.0] - 2025-12-02

### Added
- P00-router.md — meta-protocol for state machine navigation
- reference/commands.md — SSOT for all shell commands
- SSOT Note pattern for reference guides

### Changed
- SKILL.md simplified to pure router (166→134 lines)
- All protocols (P01-P08): inline commands → references to commands.md
- self-diagnostic.md: rewritten for Protocol-First checks
- self-diagnostic.sh: smart SSOT validation
- ssot-check.md: updated rules for SSOT Note pattern
- All footers updated to v6.1.0

### Fixed
- SSOT violations: 12 duplicate commands → 0
- Outdated footers: 14 → 0

---

## [6.0.0] - 2025-11-XX

### Added
- Protocol-Driven architecture (P01-P08)
- Blocking points at P03, P06, P07
- Protocol Router in SKILL.md

### Changed
- Complete restructure from inline to protocol-based
- SKILL.md becomes entry point / router

---

## [5.4.0] - 2025-XX-XX

### Added
- self-diagnostic.md protocol
- ssot-check.sh script

---

## [5.3.0] - 2025-XX-XX

### Added
- Project Mode support
- YAML module specifications
- Import/export procedures

---

*CHANGELOG.md v1.0.0 | skill-architect v6.1.0*
