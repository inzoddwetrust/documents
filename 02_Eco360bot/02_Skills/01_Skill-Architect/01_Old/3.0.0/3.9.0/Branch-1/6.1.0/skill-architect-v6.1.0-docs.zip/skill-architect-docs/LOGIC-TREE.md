# Logic Tree

Decision flow and state machine for skill-architect.

---

## Main Flow

```
[START]
    │
    ▼
┌─────────┐
│   P01   │ Activation
│         │ Read clean-protocol, detect mode
└────┬────┘
     │
     ▼
┌─────────┐
│   P02   │ Config
│         │ Gather requirements, read references
└────┬────┘
     │
     ▼
┌─────────┐
│   P03   │ Planning ⛔ BLOCKING
│         │ Create plan, wait for confirmation
└────┬────┘
     │ "да/yes/go"
     ▼
┌─────────┐
│   P04   │ Build
│         │ Implement per plan
└────┬────┘
     │
     ▼
┌─────────┐
│   P05   │ Validate
│         │ Run validators, create diff
└────┬────┘
     │
     ▼
┌─────────┐
│   P06   │ Delivery-Skill ⛔ BLOCKING
│         │ Package .skill, wait for docs confirm
└────┬────┘
     │
     ├──"готово/skip"──────────────────┐
     │                                  │
     │ "да/docs"                        │
     ▼                                  │
┌─────────┐                             │
│   P07   │ Delivery-Docs ⛔ BLOCKING   │
│         │ Create 7 doc files          │
└────┬────┘                             │
     │                                  │
     ▼                                  │
┌─────────┐◄────────────────────────────┘
│   P08   │ Scan
│         │ Chat scan, update backlog
└────┬────┘
     │
     ▼
  [END]
```

---

## Decision Points

### D1: Mode Detection (P01)

| Condition | Action |
|-----------|--------|
| "project" in request | → Project Mode |
| else | → Tool Mode |

### D2: Confirmation Handling (P03)

| User says | Action |
|-----------|--------|
| "да/yes/go/делай/proceed" | → P04 |
| "ок/понял" | Ask explicit confirmation |
| Question | Answer, re-ask |
| Change request | Update plan, re-confirm |

### D3: Docs Decision (P06)

| User says | Action |
|-----------|--------|
| "да/yes/docs/доки" | → P07 |
| "готово/skip/всё" | → P08 (skip docs) |

### D4: NEVER DEGRADE Check (P04)

| Condition | Action |
|-----------|--------|
| Removes working functionality | ⛔ STOP |
| Replaces specific with abstract | ⛔ STOP |
| No space for content | Move to reference/ |
| New feature | ADD alongside, don't merge |

---

## State Tracking

Each response ends with protocol state:

```
Protocol: P0X
Status: [in-progress | waiting | complete]
Next: P0Y (condition)
```

---

## Recovery

If state unclear:
1. Check /home/claude/ for work artifacts
2. Check /mnt/user-data/outputs/ for deliverables
3. Ask user: "Where were we?"
4. Resume from last confirmed state

---

*LOGIC-TREE.md v1.0.0 | skill-architect v6.1.0*
