# Backlog

Future tasks and ideas for skill-architect.

---

## Active

| # | Task | Priority | Source |
|---|------|----------|--------|
| B-001 | Split engines.md (372 lines → <300) | Medium | Opus feedback, audit-skill.sh |
| B-002 | Split project-modules.md (391 lines → <300) | Medium | Opus feedback, audit-skill.sh |
| B-003 | Split workflow.md (327 lines → <300) | Medium | audit-skill.sh |
| B-004 | Standardize reference files to English | Low | audit-skill.sh |
| B-005 | Add more examples to SKILL.md | Low | Best Practices Score 5/8 |

---

## Ideas

| # | Idea | Notes |
|---|------|-------|
| I-001 | Auto-generate MANIFEST.md from folder scan | Could simplify P05 |
| I-002 | Protocol visualization tool | Mermaid diagram generator |
| I-003 | Skill template generator | Interactive wizard mode |
| I-004 | Cross-skill dependency checker | For multi-skill projects |

---

## Rejected

| # | Idea | Reason |
|---|------|--------|
| R-001 | Fast-track mode for simple skills | Consistency > speed. "Лучше +пару минут но всё чётко" |

---

## Done

### v6.1.0
| # | Task | Implemented |
|---|------|-------------|
| D-001 | Protocol-First SSOT compliance | All commands → commands.md |
| D-002 | Update all footers to v6.1.0 | 14 files updated |
| D-003 | Create P00-router.md | Meta-protocol added |
| D-004 | Smart SSOT validation in self-diagnostic.sh | SSOT Note pattern |

### v6.0.0
| # | Task | Implemented |
|---|------|-------------|
| D-005 | Protocol-Driven architecture | P01-P08 created |
| D-006 | Blocking points system | P03, P06, P07 |

---

*BACKLOG.md v1.1.0 | skill-architect v6.1.0*
