# SCAN: skill-architect v8.7.0

Post-build validation results.

---

## Summary

| Check | Result |
|-------|--------|
| SKILL.md exists | ☐ |
| README-{name}.md exists | ☐ |
| CHANGELOG-{name}.md exists | ☐ |
| SKILL.md < 300 lines | ☐ |
| SKILL.md English | ☐ |
| Frontmatter valid | ☐ |
| Version sync | ☐ |
| Package format | ☐ ZIP |

**Overall:** PENDING

---

## File Counts

| Category | Count |
|----------|-------|
| Core files | |
| Reference files | |
| Protocol files | |
| Script files | |
| **Total** | |

---

## SKILL.md Analysis

```
Lines: / 300
Headings:
Tables:
Code blocks:
```

---

## Protocol Completeness

| Protocol | File | Self-Check |
|----------|------|------------|
| P00-router | ☐ | ☐ |
| P01-activation | ☐ | ☐ |
| ... | | |

---

*SCAN-skill-architect-v8.7.0.md | skill-architect v8.7.0*
