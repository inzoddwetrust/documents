# DECISIONS: skill-architect v8.7.0

Architectural Decision Records.

---

## AD-001: [Decision Title]

**Context:** [Why this decision was needed]

**Decision:** [What was decided]

**Alternatives:**
- [Option A] → [Why not]
- [Option B] → [Why not]

**Consequences:** [Impact]

---

## Decision Principles

1. **Visibility over brevity** — better visible than short
2. **Explicit over implicit** — explicit beats implicit
3. **Prevention over correction** — prevent beats fix
4. **NEVER DEGRADE** — only add, never remove

---

*DECISIONS-skill-architect-v8.7.0.md | skill-architect v8.7.0*
