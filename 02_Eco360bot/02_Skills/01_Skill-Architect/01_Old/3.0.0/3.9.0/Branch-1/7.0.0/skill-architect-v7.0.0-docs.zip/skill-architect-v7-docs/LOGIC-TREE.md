# LOGIC-TREE

Дерево решений skill-architect v7.0.0.

---

## Main Flow

```
[START]
    │
    ▼
┌─────────────────────────────┐
│ SKILL.md activated          │
│ Read P00-router.md          │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ P01: Activation             │
│ Read clean-protocol         │
│ "Purpose?"                  │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ P02: Config                 │
│ Detect mode (Tool/Project)  │
│ Gather requirements         │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ P03: Planning          ⛔   │
│ Create PLAN.md              │
│ Chat verification           │
│ WAIT: "да/yes/go"           │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ P04: Build                  │
│ Create/Update files         │
│ Check NEVER DEGRADE         │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ P05: Validate               │
│ → See P05 Flow below        │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ P06: Delivery Skill    ⛔   │
│ Package .skill              │
│ WAIT: "да/docs" or "skip"   │
└─────────────────────────────┘
    │
    ├── "docs" ──────────────────┐
    │                            ▼
    │              ┌─────────────────────────────┐
    │              │ P07: Delivery Docs     ⛔   │
    │              │ Create 7 doc files          │
    │              │ Package docs.zip            │
    │              └─────────────────────────────┘
    │                            │
    ├────────────────────────────┘
    ▼
┌─────────────────────────────┐
│ P08: Scan                   │
│ Final review                │
│ [END]                       │
└─────────────────────────────┘
```

---

## P05: Validate Flow (v7.0.0)

```
[P05 START]
    │
    ▼
┌─────────────────────────────┐
│ Check flags                 │
│ +vt? +full?                 │
└─────────────────────────────┘
    │
    ├── +vt ─────────────────────────────────────┐
    │                                            ▼
    │                    ┌─────────────────────────────────┐
    │                    │ LAYER 0: Virtual Testing       │
    │                    │ ├─ Context Detection           │
    │                    │ ├─ Persona Generation (5-7)    │
    │                    │ ├─ Adversarial Layer           │
    │                    │ ├─ Expert Panel                │
    │                    │ └─ Scoring                     │
    │                    └─────────────────────────────────┘
    │                                            │
    │                                 ┌──────────┴──────────┐
    │                                 ▼                     ▼
    │                          Score ≥ 70?           Any 🔴 Critical?
    │                             │                        │
    │                          YES │                    YES │
    │                             ▼                        ▼
    │                         Continue                ⛔ STOP, fix
    │                                            
    ├────────────────────────────────────────────────────────┘
    ▼
┌─────────────────────────────────┐
│ LAYER 1: Static Validation     │ ← Always runs
│ ├─ validate-skill.sh           │
│ ├─ validate-naming.sh          │
│ └─ ssot-check.sh               │
└─────────────────────────────────┘
    │
    ├── Any ❌? ──────────────────────────────────┐
    │                                            ▼
    │                                      ⛔ Fix first
    │
    ├── +full ───────────────────────────────────┐
    │                                            ▼
    │                    ┌─────────────────────────────────┐
    │                    │ LAYER 2: Deep Testing          │
    │                    │ ├─ L4: Simulation              │
    │                    │ ├─ L5: Methodology             │
    │                    │ └─ L6: Interpretation          │
    │                    └─────────────────────────────────┘
    │                                            │
    ├────────────────────────────────────────────┘
    ▼
┌─────────────────────────────────┐
│ LAYER 3: Reporting             │ ← Always runs
│ ├─ Diff Report                 │
│ ├─ MANIFEST.md                 │
│ └─ [+full] TEST_REPORT.md      │
└─────────────────────────────────┘
    │
    ▼
[P05 END → P06]
```

---

## Virtual Testing Decision Tree

```
[VT Input: Artifact]
    │
    ▼
┌─────────────────────────────┐
│ Context Detection           │
│ Has SKILL.md? → "skill"     │
│ Has problem? → "idea"       │
│ Has features? → "product"   │
│ Else → "document"           │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ Generate Personas           │
│ - 1+ novice                 │
│ - 1+ expert                 │
│ - 1+ skeptic                │
│ - 1+ edge case              │
│ - 1+ integrator             │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ For each claim in artifact: │
│ ├─ Attack (feasibility)     │
│ ├─ Attack (clarity)         │
│ ├─ Attack (edge cases)      │
│ ├─ Attack (dependencies)    │
│ └─ Risk = P × I             │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ Expert Panel                │
│ ├─ User scores              │
│ ├─ Maintainer scores        │
│ ├─ Skeptic scores           │
│ ├─ Integrator scores        │
│ ├─ Novice scores            │
│ └─ Debate disagreements     │
└─────────────────────────────┘
    │
    ▼
┌─────────────────────────────┐
│ Final Score                 │
│ ├─ ≥90 → Excellent          │
│ ├─ 70-89 → Good             │
│ ├─ 50-69 → Weak             │
│ └─ <50 → Critical           │
└─────────────────────────────┘
    │
    ▼
[Output: Hypotheses to validate]
```

---

## NEVER DEGRADE Check

```
[Before ANY change]
    │
    ▼
┌─────────────────────────────┐
│ 1. Removes functionality?   │
└─────────────────────────────┘
    │
    ├── YES → ⛔ STOP
    │
    ▼
┌─────────────────────────────┐
│ 2. Replaces specific        │
│    with abstract?           │
└─────────────────────────────┘
    │
    ├── YES → ⛔ STOP
    │
    ▼
┌─────────────────────────────┐
│ 3. No space?                │
└─────────────────────────────┘
    │
    ├── YES → Move to reference/, never delete
    │
    ▼
┌─────────────────────────────┐
│ 4. New feature?             │
└─────────────────────────────┘
    │
    ├── YES → ADD alongside, don't merge
    │
    ▼
[PROCEED with change]
```

---

*LOGIC-TREE.md v1.0.0 | skill-architect v7.0.0*
