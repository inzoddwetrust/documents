# CHANGELOG

Все изменения skill-architect документируются здесь.

---

## [7.0.0] — 2025-12-05 "Unified Ecosystem"

### Добавлено
- **Virtual Testing Engine** — синтетическая валидация через персоны, devil's advocate, expert panel
- **reference/virtual-testing.md** — VT протокол
- **reference/test-levels.md** — L1-L6 спецификации тестов
- **reference/test-cases.md** — паттерны тест-кейсов
- **reference/personas.md** — шаблоны синтетических пользователей
- **reference/adversarial.md** — devil's advocate протокол
- **reference/expert-panel.md** — multi-agent evaluation
- **+vt флаг** — запуск Virtual Testing в P05
- **+full флаг** — запуск глубокого тестирования (L4-L6)
- Секция "Testing & Validation" в SKILL.md resources

### Изменено
- **P05-validate.md** — расширен с 3 шагов до 4 layers
- **engines.md** — добавлен VT Engine, обновлены presets
- **templates.md** — добавлен VT hook раздел
- **quality-checklist.md** — добавлен VT gate раздел
- **README.md** — полностью переписан с VT документацией

### Интегрировано
- **skill-tester** — функциональность поглощена в skill-architect

### Сохранено без изменений
- Ядро: SKILL.md router structure
- Протоколы: P00-P04, P06-P08
- Все скрипты
- Core reference файлы

---

## [6.2.0] — 2025-XX-XX "Self-Compliance"

### Добавлено
- Explicit first step requirement
- Absolute paths в инструкциях
- Naming checks в checklist

---

## [6.1.0] — 2025-XX-XX "Protocol Router"

### Добавлено
- P00-router.md мета-протокол
- State tracking между протоколами

---

## [6.0.0] — 2025-XX-XX "Protocol-Driven"

### Добавлено
- Protocol-first architecture (P01-P08)
- Blocking points
- Chat verification в planning

### Изменено
- Полная реструктуризация workflow

---

## [5.x.x] — Earlier versions

См. историю версий в README.md предыдущих версий.

---

*CHANGELOG.md v1.0.0 | skill-architect v7.0.0*
