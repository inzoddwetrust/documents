# BACKLOG

Идеи, известные проблемы и планы развития skill-architect.

---

## Приоритет: High

### [FEATURE] VT Auto-trigger для complex skills
**Статус:** Planned
**Описание:** Автоматически запускать VT когда skill имеет >5 протоколов или >20 reference файлов.
**Зачем:** Уменьшить risk сложных скилов без ручного +vt.

### [IMPROVEMENT] VT Scoring calibration
**Статус:** Needs Research
**Описание:** Калибровка весов scoring engine на реальных данных.
**Зачем:** Текущие веса экспертные, нужна валидация.

---

## Приоритет: Medium

### [FEATURE] VT Report export
**Статус:** Idea
**Описание:** Экспорт VT результатов в отдельный файл (не только в Diff).
**Зачем:** Удобнее для review и архивирования.

### [FEATURE] Persona customization
**Статус:** Idea
**Описание:** Позволить пользователю добавлять свои персоны.
**Зачем:** Domain-specific тестирование.

### [IMPROVEMENT] L4 test generation
**Статус:** Idea
**Описание:** Автоматическая генерация test cases из SKILL.md triggers.
**Зачем:** Ускорить +full тестирование.

---

## Приоритет: Low

### [DOCS] Video walkthrough
**Статус:** Idea
**Описание:** Видео-демо создания skill с нуля.
**Зачем:** Onboarding новых пользователей.

### [FEATURE] Skill templates gallery
**Статус:** Idea
**Описание:** Готовые шаблоны для частых use cases.
**Зачем:** Ускорить создание типовых скилов.

---

## Известные ограничения

### VT Limitations
- Синтетические персоны ≠ реальные пользователи
- Adversarial attacks based on known patterns
- Expert panel perspectives from training data
- **Митигация:** Явное указание "HYPOTHESES, not facts"

### Context window
- При длинных сессиях Claude может "забывать" инструкции
- **Митигация:** FIRST STEP — MANDATORY, перечитывать протоколы

### Deep testing duration
- +full +vt может занять 15+ минут
- **Митигация:** Разделение на опциональные флаги

---

## Отклонённые идеи

### ❌ Merge VT и Static validation
**Причина:** Нарушает принцип "optional layers"
**Решение:** Оставить VT как +vt флаг

### ❌ Auto-fix после VT
**Причина:** VT генерирует гипотезы, не facts
**Решение:** Человек принимает решение о fix

---

*BACKLOG.md v1.0.0 | skill-architect v7.0.0*
