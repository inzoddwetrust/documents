# Logic Tree: skill-architect v8.4.0

Business logic flow and decision points.

---

## Main Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                      ACTIVATION                                  │
│                                                                  │
│  User triggers skill-architect                                   │
│         ↓                                                        │
│  P01: "Skill Architect v8.4.0. Purpose? Triggers?"              │
│         ↓                                                        │
│  ┌─────────────────┐                                            │
│  │ Purpose stated? │                                            │
│  └────────┬────────┘                                            │
│      YES  │  NO → Wait                                           │
│           ↓                                                      │
└───────────┼─────────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────────┐
│           ↓         CONFIG                                       │
│  P02: Extract/Ask                                               │
│         ↓                                                        │
│  ┌─────────────────┐                                            │
│  │ Mode detected?  │                                            │
│  └────────┬────────┘                                            │
│     ┌─────┴─────┐                                               │
│     ↓           ↓                                               │
│   TOOL      PROJECT                                              │
│     │           │                                               │
│     └─────┬─────┘                                               │
│           ↓                                                      │
│  Self-Check ✓                                                    │
└───────────┼─────────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────────┐
│           ↓   ════════════════════════════════════              │
│               ⛔ PLANNING — BLOCKING                             │
│               ════════════════════════════════════              │
│  P03: Create Planning Document                                   │
│         ↓                                                        │
│  Chat Verification                                               │
│         ↓                                                        │
│  ┌─────────────────┐                                            │
│  │ User confirms?  │ "да/yes/go"                                │
│  └────────┬────────┘                                            │
│      YES  │  NO → Wait / Revise                                  │
│           │  "ок понял" → Re-ask!                                │
│           ↓                                                      │
│  Self-Check ✓                                                    │
└───────────┼─────────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────────┐
│           ↓         BUILD                                        │
│                                                                  │
│  ⛔ PRE-BUILD CHECKPOINT (v8.4.0 NEW)                           │
│  ┌────────────────────────────────┐                             │
│  │ □ Plan confirmed?              │                             │
│  │ □ SKILL.md = English?          │                             │
│  │ □ README = User's language?    │                             │
│  │ □ < 300 lines?                 │                             │
│  └────────────────────────────────┘                             │
│         ↓                                                        │
│  P04: NEVER DEGRADE check                                        │
│         ↓                                                        │
│  ┌─────────────────┐                                            │
│  │ DEGRADE risk?   │                                            │
│  └────────┬────────┘                                            │
│      NO   │  YES → ⛔ STOP, discuss                              │
│           ↓                                                      │
│  Implement per plan                                              │
│  Apply 5 Clean Skill Principles                                  │
│           ↓                                                      │
│  Self-Check ✓                                                    │
└───────────┼─────────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────────┐
│           ↓         VALIDATE                                     │
│  P05: Run validators L1-L8                                       │
│         ↓                                                        │
│  ┌─────────────────┐                                            │
│  │ All pass?       │                                            │
│  └────────┬────────┘                                            │
│      YES  │  NO → Fix issues, re-validate                        │
│           ↓                                                      │
│  Create Diff Report (diff-report.md format)                      │
│           ↓                                                      │
│  Self-Check ✓                                                    │
└───────────┼─────────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────────┐
│           ↓   ════════════════════════════════════              │
│               ⛔ DELIVERY — BLOCKING                             │
│               ════════════════════════════════════              │
│  P06: Package .skill                                             │
│         ↓                                                        │
│  Verify ZIP format                                               │
│         ↓                                                        │
│  Present Diff Report + Download Link                             │
│         ↓                                                        │
│  ┌─────────────────┐                                            │
│  │ User confirms?  │                                            │
│  └────────┬────────┘                                            │
│      YES  │  NO → Wait                                           │
│           ↓                                                      │
│  Self-Check ✓                                                    │
└───────────┼─────────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────────┐
│           ↓   ════════════════════════════════════              │
│               ⛔ CLOSURE — BLOCKING                              │
│               ════════════════════════════════════              │
│  P07: Scan + Generate 8 docs                                     │
│         ↓                                                        │
│  Package docs.zip                                                │
│         ↓                                                        │
│  Final delivery (skill + docs)                                   │
│         ↓                                                        │
│  ┌─────────────────┐                                            │
│  │ Simulation?     │                                            │
│  └────────┬────────┘                                            │
│     YES   │  NO                                                  │
│     ↓     ↓                                                      │
│   P08   END                                                      │
│           ↓                                                      │
│  Self-Check ✓                                                    │
└───────────┴─────────────────────────────────────────────────────┘
```

---

## Context Drift Protection (v8.4.0 NEW)

```
┌─────────────────────────────────────────────────────────────────┐
│                 CONTEXT DRIFT DETECTION                          │
│                                                                  │
│  Triggers:                                                       │
│  • After web search                                              │
│  • After long conversation                                       │
│  • Any doubt about rules                                         │
│         ↓                                                        │
│  ┌─────────────────────────────────────────┐                    │
│  │ PRE-BUILD CHECKPOINT                     │                    │
│  │                                          │                    │
│  │ □ Plan confirmed (да/yes/go)?           │                    │
│  │ □ SKILL.md = English?                   │                    │
│  │ □ README.md = User's language?          │                    │
│  │ □ < 300 lines?                          │                    │
│  │ □ Frontmatter valid?                    │                    │
│  └─────────────────────────────────────────┘                    │
│         ↓                                                        │
│  Context Anchor in EVERY response:                               │
│  ┌─────────────────────────────────────────┐                    │
│  │ ⚙️ skill v8.4.0 · P0X · status          │                    │
│  │ 📋 SKILL.md=EN | README=[LANG] | <300   │  ← Rule reminder   │
│  │ 🟢 ~Xk | ~Yk 🟡                         │                    │
│  └─────────────────────────────────────────┘                    │
└─────────────────────────────────────────────────────────────────┘
```

---

## Decision Points Summary

| Point | Options | Default |
|-------|---------|---------|
| Mode | Tool / Project | Tool |
| Plan confirm | да/yes/go / revise | Wait |
| "ок понял" | Re-ask | Re-ask |
| DEGRADE check | Continue / STOP | Continue |
| PRE-BUILD | Pass / Re-check | Re-check |
| Validation | Pass / Fix | Fix loop |
| Skill delivery | Confirm / Wait | Wait |
| Simulation | Yes / No | No |

---

## Blocking Points (⛔)

| Protocol | Gate | Requires |
|----------|------|----------|
| P03 | Planning confirm | Explicit "да/yes/go" |
| P06 | Skill delivery | User confirmation |
| P07 | Closure | All 8 docs complete |

---

## Quality Gates

| Phase | Check |
|-------|-------|
| Activation | Purpose + Triggers asked |
| Config | Mode + Complexity determined |
| Planning | Chat Verification passed |
| Pre-Build | PRE-BUILD CHECKPOINT passed |
| Build | NEVER DEGRADE passed |
| Validate | L1-L8 all green |
| Delivery | ZIP verified, Diff Report created |
| Closure | Scan clean, 8 docs generated |

---

## Self-Check Points (v8.4.0 NEW)

Every protocol ends with Self-Check:

```
□ Current protocol objectives met?
□ NEVER DEGRADE respected?
□ SKILL.md still in English?
□ Blocking confirmation received (if required)?
□ All changes logged for Diff Report?
```

---

*08-LOGIC-TREE.md v1.0.0 | skill-architect v8.4.0*
