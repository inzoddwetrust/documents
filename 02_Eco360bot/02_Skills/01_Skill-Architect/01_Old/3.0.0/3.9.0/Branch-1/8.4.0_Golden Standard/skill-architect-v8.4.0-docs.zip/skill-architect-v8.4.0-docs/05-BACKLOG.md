# Backlog: skill-architect v8.4.0

Текущий backlog после релиза v8.4.0 "Golden Standard".

---

## ✅ Закрыто в v8.4.0

| ID | Item | Status |
|----|------|--------|
| B-020 | PRE-BUILD CHECKPOINT в SKILL.md | ✅ Done |
| B-021 | Enhanced Context Anchor | ✅ Done |
| B-022 | Common Mistakes секция | ✅ Done |
| B-023 | Self-Check в протоколах | ✅ Done |
| B-024 | Visual blocking markers | ✅ Done |
| B-025 | retrospective.md | ✅ Done |
| B-026 | Enhanced Recovery в P00 | ✅ Done |
| B-027 | Inline примеры в evaluations | ✅ Done (E-001) |

---

## 📋 Открытый Backlog

### 🔴 High Priority

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-028 | Inline примеры для E-002 to E-008 | v8.4.0 | Только E-001 сделан |
| B-029 | Auto-detect context drift | v8.4.0 | Механизм определения потери контекста |

### 🟡 Medium Priority

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-017 | Project Mode evaluations расширить | v5.3.0 | E-006, E-007, E-008 базовые |
| B-030 | Multi-skill dependency graph | v8.2.1 | skill-architect порождает child skills |
| B-031 | Real-time token counter integration | v8.2.1 | Интеграция с платформой |

### 🟢 Low Priority / Ideas

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-032 | Shared reference library | v8.2.1 | Общие паттерны в отдельный skill |
| B-033 | Skill versioning strategy doc | v8.4.0 | Когда MAJOR/MINOR/PATCH |
| B-034 | Automated regression testing | v8.4.0 | CI/CD для skills |

---

## 🐛 Known Issues

| ID | Issue | Workaround |
|----|-------|------------|
| I-004 | genetic-audit.sh exit code 1 при partial pass | Manual check |
| I-005 | validate-skill.sh не проверяет YAML syntax | Manual check |

---

## 📊 Backlog Stats

| Category | Count |
|----------|-------|
| High Priority | 2 |
| Medium Priority | 3 |
| Low Priority | 3 |
| Known Issues | 2 |
| **Total Open** | **10** |

---

## Prioritization Criteria

1. **Impact on Claude's work quality** — высший приоритет
2. **User-facing improvements** — средний приоритет
3. **Developer experience** — низкий приоритет

---

*05-BACKLOG.md v1.0.0 | skill-architect v8.4.0*
