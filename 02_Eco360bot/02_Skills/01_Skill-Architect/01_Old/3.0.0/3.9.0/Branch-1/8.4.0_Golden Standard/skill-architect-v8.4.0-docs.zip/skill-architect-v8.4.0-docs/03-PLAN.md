# skill-architect: План v8.3.0 → v8.4.0 "Golden Standard"

**Дата:** 2025-12-12  
**Контекст:** Сравнительный анализ V1 vs V2, предложения Claude Opus по улучшению механизмов взаимодействия  
**Источники:** comparison-report.md, V1 RETROSPECTIVE.md, V2 evaluations.md

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | User's language (RU) |
| Frontmatter | name + description (version in description) |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

### Почему v8.4.0?

Анализ двух версий v8.3.0 выявил:
- **V2 полнее** — 12 правил vs 8, все 5 Clean Skill Principles, L8 Version Integrity
- **V1 имеет ценное** — RETROSPECTIVE.md с историей 18 версий
- **Обе версии не имеют** — механизмов защиты от context drift

### Цель v8.4.0 "Golden Standard"

Создать **эталонную версию**, которая:
1. Объединяет лучшее из V1 и V2
2. Добавляет механизмы защиты от ошибок Claude
3. Минимизирует context drift после web search
4. Максимизирует self-verification

---

## 2. Проблемы / Задачи

### 🔴 Критические (влияют на качество работы Claude)

| # | Проблема | Источник | Impact |
|---|----------|----------|--------|
| P-001 | Context drift после web search | Opus analysis | Claude забывает SKILL.md=English |
| P-002 | Нет PRE-BUILD CHECKPOINT в SKILL.md | Opus proposal | Правила разбросаны по протоколам |
| P-003 | Context Anchor без rule reminder | Opus proposal | Каждый ответ не напоминает правила |
| P-004 | Blocking points визуально не выделены | Opus proposal | Легко пропустить ⛔ |

### 🟡 Важные (улучшают workflow)

| # | Проблема | Источник | Impact |
|---|----------|----------|--------|
| P-005 | Нет Common Mistakes секции | Opus proposal | Типичные ошибки повторяются |
| P-006 | Self-Check вопросов нет в протоколах | Opus proposal | Нет самопроверки перед переходом |
| P-007 | RETROSPECTIVE отсутствует в V2 | V1 analysis | Теряется история эволюции |
| P-008 | Recovery protocol минимальный | Opus analysis | Сложно восстановиться после drift |

### 🟢 Улучшения (nice-to-have)

| # | Проблема | Источник | Impact |
|---|----------|----------|--------|
| P-009 | Нет inline примеров в evaluations | Opus proposal | Не вижу ожидаемый output |
| P-010 | Footer версия в Context Anchor | Opus proposal | Версия в каждом ответе |

---

## 3. План изменений

### 3.1 ДОБАВЛЯЕМ (NEW)

| Файл | Что | Зачем |
|------|-----|-------|
| **SKILL.md** | `## ⛔ PRE-BUILD CHECKPOINT` | Reminder перед каждой сборкой |
| **SKILL.md** | `## ⚠️ Common Mistakes` | Предотвращение типичных ошибок |
| **SKILL.md** | Enhanced Context Anchor с правилами | Reminder в каждом ответе |
| **reference/retrospective.md** (NEW) | История эволюции из V1 | Контекст принятых решений |
| **P00-router.md** | Enhanced Recovery Protocol | Восстановление после drift |
| **Все протоколы** | `## Self-Check` секция | Самопроверка перед переходом |

### 3.2 ИЗМЕНЯЕМ (UPDATE)

| Файл | Изменение | Было → Стало |
|------|-----------|--------------|
| **SKILL.md** | Context Anchor format | `⚙️ skill · protocol · status` → `⚙️ skill · protocol · status` + `📋 SKILL.md=EN \| README=RU \| <300` |
| **templates.md** | Context Anchor template | Без правил → С правилами |
| **evaluations.md** | Добавить inline примеры | Expected → Expected + Example Output |
| **P03-planning.md** | Визуальный blocking marker | `## ⛔ BLOCKING` → `## ═══ ⛔ BLOCKING ═══` |
| **P06-delivery-skill.md** | Визуальный blocking marker | То же |
| **P07-closure.md** | Визуальный blocking marker | То же |

### 3.3 УДАЛЯЕМ

| Что | Причина |
|-----|---------|
| ❌ Ничего | NEVER DEGRADE |

### 3.4 НЕ ТРОГАЕМ

| Что | Причина |
|-----|---------|
| Protocol flow P00-P09 | Работает |
| L1-L8 quality levels | Работает |
| Scripts (все) | Стабильны |
| 12 Critical Rules | Работает |
| 5 Clean Skill Principles | Работает |
| diff-report.md с примером | Работает |

---

## 4. Было → Стало

### 4.1 SKILL.md — PRE-BUILD CHECKPOINT (NEW)

**Было:** Нет в SKILL.md, только в P04-build.md

**Стало:**
```markdown
## ⛔ PRE-BUILD CHECKPOINT

Before ANY file creation, verify:
```
□ Plan confirmed (explicit да/yes/go)
□ SKILL.md = English
□ README.md = User's language  
□ SKILL.md < 300 lines
□ Frontmatter valid
```

**Trigger:** After web search, long conversation, any doubt.
```

### 4.2 SKILL.md — Common Mistakes (NEW)

**Было:** Нет

**Стало:**
```markdown
## ⚠️ Common Mistakes

| ❌ Mistake | ✅ Correct |
|------------|------------|
| README.md in English | README.md in user's language |
| Proceed on "ок понял" | Wait for explicit "да/yes/go" |
| Skip Diff Report | Always create before delivery |
| Remove without reason | NEVER DEGRADE — ask first |
| Mixed languages in SKILL.md | English only |
| Forget version in footer | All footers = current version |
```

### 4.3 Context Anchor — Enhanced (UPDATE)

**Было:**
```
⚙️ skill-architect · P04 · building
🟢 ~80k | ~20k 🟡
```

**Стало:**
```
⚙️ skill-architect v8.4.0 · P04 · building
📋 SKILL.md=EN | README=RU | <300 lines
🟢 ~80k | ~20k 🟡
```

### 4.4 P00-router.md — Enhanced Recovery (UPDATE)

**Было:**
```markdown
## Recovery

If state unclear:
1. Ask user: "Where were we?"
2. Check /home/claude/ for artifacts
3. Check /mnt/user-data/outputs/ for deliverables
4. Resume from last confirmed state
```

**Стало:**
```markdown
## Recovery

### After Context Loss (web search, long conversation)

1. **Re-read SKILL.md** — especially:
   - ⛔ CRITICAL RULES (all 12)
   - ⛔ PRE-BUILD CHECKPOINT
   - ⚠️ Common Mistakes

2. **Verify current constraints:**
   □ SKILL.md = English
   □ README.md = User's language
   □ < 300 lines limit
   □ Frontmatter valid

3. **Check protocol state:**
   - Last blocking point passed?
   - Explicit confirmation received?

4. **Resume from last confirmed state**

### If Artifacts Exist

```bash
ls /home/claude/[skill-name]/
ls /mnt/user-data/outputs/
```

### Recovery Trigger Words

| User says | Action |
|-----------|--------|
| "где мы остановились" | Full recovery check |
| "продолжи" | Verify state, continue |
| "что дальше" | State summary, next step |
```

### 4.5 Protocol Self-Check (NEW in ALL protocols)

**Добавить в конец каждого P0X файла:**

```markdown
---

## Self-Check Before Next Protocol

Before proceeding, verify:

□ Current protocol objectives met?
□ NEVER DEGRADE respected?
□ SKILL.md still in English?
□ Blocking confirmation received (if required)?
□ All changes logged for Diff Report?

---
```

### 4.6 Blocking Point Visual Marker (UPDATE)

**Было:**
```markdown
## ⛔ BLOCKING

Cannot proceed without confirmation.
```

**Стало:**
```markdown
## ════════════════════════════════════════════════
## ⛔ BLOCKING — EXPLICIT CONFIRMATION REQUIRED
## ════════════════════════════════════════════════

**Valid:** "да", "yes", "go", "делай", "proceed"
**Invalid:** "ок", "понял", "хорошо", "ясно"

Cannot proceed without explicit confirmation.
```

### 4.7 evaluations.md — Inline Examples (UPDATE)

**Было (E-001):**
```markdown
**Criteria:**
- [ ] SKILL.md in English, < 300 lines
- [ ] README.md in Russian
...
```

**Стало (E-001):**
```markdown
**Criteria:**
- [ ] SKILL.md in English, < 300 lines
- [ ] README.md in Russian
...

**Example Output (P03 Planning):**

```markdown
## api-tester: План v0.0.0 → v1.0.0

| Parameter | Value |
|-----------|-------|
| Purpose | Generate API tests from OpenAPI spec |
| Triggers | test api, api tests, тесты апи |
| Mode | Tool |
| Complexity | Medium |

### Chat Verification
✅ Purpose: API test generation
✅ Triggers: test api, api tests
✅ Mode: Tool (creates instruments)

Ожидаю подтверждение: "да", "yes", "go"

⚙️ skill-architect v8.4.0 · P03 · awaiting confirmation
📋 SKILL.md=EN | README=RU | <300 lines
🟢 ~75k | ~25k 🟡
```
```

### 4.8 reference/retrospective.md (NEW)

**Было:** Нет файла

**Стало:** Перенести из V1 docs `09-RETROSPECTIVE.md` в reference/ (краткая версия):

```markdown
# Retrospective: skill-architect Evolution

Key learnings from 18 versions (v5.3.0 → v8.3.0).

---

## Timeline

| Version | Change | Impact |
|---------|--------|--------|
| v3.9.0 | Golden standard | 223 lines, all works |
| v4.0.0 | "Unified Workflow" | 🔴 Lost specificity |
| v5.1.0 | "Restoration" | ✅ Recovered from v3.9.0 |
| v6.0.0 | Protocol-Driven | ✅ Modular architecture |
| v8.2.0 | "Lean Core" | ✅ -60% size, L7 added |
| v8.3.0 | "Restoration+" | ✅ Active prompts restored |
| v8.4.0 | "Golden Standard" | ✅ Context drift protection |

---

## Critical Lessons

### 1. NEVER DEGRADE
Removing functionality = quality loss. Always ADD alongside.

### 2. Specific > Abstract
Two specific protocols > one abstract table.

### 3. Claude Knows More Than You Think
40%+ of content was redundant — Claude knows it natively.

### 4. Self-Audit Regularly
Skill must pass its own validation.

### 5. Context Drifts
After web search or long conversations, Claude may forget rules.
→ Solution: PRE-BUILD CHECKPOINT + Enhanced Context Anchor

---

## Anti-patterns

| ❌ Pattern | ✅ Alternative |
|-----------|----------------|
| Unify different protocols | Keep separate with blocking points |
| Remove "unused" sections | Keep if provides context |
| Assume Claude remembers | Remind in every response |
| Silent removal | Always ask + document reason |

---

*retrospective.md v1.0.0 | skill-architect v8.4.0*
```

---

## 5. Финальная структура SKILL.md v8.4.0

```markdown
---
name: skill-architect
description: "v8.4.0 | Protocol-Driven skill/project creation with context drift protection. Triggers: create skill, create project, refactor, update, чекап, full-audit, validate."
---

# Skill Architect v8.4.0

Protocol-Driven skill and project creation with integrated testing, LLM-knowledge redundancy checks, and context drift protection.

---

## Purpose

| Field | Value |
|-------|-------|
| serves | Claude user with repeatable task |
| goal | Lean, reusable skill that works predictably |
| method | Protocols P00-P09 + validation + redundancy pruning |
| success | Skill solves task without manual control, minimal token footprint |

---

## ⛔ CRITICAL RULES

| # | Rule | Enforcement |
|---|------|-------------|
| 1 | SKILL.md = English only | validate-skill.sh |
| 2 | SKILL.md < 300 lines | validate-skill.sh |
| 3 | Frontmatter: name + description + version | validate-skill.sh |
| 4 | README.md required | validate-skill.sh |
| 5 | MANIFEST.md if reference/ exists | validate-skill.sh |
| 6 | Planning Document before changes | P03 ⛔ |
| 7 | Chat Verification in plan | P03 |
| 8 | Diff Report after changes | P06 ⛔ |
| 9 | NEVER remove working functionality | P04 |
| 10 | NEVER replace specific with abstract | P04 |
| 11 | Explicit confirmation required | P03 ⛔, P06 ⛔ |
| 12 | Footer versions must match | validate-skill.sh L8 |

---

## ⛔ PRE-BUILD CHECKPOINT

Before ANY file creation, verify:

```
□ Plan confirmed (explicit да/yes/go)
□ SKILL.md = English
□ README.md = User's language
□ SKILL.md < 300 lines
□ Frontmatter valid
```

**Trigger:** After web search, long conversation, any doubt.

---

## ⚠️ Common Mistakes

| ❌ Mistake | ✅ Correct |
|------------|------------|
| README.md in English | README.md in user's language |
| Proceed on "ок понял" | Wait for explicit "да/yes/go" |
| Skip Diff Report | Always create before delivery |
| Remove without reason | NEVER DEGRADE — ask first |
| Mixed languages in SKILL.md | English only |

---

## ⛔ FIRST STEP — MANDATORY

```
file_read → /mnt/skills/user/skill-architect/reference/protocols/P00-router.md
```

Then: Read protocol for current state → Execute.

---

## Quick Activation

Response: `Skill Architect v8.4.0. Purpose? Triggers?`

Then: P02 → P03 ⛔ → P04 → P05 → P06 ⛔ → P07 ⛔

---

## ⚠️ Context Anchor

End EVERY response:
```
⚙️ skill-architect v8.4.0 · [protocol] · [status]
📋 SKILL.md=EN | README=[USER_LANG] | <300 lines
🟢 ~Xk | ~Yk 🟡
```

Token colors: >100k 🟢 | 50-100k 🟡 | <50k 🔴

---

## Protocol Router

| Trigger | Protocol | Block |
|---------|----------|-------|
| Activation | P01-activation | |
| Purpose stated | P02-config | |
| Config done | P03-planning | ⛔ |
| Plan confirmed | P04-build | |
| Build done | P05-validate | |
| Validation passed | P06-delivery | ⛔ |
| Delivered | P07-closure | ⛔ |
| Simulation | P08-simulation | opt |
| checkup/full-audit | P09-full-audit | |

**Path:** `reference/protocols/P0X-name.md`

---

## Quick Start

**Tool Mode:** `create skill: [purpose]` | `update: [changes]` | `refactor`

**Project Mode:** `create project: [name]` | `import project`

**Audit:** `checkup` | `full-audit` | `validate +vt` | `validate +full`

---

## Output

| Trigger | Deliverable |
|---------|-------------|
| create skill | .skill archive + Diff Report |
| update | Updated .skill + Diff Report |
| checkup | Full Audit Report |

---

## Key Resources

| File | Purpose |
|------|---------|
| templates.md | SKILL.md templates + frontmatter |
| packaging.md | Archive structure |
| quality-checklist.md | L1-L8 quality gates |
| diff-report.md | Diff Report format |
| evaluations.md | E-001 to E-008 test scenarios |
| retrospective.md | Evolution history & lessons |

**Protocols:** `reference/protocols/P00-P09`

**Scripts:** validate-skill.sh, update-version.sh, genetic-audit.sh

---

## Lean Principle

Claude knows: general concepts, standard patterns, common formats, programming basics.

Skill contains ONLY: custom workflows, blocking points, platform constraints, ecosystem rules.

→ See quality-checklist.md L7: Knowledge Redundancy

---

*v8.4.0 "Golden Standard" — Context drift protection, enhanced recovery, unified best practices*
```

**Оценка размера:** ~155 строк (в рамках 300)

---

## 6. Риски

| Риск | Вероятность | Impact | Mitigation |
|------|-------------|--------|------------|
| SKILL.md > 300 lines | Low | High | Текущая оценка ~155, есть запас |
| Context Anchor слишком verbose | Medium | Low | Можно сократить если мешает |
| Self-Check замедляет workflow | Low | Medium | Опциональный, не blocking |
| Retrospective устареет | Medium | Low | Обновлять при major versions |

---

## 7. Чат-верификация

**Обсуждено в этой сессии:**

| # | Тема | Источник | Статус в плане |
|---|------|----------|----------------|
| 1 | V2 полнее (12 правил vs 8) | comparison-report.md | ✅ База = V2 |
| 2 | V1 имеет RETROSPECTIVE | comparison-report.md | ✅ Добавляем retrospective.md |
| 3 | Context drift после web search | Opus analysis | ✅ PRE-BUILD CHECKPOINT |
| 4 | Нужен rule reminder в каждом ответе | Opus proposal | ✅ Enhanced Context Anchor |
| 5 | Blocking points не заметны | Opus proposal | ✅ Visual markers |
| 6 | Нет Common Mistakes | Opus proposal | ✅ Новая секция |
| 7 | Recovery protocol минимальный | Opus analysis | ✅ Enhanced Recovery |
| 8 | Self-Check нужен в протоколах | Opus proposal | ✅ Добавляем во все P0X |
| 9 | Inline примеры в evaluations | Opus proposal | ✅ Example Output секция |
| 10 | Принцип "Chat = 2-4 sentences" потерян в V1 | comparison-report.md | ✅ V2 база, все 5 принципов |

**Verified:** 10 items. **Missing:** none.

---

## 8. Effort Estimate

| Task | Time | Priority |
|------|------|----------|
| SKILL.md PRE-BUILD CHECKPOINT | 10 min | 🔴 Critical |
| SKILL.md Common Mistakes | 10 min | 🔴 Critical |
| Enhanced Context Anchor (SKILL + templates) | 15 min | 🔴 Critical |
| P00-router Enhanced Recovery | 20 min | 🔴 Critical |
| Visual blocking markers (P03, P06, P07) | 15 min | 🟡 Important |
| Self-Check sections (all protocols) | 30 min | 🟡 Important |
| reference/retrospective.md (NEW) | 20 min | 🟡 Important |
| evaluations.md inline examples | 25 min | 🟢 Nice-to-have |
| All footer sync to v8.4.0 | 15 min | 🟢 Nice-to-have |
| Testing & self-validation | 45 min | 🔴 Critical |
| Packaging & docs | 30 min | 🔴 Critical |
| **Total** | **~4 hours** | |

---

## 9. Deliverables

| # | Deliverable | Format |
|---|-------------|--------|
| 1 | skill-architect-v8.4.0.skill | .skill archive |
| 2 | skill-architect-v8.4.0-docs.zip | docs archive |
| 3 | Diff Report v8.3.0 → v8.4.0 | в docs |

---

## 10. Чеклист подтверждения

- [ ] План понятен
- [ ] PRE-BUILD CHECKPOINT добавляется
- [ ] Enhanced Context Anchor согласован
- [ ] Common Mistakes полезны
- [ ] Recovery protocol достаточен
- [ ] Visual blocking markers не избыточны
- [ ] retrospective.md нужен
- [ ] NEVER DEGRADE соблюдён (ничего не удаляем)
- [ ] Риски приемлемы
- [ ] Можно начинать

---

## Key Principle

> **"Golden Standard" = V2 полнота + V1 история + Opus механизмы защиты**
>
> - 12 Critical Rules из V2
> - Все 5 Clean Skill Principles из V2
> - L1-L8 качества из V2
> - RETROSPECTIVE из V1
> - PRE-BUILD CHECKPOINT для context drift (NEW)
> - Enhanced Context Anchor для постоянного reminder (NEW)
> - Self-Check для самопроверки (NEW)

---

**⚙️ skill-architect · P03-planning · awaiting confirmation**

Ожидаю подтверждение: **"да"**, **"yes"**, **"go"**, **"делай"**

---

*skill-architect v8.3.0 → v8.4.0 "Golden Standard" Planning Document*
*Based on: V1/V2 comparison + Claude Opus enhancement proposals*

*03-PLAN.md | skill-architect v8.4.0*
