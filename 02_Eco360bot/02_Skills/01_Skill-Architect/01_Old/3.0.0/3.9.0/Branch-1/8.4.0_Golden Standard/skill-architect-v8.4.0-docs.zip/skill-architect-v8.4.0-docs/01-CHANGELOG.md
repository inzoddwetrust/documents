# Changelog

All notable changes to Skill Architect.

---

## [8.4.0] - 2025-12-12 "Golden Standard"

### Added
- **SKILL.md**: ⛔ PRE-BUILD CHECKPOINT section (context drift protection)
- **SKILL.md**: ⚠️ Common Mistakes table
- **SKILL.md**: Enhanced Context Anchor with rule reminder line
- **retrospective.md**: Evolution history from 18+ versions (from V1 docs)
- **All protocols**: Self-Check section before next protocol
- **P00-router.md**: Enhanced Recovery Protocol for context loss

### Changed
- **Context Anchor**: Now includes rule reminder `📋 SKILL.md=EN | README=[LANG] | <300 lines`
- **Blocking markers**: Visual enhancement `════ ⛔ BLOCKING ════`
- **templates.md**: Updated Context Anchor template with rule reminder
- **evaluations.md**: Added inline example output for E-001

### Fixed
- All footers synced to v8.4.0
- P01-activation version updated to v8.4.0

### Technical
- Base: V2 (v8.3.0 full version with 12 rules, L1-L8, all 5 principles)
- Added: V1 retrospective.md
- New: Context drift protection mechanisms
- 45 files total (+1 retrospective.md)
- ~5500 lines total

---

## [8.3.0] - 2025-12-12 "Restoration+"

### Added
- **diff-report.md**: Restored Diff Report format (was lost in v5→v8)
- **evaluations.md**: E-001 to E-008 test scenarios (was deleted)
- **update-version.sh**: Footer sync automation script
- **quality-checklist.md**: L8 Version Integrity layer
- **validate-skill.sh**: L8 Version Integrity check
- **P02-config.md**: "Questions to Ask" section
- **SKILL.md**: Quick Activation reference

### Fixed
- **P01-activation.md**: Active "Purpose?" prompt (was passive)
- **P04-build.md**: Restored Clean Skill Principle #3 "Chat = 2-4 sentences"
- **P06-delivery-skill.md**: Explicit reference to diff-report.md
- **SKILL.md**: Consolidated 12 Critical Rules in one table

### Restored (from v3.9.0-v4.1.0)
- Diff Report format with metrics table
- Active Purpose? question on activation
- Full 5 Clean Skill Principles
- evaluations.md with test scenarios

### Technical
- All footers synced to v8.3.0
- 44 files total (+3 new)
- ~5200 lines total

---

## [8.2.2] - 2025-12-12 "Package Guard"

### Added
- **packaging.md**: ⛔ BEFORE PACKAGING — MANDATORY section
- **packaging.md**: Post-packaging verify commands (file + unzip -t)
- **validate-skill.sh**: ZIP format validation (prevents tar+gzip mistake)
- **P06-delivery-skill.md**: Pre-packaging checklist

### Fixed
- Prevented "Invalid zip file" errors from tar+gzip usage
- Prevented wrong folder names (without version) in archives
- Prevented temp files (DIFF-REPORT) in .skill packages

### Technical
- validate-skill.sh v1.6 → v1.7
- packaging.md v2.0.0 → v2.1.0
- P06-delivery-skill.md v1.3.0 → v1.4.0

---

## [8.2.1] - 2025-12-11

### Added
- Frontmatter key validation in validate-skill.sh
- SSOT check script

### Fixed
- Version sync validation

---

## [8.2.0] - 2025-12-10 "Lean Core"

### Added
- L7 Knowledge Redundancy checks
- Aggressive pruning protocols
- Frontmatter validation

---

*CHANGELOG.md | skill-architect v8.4.0*

*01-CHANGELOG.md | skill-architect v8.4.0*
