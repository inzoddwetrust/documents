# Skill-Architect: План v8.2.1 → v8.2.2

**Date:** 2025-12-12
**Context:** Post-mortem анализ ошибок упаковки в сессии landing-studio
**Type:** Patch — Bug fixes + safety guards

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | User's language |
| Frontmatter | name + description + version |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

В сессии landing-studio v4.3.1 произошли 5 ошибок упаковки:

1. **tar+gzip вместо zip** — "Invalid zip file"
2. **Папка без версии** — `landing-studio/` вместо `landing-studio-v4.3.1/`
3. **Лишний DIFF-REPORT.md в .skill**
4. **Ложная проверка** — tar -tv показал файлы, но формат неверный
5. **Пропуск чтения packaging.md** — положился на память

Несмотря на существующую документацию (packaging.md строка 54 говорит `zip -r`), ошибка повторилась.

---

## 2. Проблемы / Задачи

| # | Проблема | Корневая причина | Решение |
|---|----------|------------------|---------|
| 1 | tar вместо zip | Нет MANDATORY read | Добавить ⛔ секцию |
| 2 | Неверное имя папки | Нет pre-flight check | Добавить checklist |
| 3 | Лишние файлы | Нет whitelist | Добавить список файлов |
| 4 | Ложная проверка | validate-skill.sh не проверяет формат | Добавить file check |
| 5 | Пропуск reference | Нет enforcement | Добавить в P06 |

---

## 3. План изменений

### Добавляем

**packaging.md:**
```markdown
## ⛔ BEFORE PACKAGING — MANDATORY

1. Read this file completely
2. Verify: folder name = skill-name-vX.Y.Z
3. Verify: ONLY these files:
   - SKILL.md, README.md, MANIFEST.md, CHANGELOG.md
   - reference/, scripts/ (if exist)
   - NO: DIFF-REPORT, PLAN, AUDIT, temp files
4. Command: zip -r (NOT tar, NOT gzip)

## Post-Packaging Verify

```bash
# REQUIRED — run both:
file skill-name-vX.Y.Z.skill
# Expected: "Zip archive data"

unzip -t skill-name-vX.Y.Z.skill
# Expected: "No errors detected"
```
```

**validate-skill.sh:**
```bash
# Add after line 230 (archive validation):
FILE_TYPE=$(file "$ARCHIVE" 2>/dev/null)
if ! echo "$FILE_TYPE" | grep -q "Zip archive"; then
    echo -e "${RED}❌ NOT a ZIP archive! Got: $FILE_TYPE${NC}"
    echo "   Use: zip -r name.skill folder/"
    echo "   NOT: tar + gzip"
    ((ERRORS++))
fi
```

**P06-delivery-skill.md:**
```markdown
## ⛔ Pre-Packaging Checklist

Before running zip command:

□ Read packaging.md (mandatory)
□ Folder name = skill-name-vX.Y.Z
□ Files whitelist verified:
  □ SKILL.md ✓
  □ README.md ✓
  □ MANIFEST.md (if reference/) ✓
  □ CHANGELOG.md ✓
  □ reference/ ✓
  □ NO temp files (DIFF, PLAN, AUDIT)
□ Command ready: zip -r (not tar)
```

### Изменяем

| File | Change |
|------|--------|
| packaging.md | +⛔ MANDATORY section, +verify commands |
| validate-skill.sh | +ZIP format check |
| P06-delivery-skill.md | +pre-packaging checklist |
| SKILL.md footer | v8.2.1 → v8.2.2 |

### Удаляем

Ничего.

### Не трогаем

- Все протоколы P00-P05, P07-P09
- templates.md, quality-checklist.md
- genetic-audit.sh, full-audit.sh
- SKILL.md structure (только версию)

---

## 4. Было → Стало

### packaging.md

**Было (49-58):**
```markdown
## Commands

```bash
# Create archive
cd /home/claude
zip -r skill-name-vX.Y.Z.skill skill-name-vX.Y.Z/
```

**Стало:**
```markdown
## ⛔ BEFORE PACKAGING — MANDATORY

1. Read this file completely
2. Verify folder = skill-name-vX.Y.Z
3. Verify files whitelist (no temp files)
4. Use: zip -r (NOT tar)

---

## Commands

```bash
# Create archive
cd /home/claude
zip -r skill-name-vX.Y.Z.skill skill-name-vX.Y.Z/

# REQUIRED verification:
file skill-name-vX.Y.Z.skill        # Must show: Zip archive
unzip -t skill-name-vX.Y.Z.skill    # Must show: No errors
```

---

## 5. Риски

| Риск | Вероятность | Митигация |
|------|-------------|-----------|
| Увеличение packaging.md | Низкая | +20 lines max |
| validate-skill.sh breaks | Низкая | Тестируем на landing-studio.skill |
| Overhead на упаковку | Приемлемая | 30 сек экономит повторную работу |

---

## 6. Чат-верификация

**Verified items from conversation:**

1. ✅ ERROR-1: tar+gzip вместо zip
2. ✅ ERROR-2: Папка без версии
3. ✅ ERROR-3: DIFF-REPORT в .skill
4. ✅ ERROR-4: Ложная проверка (tar -tv)
5. ✅ ERROR-5: Пропуск чтения packaging.md
6. ✅ FIX-1: ⛔ MANDATORY секция
7. ✅ FIX-2: verify commands
8. ✅ FIX-3: validate-skill.sh check
9. ✅ FIX-4: P06 checklist

**Verified: 9 items. Missing: none**

---

## 7. Чеклист подтверждения

- [ ] План понятен
- [ ] Изменения согласованы
- [ ] Риски приемлемы
- [ ] NEVER DEGRADE — функционал сохранён
- [ ] Можно начинать

---

## Deliverables

После обновления:
- `skill-architect-v8.2.2.skill` — обновлённый скилл
- `skill-architect-v8.2.2-docs.zip` — документация
- Тест на landing-studio-v4.3.1.skill

---

**⛔ Ожидаю подтверждение: "да", "yes", "go", "делай"**

---

*PLAN-v8.2.2.md | skill-architect v8.2.1*
