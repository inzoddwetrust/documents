# Backlog: skill-architect

## Current Version: v8.2.2

---

## Completed (v8.2.x)

- [x] ZIP format validation in validate-skill.sh
- [x] Pre-packaging checklist in P06
- [x] MANDATORY section in packaging.md
- [x] Post-packaging verify commands
- [x] Frontmatter key validation
- [x] L7 Knowledge Redundancy checks

---

## Backlog

### High Priority

| Item | Description | Estimate |
|------|-------------|----------|
| Auto-packaging | Script to run full packaging flow | v8.3.0 |
| Version bump script | Auto-update all version references | v8.3.0 |

### Medium Priority

| Item | Description | Estimate |
|------|-------------|----------|
| Project mode testing | More VT scenarios for projects | v8.4.0 |
| Docs auto-generation | Script for P07 docs creation | v8.4.0 |
| Archive comparison | Diff between .skill versions | v8.5.0 |

### Low Priority

| Item | Description | Estimate |
|------|-------------|----------|
| Web UI | Visual skill builder | Future |
| Import from GitHub | Skill from repo | Future |
| Multi-skill packages | Bundle skills together | Future |

---

## Technical Debt

| Item | Impact | Priority |
|------|--------|----------|
| - | - | - |

**Current debt: None** (cleaned in v8.2.2)

---

## Known Issues

| Issue | Workaround | Status |
|-------|------------|--------|
| Folder name warning with version | Expected behavior | Won't fix |

---

*05-BACKLOG.md v1.0.0 | skill-architect v8.2.2*
