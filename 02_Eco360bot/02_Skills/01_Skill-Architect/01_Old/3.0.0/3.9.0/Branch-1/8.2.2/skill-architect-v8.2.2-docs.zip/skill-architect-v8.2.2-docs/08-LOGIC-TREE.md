# Logic Tree: skill-architect v8.2.2

## Protocol Flow

```
[ACTIVATION]
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ P00: ROUTER                                                 │
│                                                             │
│ Input Analysis:                                             │
│ "create skill" → P01 → P02 → P03 → P04 → P05 → P06 → P07   │
│ "update"       → P01 → P02 → P03 → P04 → P05 → P06 → P07   │
│ "checkup"      → P09                                        │
│ "validate"     → P05                                        │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ P01: ACTIVATION                                             │
│ • Display purpose table                                     │
│ • Show context anchor                                       │
│ • Ask for purpose/task                                      │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ P02: CONFIG                                                 │
│ • Determine mode (Tool/Project)                             │
│ • Gather requirements                                       │
│ • Define triggers                                           │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ P03: PLANNING                                               │
│ • Create plan document                                      │
│ • Chat verification                                         │
│ • ⛔ WAIT for explicit confirmation                         │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ P04: BUILD                                                  │
│ • Verify NEVER DEGRADE                                      │
│ • Create/update files                                       │
│ • Follow plan exactly                                       │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ P05: VALIDATE                                               │
│ • Run validate-skill.sh                                     │
│ • Check L1-L7 quality gates                                 │
│ • Create DIFF report                                        │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ P06: DELIVERY                                               │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ ⛔ PRE-PACKAGING CHECKLIST (v8.2.2)                     │ │
│ │ □ Read packaging.md                                     │ │
│ │ □ Folder name = skill-name-vX.Y.Z                       │ │
│ │ □ Files whitelist verified                              │ │
│ │ □ Command: zip -r (NOT tar)                             │ │
│ └─────────────────────────────────────────────────────────┘ │
│ • Create .skill package                                     │
│ • ⛔ Verify: file + unzip -t                               │
│ • Deliver to user                                           │
│ • ⛔ WAIT for confirmation                                  │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ P07: CLOSURE                                                │
│ • Run scans                                                 │
│ • Generate 8 docs files                                     │
│ • Package docs.zip                                          │
│ • Offer P08 simulation                                      │
└─────────────────────────────────────────────────────────────┘
    │
    ├──────────────────────┐
    ▼                      ▼
┌───────────────┐    ┌─────────────────┐
│ P08:          │    │ END SESSION     │
│ SIMULATION    │    │                 │
│ (optional)    │    │                 │
└───────────────┘    └─────────────────┘
```

---

## Packaging Flow (v8.2.2)

```
[BEFORE PACKAGING]
    │
    ▼
┌─────────────────────────────────────────┐
│ ⛔ READ packaging.md (MANDATORY)        │
│                                         │
│ □ Folder = skill-name-vX.Y.Z            │
│ □ Only whitelist files                  │
│ □ No DIFF/PLAN/AUDIT                    │
│ □ Use: zip -r                           │
└─────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────┐
│ zip -r name.skill folder/               │
└─────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────┐
│ ⛔ POST-PACKAGING VERIFY                │
│                                         │
│ file name.skill                         │
│ → Must show: "Zip archive data"         │
│                                         │
│ unzip -t name.skill                     │
│ → Must show: "No errors detected"       │
└─────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────┐
│ cp name.skill /mnt/user-data/outputs/   │
└─────────────────────────────────────────┘
    │
    ▼
[DELIVER TO USER]
```

---

## Blocking Points

| Protocol | Blocking Point | Resolution |
|----------|----------------|------------|
| P03 | Plan confirmation | Explicit "да/yes/go" |
| P06 | Pre-packaging checklist | Complete all checks |
| P06 | Post-packaging verify | file + unzip -t pass |
| P06 | User confirmation | Before P07 |
| P07 | All 8 docs created | Complete docs.zip |

---

*08-LOGIC-TREE.md v1.0.0 | skill-architect v8.2.2*
