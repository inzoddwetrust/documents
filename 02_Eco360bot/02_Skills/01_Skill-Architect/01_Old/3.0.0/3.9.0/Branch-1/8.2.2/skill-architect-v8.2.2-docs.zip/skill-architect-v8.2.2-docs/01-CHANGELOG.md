# Changelog

All notable changes to Skill Architect.

---

## [8.2.2] - 2025-12-12 "Package Guard"

### Added
- **packaging.md**: ⛔ BEFORE PACKAGING — MANDATORY section
- **packaging.md**: Post-packaging verify commands (file + unzip -t)
- **validate-skill.sh**: ZIP format validation (prevents tar+gzip mistake)
- **P06-delivery-skill.md**: Pre-packaging checklist

### Fixed
- Prevented "Invalid zip file" errors from tar+gzip usage
- Prevented wrong folder names (without version) in archives
- Prevented temp files (DIFF-REPORT) in .skill packages

### Technical
- validate-skill.sh v1.6 → v1.7
- packaging.md v2.0.0 → v2.1.0
- P06-delivery-skill.md v1.3.0 → v1.4.0

---

## [8.2.1] - 2025-12-11

### Added
- Frontmatter key validation in validate-skill.sh
- SSOT check script

### Fixed
- Version sync validation

---

## [8.2.0] - 2025-12-10 "Lean Core"

### Added
- L7 Knowledge Redundancy checks
- Aggressive pruning protocols
- Frontmatter validation

---

*CHANGELOG.md | skill-architect v8.2.2*
