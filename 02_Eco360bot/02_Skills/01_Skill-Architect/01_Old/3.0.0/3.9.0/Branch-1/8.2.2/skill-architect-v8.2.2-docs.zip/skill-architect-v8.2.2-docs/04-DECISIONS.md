# Architectural Decisions: skill-architect v8.2.2

## ADR-001: Protocol-Driven Architecture

**Decision:** All operations follow numbered protocols P00-P09.

**Rationale:**
- Predictable behavior across sessions
- Easy to debug and improve
- Self-documenting workflow

**Status:** Active since v1.0.0

---

## ADR-002: SKILL.md < 300 Lines

**Decision:** Hard limit on main file size.

**Rationale:**
- Forces density over verbosity
- Reduces token consumption
- Complex content → reference/

**Status:** Active since v6.0.0

---

## ADR-003: ZIP Format for .skill

**Decision:** Use ZIP (not tar+gzip) for archives.

**Rationale:**
- Platform compatibility
- Claude.ai expects ZIP
- Easier validation with `unzip -t`

**Status:** Enforced since v8.2.2

---

## ADR-004: Mandatory Pre-Packaging Read

**Decision:** Claude MUST read packaging.md before every packaging operation.

**Rationale:**
- Prevents "Invalid zip file" errors
- Memory is unreliable for procedures
- Documents change between versions

**Status:** Active since v8.2.2

---

## ADR-005: Post-Packaging Verification

**Decision:** `file` + `unzip -t` required after every packaging.

**Rationale:**
- Catches format errors before delivery
- User never sees broken archives
- Quick sanity check

**Status:** Active since v8.2.2

---

*04-DECISIONS.md v1.0.0 | skill-architect v8.2.2*
