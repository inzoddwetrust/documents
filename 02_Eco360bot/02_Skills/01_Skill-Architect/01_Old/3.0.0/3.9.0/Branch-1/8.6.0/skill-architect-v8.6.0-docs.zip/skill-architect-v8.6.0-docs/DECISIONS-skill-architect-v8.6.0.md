# DECISIONS: skill-architect v8.6.0

Architectural Decision Records. Cumulative from v8.6.0+.

---

## v8.6.0 Decisions (inherited)

### AD-001: PRE-BUILD CHECKPOINT в SKILL.md

**Context:** Claude теряет контекст после web search.  
**Decision:** Секция `⛔ PRE-BUILD CHECKPOINT` в SKILL.md.  
**Consequences:** +12 строк, критически важно.

### AD-002: Enhanced Context Anchor

**Context:** Стандартный Context Anchor не напоминает правила.  
**Decision:** Вторая строка `📋 SKILL.md=EN | README=[LANG] | <300`.  
**Consequences:** Минимальный overhead, максимальная польза.

### AD-003: Self-Check в протоколах

**Context:** Нет самопроверки между протоколами.  
**Decision:** `## Self-Check` в конце каждого P0X.  
**Consequences:** +10-15 строк на протокол.

### AD-004: Visual Blocking Markers

**Context:** `## ⛔ BLOCKING` легко пропустить.  
**Decision:** `════ ⛔ BLOCKING ════` visual markers.  
**Consequences:** Значительно заметнее.

### AD-005: retrospective.md

**Context:** V1 имела историю эволюции.  
**Decision:** `reference/retrospective.md` с timeline и lessons.  
**Consequences:** +140 строк, контекст "почему так".

### AD-006: Common Mistakes в SKILL.md

**Context:** Типичные ошибки повторяются.  
**Decision:** Таблица `## ⚠️ Common Mistakes` с ❌/✅.  
**Consequences:** +10 строк, предотвращает ошибки.

### AD-007: База = V2, не V1

**Context:** Две версии v8.6.0.  
**Decision:** V2 как база (12 правил, L8, детальные evaluations).  
**Consequences:** Более полная база.

---

## v8.6.0 Decisions (new)

### AD-008: Naming Convention для документов

**Context:** README.md и CHANGELOG.md не уникальны в multi-skill context.

**Decision:** `{TYPE}-{skill-name}[-v{X.Y.Z}].md`
- Root: README-skill-architect.md, CHANGELOG-skill-architect.md
- Versioned: DIFF-skill-architect-v8.6.0.md

**Alternatives:**
- Generic names (README.md) → confusion in multi-skill
- Numbered prefixes (01-README.md) → не переносится

**Consequences:** Ясность в любом контексте.

### AD-009: Версионный архив docs/vX.Y.Z/

**Context:** Документы теряются между версиями.

**Decision:** `docs/vX.Y.Z/` folder с версионированными docs.

**Alternatives:**
- Inline in reference/ → loses version tracking
- Separate repo → complexity

**Consequences:** History preserved, SKILL.md stays minimal.

### AD-010: L9 Documentation quality gate

**Context:** Нет enforcement для documentation standards.

**Decision:** L9 в quality-checklist.md:
- README-{name}.md exists
- CHANGELOG-{name}.md exists
- docs/vX.Y.Z/ structure
- Naming convention
- Footer consistency

**Alternatives:**
- Optional documentation → inconsistency
- No validation → drift

**Consequences:** Documentation is enforced.

### AD-011: generate-docs.sh для automation

**Context:** Manual doc creation error-prone.

**Decision:** Script generates 7 template docs with correct naming.

**Alternatives:**
- Manual creation → errors, inconsistency
- No templates → blank slate every time

**Consequences:** Consistent starting point. ⚠️ Templates only — must preserve existing content!

---

## Decision Principles

1. **Visibility over brevity** — лучше видно, чем кратко
2. **Explicit over implicit** — явно лучше неявного
3. **Prevention over correction** — предотвратить лучше, чем исправлять
4. **NEVER DEGRADE** — только добавляем, не удаляем

---

*DECISIONS-skill-architect-v8.6.0.md | skill-architect v8.6.0*
