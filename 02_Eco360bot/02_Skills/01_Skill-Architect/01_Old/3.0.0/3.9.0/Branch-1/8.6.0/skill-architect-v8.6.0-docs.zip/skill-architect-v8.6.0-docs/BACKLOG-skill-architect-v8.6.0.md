# BACKLOG: skill-architect v8.6.0

Текущий backlog после релиза v8.6.0 "Docs Architect".

---

## ✅ Закрыто в v8.6.0

| ID | Item | Status |
|----|------|--------|
| B-035 | Documentation system | ✅ Done |
| B-035a | generate-docs.sh script | ✅ Done |
| B-035b | validate-docs.sh v2.0 | ✅ Done |
| B-035c | docs-system.md reference | ✅ Done |
| B-035d | L9 Documentation quality gate | ✅ Done |
| B-035e | Naming convention | ✅ Done |
| B-035f | docs/vX.Y.Z/ structure | ✅ Done |

---

## ✅ Закрыто в v8.6.0 (inherited)

| ID | Item | Status |
|----|------|--------|
| B-020 | PRE-BUILD CHECKPOINT в SKILL.md | ✅ Done |
| B-021 | Enhanced Context Anchor | ✅ Done |
| B-022 | Common Mistakes секция | ✅ Done |
| B-023 | Self-Check в протоколах | ✅ Done |
| B-024 | Visual blocking markers | ✅ Done |
| B-025 | retrospective.md | ✅ Done |
| B-026 | Enhanced Recovery в P00 | ✅ Done |
| B-027 | Inline примеры в evaluations | ✅ Done (E-001) |

---

## 📋 Открытый Backlog

### 🔴 High Priority (from v8.6.0 simulation)

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-036 | **validate-degrade.sh** — NEVER DEGRADE enforcement | v8.6.0 | Script to detect content loss |
| B-037 | **Move NEVER DEGRADE check** from P04 to P06/P07 | v8.6.0 | Check where comparison possible |
| B-038 | **generate-docs.sh update mode** — require prev docs | v8.6.0 | Prevent template overwrite |
| B-039 | **P08 create PATCH document** when issues found | v8.6.0 | Document issues for next release |

### 🟡 Medium Priority

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-028 | Inline примеры для E-002 to E-008 | v8.6.0 | Только E-001 сделан |
| B-029 | Auto-detect context drift | v8.6.0 | Механизм определения потери контекста |
| B-040 | Protocol footers update to v8.6.0 | v8.6.0 | 9 of 10 still show v8.6.0 |

### 🟢 Low Priority

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-017 | Project Mode evaluations расширить | v8.6.0 | E-006, E-007, E-008 базовые |
| B-030 | Multi-skill dependency graph | v8.6.0 | skill-architect порождает child skills |
| B-031 | Real-time token counter integration | v8.6.0 | Интеграция с платформой |
| B-032 | Shared reference library | v8.6.0 | Общие паттерны в отдельный skill |
| B-033 | Skill versioning strategy doc | v8.6.0 | Когда MAJOR/MINOR/PATCH |

---

## 🐛 Known Issues

| ID | Issue | Workaround |
|----|-------|------------|
| I-004 | genetic-audit.sh exit code 1 при partial pass | Manual check |
| I-005 | validate-skill.sh не проверяет YAML syntax | Manual check |
| I-006 | Cyrillic in SKILL.md examples ("да/yes/go") | Documented, acceptable |
| I-007 | generate-docs.sh creates templates that can overwrite content | Use update mode (B-038) |

---

## 📊 Backlog Stats

| Category | Count |
|----------|-------|
| High Priority | 4 |
| Medium Priority | 3 |
| Low Priority | 5 |
| Known Issues | 4 |
| **Total Open** | **16** |

---

## Next Release Focus (v8.6.0)

Primary: B-036, B-037, B-038, B-039 — NEVER DEGRADE enforcement

---

*BACKLOG-skill-architect-v8.6.0.md | skill-architect v8.6.0*
