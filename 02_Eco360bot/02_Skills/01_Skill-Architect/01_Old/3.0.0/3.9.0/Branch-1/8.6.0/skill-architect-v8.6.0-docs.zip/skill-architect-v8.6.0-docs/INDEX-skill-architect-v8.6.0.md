# INDEX: skill-architect v8.6.0 Documentation

**Generated:** 2025-12-12

---

## Document Map

| # | Document | Purpose |
|---|----------|---------|
| 1 | INDEX-skill-architect-v8.6.0.md | Navigation |
| 2 | PLAN-skill-architect-v8.6.0.md | Release planning |
| 3 | DIFF-skill-architect-v8.6.0.md | Version changes |
| 4 | DECISIONS-skill-architect-v8.6.0.md | ADRs |
| 5 | BACKLOG-skill-architect-v8.6.0.md | Open items |
| 6 | SCAN-skill-architect-v8.6.0.md | Validation |
| 7 | LOGIC-TREE-skill-architect-v8.6.0.md | Flow diagram |

---

## Naming Convention

```
{TYPE}-{skill-name}[-v{X.Y.Z}].md
```

| Type | Versioned | Purpose |
|------|-----------|---------|
| README | No | User documentation |
| CHANGELOG | No | Cumulative history |
| PLAN | Yes | Release planning |
| DIFF | Yes | Version changes |
| DECISIONS | Yes | ADRs |
| BACKLOG | Yes | Open items |
| SCAN | Yes | Validation |
| LOGIC-TREE | Yes | Flow diagram |

---

*INDEX-skill-architect-v8.6.0.md | skill-architect v8.6.0*
