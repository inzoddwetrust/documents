# skill-architect: План v8.5.0 → v8.6.0

**Дата:** 2025-12-12  
**Источник:** PATCH-skill-architect-v8.6.0.md (результат P08 симуляции)

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | Русский |
| Frontmatter | name + description + version |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

Симуляция v8.5.0 (P08) выявила критические проблемы с защитой NEVER DEGRADE. Правило существует, но не имеет автоматического enforcement — результат: ~840 строк документации было потеряно в v8.5.0.

---

## 2. Проблемы (из PATCH)

### 🔴 CRITICAL

| # | Проблема | Последствие |
|---|----------|-------------|
| ISSUE-005 | NEVER DEGRADE без automated enforcement | Правило нарушается без обнаружения |
| ISSUE-006 | Проверка в P04 (build) вместо P06/P07 | Нечего сравнивать на этапе build |
| ISSUE-002 | generate-docs.sh перезаписывает контент шаблонами | 840 строк потеряно |

### 🟡 MEDIUM

| # | Проблема |
|---|----------|
| ISSUE-001 | Footer версии v8.4.0 в 9 протоколах |
| ISSUE-003 | P08 не создаёт PATCH документ |

### 🟢 MINOR

| # | Проблема |
|---|----------|
| ISSUE-004 | Кириллица в примерах SKILL.md (допустимо) |

---

## 3. План изменений

### ✅ Добавляем

| Файл | Описание |
|------|----------|
| `scripts/validate-degrade.sh` | **НОВЫЙ** — автоматическая проверка NEVER DEGRADE |

**validate-degrade.sh функционал:**
- REQUIRE: обязательные prev docs для сравнения
- PHASE 1: проверка удалённых файлов
- PHASE 2: проверка потери объёма (>30% = violation)
- PHASE 3: проверка ключевых секций
- EXIT 1 = BLOCKING (доставка блокируется)

### ✏️ Изменяем

| Файл | Изменение |
|------|-----------|
| `SKILL.md` | Версия 8.5.0 → 8.6.0, добавить validate-degrade.sh в скрипты |
| `reference/protocols/P04-build.md` | Упростить NEVER DEGRADE до reminder |
| `reference/protocols/P06-delivery-skill.md` | Добавить ⛔ BLOCKING проверку validate-degrade.sh |
| `reference/protocols/P07-closure.md` | Добавить BLOCKING проверку для docs |
| `reference/protocols/P08-simulation.md` | Добавить создание PATCH документа |
| `scripts/generate-docs.sh` | Добавить режим update с обязательными prev docs |
| `reference/protocols/*.md` (9 файлов) | Footer v8.4.0 → v8.6.0 |

### ❌ Удаляем

Ничего не удаляем (NEVER DEGRADE).

### 🔒 Не трогаем

- `reference/` (кроме protocols)
- `docs/v8.5.0/` (история)
- `README-skill-architect.md`
- `MANIFEST.md`
- Логику существующих скриптов

---

## 4. Было → Стало

### Структура скриптов

```
scripts/
├── validate-skill.sh      (без изменений)
├── validate-docs.sh       (без изменений)
├── validate-degrade.sh    ← НОВЫЙ
├── generate-docs.sh       (+ update mode)
├── update-version.sh      (без изменений)
└── ...
```

### Защита NEVER DEGRADE

```
БЫЛО (v8.5.0):
─────────────────────────────────────
P04 (build) → "пожалуйста не удаляй" (текст)
P06 (delivery) → упаковка (без проверки!)
P07 (closure) → генерация docs (без проверки!)

СТАЛО (v8.6.0):
─────────────────────────────────────
P04 (build) → reminder только
P06 (delivery) → validate-degrade.sh ⛔ BLOCKING
P07 (closure) → validate-degrade.sh ⛔ BLOCKING
```

---

## 5. Риски

| Риск | Вероятность | Митигация |
|------|-------------|-----------|
| validate-degrade.sh false positives | Средняя | Порог 30% настраиваемый |
| Сломать существующие скрипты | Низкая | Добавляем новый, не меняем старые |
| SKILL.md > 300 строк | Низкая | Проверим после изменений |

---

## 6. Чат-верификация

Проверка всех обсуждённых пунктов:

| # | Пункт | Источник | Статус |
|---|-------|----------|--------|
| 1 | ISSUE-005: validate-degrade.sh | PATCH | ✅ В плане |
| 2 | ISSUE-006: перенос в P06/P07 | PATCH | ✅ В плане |
| 3 | ISSUE-002: generate-docs.sh update mode | PATCH | ✅ В плане |
| 4 | ISSUE-003: PATCH в P08 | PATCH | ✅ В плане |
| 5 | ISSUE-001: footer versions | PATCH | ✅ В плане |
| 6 | ISSUE-004: кириллица | PATCH | ⏭️ Skip (допустимо) |

**Verified: 5 items. Missing: none.**

---

## 7. Чеклист подтверждения

- [ ] План понятен
- [ ] Изменения согласованы
- [ ] Риски приемлемы
- [ ] Можно начинать

---

## ⛔ Ожидаю подтверждение

Скажи **"да"**, **"yes"** или **"go"** для начала build.

---

*skill-architect_PLAN_v8.6.0.md | P03-planning*
