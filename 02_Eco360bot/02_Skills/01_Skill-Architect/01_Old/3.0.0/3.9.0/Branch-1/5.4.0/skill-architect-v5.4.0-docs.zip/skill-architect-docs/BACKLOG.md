# Backlog

Future improvements and known issues for skill-architect.

---

## Active

| # | Task | Priority | Source |
|---|------|----------|--------|
| B-001 | Reduce `zip -r` mentions (11→1) | Low | ssot-check v5.4.0 |
| B-002 | Consolidate repeated section headers across reference files | Low | audit-skill v5.4.0 |
| B-003 | Mixed language cleanup (16/17 files have Cyrillic) | Medium | audit-skill v5.4.0 |
| B-004 | Large files >300 lines: engines.md, project-modules.md, workflow.md | Low | audit-skill v5.4.0 |

---

## Ideas

| # | Idea | Notes |
|---|------|-------|
| I-001 | Auto-generate MANIFEST.md from file scan | Reduce manual tracking |
| I-002 | Skill template generator script | `bash scripts/new-skill.sh name` |
| I-003 | Interactive self-test mode | Step-by-step with fixes |

---

## Done

### v5.4.0

| # | Task | Implemented |
|---|------|-------------|
| B-000 | Semantic duplicate detection | ssot-check.md, ssot-check.sh |
| B-000 | SKILL.md constraint deduplication | SSOT refactor |
| B-000 | validate-skill.sh path bug | v1.5.0 fix |

### v5.3.0

| # | Task | Implemented |
|---|------|-------------|
| — | Docs packaging protocol | docs-packaging.md |

### v5.2.0

| # | Task | Implemented |
|---|------|-------------|
| — | Post-update integrity check | self-diagnostic.md/sh |

---

*BACKLOG.md v1.0.0 | skill-architect v5.4.0*
