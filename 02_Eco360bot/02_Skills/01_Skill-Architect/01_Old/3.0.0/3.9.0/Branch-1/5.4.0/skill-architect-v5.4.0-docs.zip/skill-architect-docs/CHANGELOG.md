# Changelog

All notable changes to skill-architect.

---

## [v5.4.0] "SSOT" — 2025-12-02

### Added
- `reference/ssot-check.md` — Single Source of Truth validation protocol
- `scripts/ssot-check.sh` — automated semantic duplicate detection

### Changed
- **SKILL.md**: SSOT refactor — constraints deduplicated
  - PRE-BUILD CHECKPOINT now references Critical Rules
  - Required Files section cleaned
  - Critical Rules marked as SINGLE SOURCE
- **validate-skill.sh** v1.4 → v1.5: fixed MANIFEST path detection
- **self-diagnostic.md**: updated expected counts (15 ref, 7 scripts)
- Version sync: header now matches frontmatter

### Fixed
- validate-skill.sh:87 — incorrect file path resolution for MANIFEST entries

---

## [v5.3.0] — 2025-12-02

### Added
- `reference/docs-packaging.md` — documentation packaging guide

### Changed
- `reference/workflow.md` v1.1.0 → v1.2.0
- Footer synchronization across all files

---

## [v5.2.0] "Full Cycle" — 2025-12-02

### Added
- `reference/self-diagnostic.md` — post-update integrity verification
- `scripts/self-diagnostic.sh` — automated self-check
- Skill Dependencies section in SKILL.md

### Changed
- Enhanced Context Tracking requirements

---

## [v5.1.0] — 2025-12-02

### Added
- NEVER DEGRADE protection rule
- Restored full REFACTOR and UPDATE protocols

### Fixed
- Protocol content that was accidentally simplified

---

## [v5.0.0] "Project Mode" — 2025-12-01

### Added
- **Project Mode** — knowledge base creation
- `reference/project-mode.md`
- `reference/project-modules.md`
- `reference/project-import.md`
- `reference/project-filters.md`
- `scripts/audit-project.sh`

### Changed
- Modes section added to SKILL.md
- Reference Reading table expanded

---

## [v4.x] — Prior versions

Initial skill creation framework with Tool Mode only.

---

*CHANGELOG.md v1.0.0 | skill-architect v5.4.0*
