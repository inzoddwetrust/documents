# Logic Tree

Decision flow for skill-architect.

---

## Main Flow

```
1. ACTIVATION
   ├─ Read clean-protocol (dependency)
   ├─ Read relevant reference file
   └─ Response: "Skill Architect ready. Purpose?"

2. CONFIG
   ├─ Get: Purpose, Triggers
   ├─ Auto-derive: type, complexity, tools
   └─ Detect mode: "project" → Project Mode, else Tool Mode

3. PLAN
   ├─ Create Planning Document
   ├─ Chat Verification (scan all discussed items)
   ├─ Report verified count
   └─ WAIT for explicit confirmation

4. BUILD
   ├─ PRE-BUILD CHECKPOINT
   │   ├─ Check Critical Rules
   │   ├─ Verify NEVER DEGRADE
   │   └─ Confirm plan approved
   ├─ Implement changes
   └─ Run validators

5. VALIDATE
   ├─ bash scripts/validate-skill.sh
   ├─ bash scripts/validate-naming.sh
   ├─ bash scripts/ssot-check.sh
   └─ Create Diff Report

6. DELIVER
   ├─ Step 1: Package .skill → WAIT confirm
   ├─ Step 2: Package docs.zip → WAIT confirm
   └─ Step 3: Chat scan → update BACKLOG
```

---

## Decision Points

### D1: Mode Detection

```
Input contains "project"?
├─ YES → Project Mode
│        Read: project-mode.md, project-modules.md
└─ NO  → Tool Mode (default)
         Read: templates.md, engines.md
```

### D2: Action Type

```
Trigger word?
├─ "create skill" → New skill flow
├─ "create project" → New project flow
├─ "update" → UPDATE Protocol
├─ "refactor" → REFACTOR Protocol
├─ "self-test" → Self-diagnostic
└─ other → Ask for clarification
```

### D3: Confirmation Validity

```
User response?
├─ "да/yes/go/делай/proceed" → VALID, continue
├─ "ок/понял/хорошо" alone → INVALID, ask again
├─ Question → Answer, then re-ask
└─ Change request → Update plan, re-confirm
```

### D4: NEVER DEGRADE Check

```
Proposed change:
├─ Removes functionality? → STOP, ask override
├─ Replaces specific with abstract? → STOP, ask override
├─ No space for new? → Move to reference/, don't delete
└─ Adds new feature? → Add alongside, don't merge
```

---

## Protocol Selection

```
Change scope?
├─ New skill from scratch → SKILL.md + templates.md
├─ Minor update (typo, version) → UPDATE Protocol
├─ Major restructure → REFACTOR Protocol
├─ Add feature → UPDATE + NEVER DEGRADE
└─ Breaking change → REFACTOR + MAJOR bump
```

---

## Validation Chain

```
1. validate-skill.sh
   ├─ Structure check
   ├─ Line count < 300
   ├─ Frontmatter valid
   └─ MANIFEST files exist

2. validate-naming.sh
   ├─ Folder kebab-case
   ├─ Files lowercase
   └─ No versions in names

3. ssot-check.sh (v5.4.0+)
   ├─ Constraint duplication
   ├─ Command repetition
   └─ Section overlap
```

---

*LOGIC-TREE.md v1.0.0 | skill-architect v5.4.0*
