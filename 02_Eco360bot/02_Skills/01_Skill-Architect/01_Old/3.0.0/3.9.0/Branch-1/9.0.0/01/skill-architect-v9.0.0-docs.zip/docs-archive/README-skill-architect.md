# Skill Architect

Protocol-driven skill creation for Claude.

## Installation

Upload `skill-architect-v9.0.0.skill` to Claude.

## Commands

| Command | Description |
|---------|-------------|
| `create skill: [purpose]` | Create a new skill |
| `update: [changes]` | Modify existing skill |
| `refactor` | Restructure skill |
| `checkup` | Run full audit |

## Quick Start

```
create skill: API test generator
```

Claude will guide you through:
1. **P01-init** — Configuration gathering
2. **P02-plan** — Planning document (requires explicit confirmation)
3. **P03-build** — File creation and validation
4. **P04-deliver** — Packaging and delivery

## Confirmation Protocol

After planning, you must confirm with:
- `yes`
- `go`
- `proceed`

These are NOT accepted: "ok", "got it", "understood"

## Output Files

Every skill includes:
- `SKILL.md` — Main instruction file (< 300 lines)
- `README-{name}.md` — User documentation
- `protocols/` — Protocol files
- `reference/` — Supporting documentation
- `scripts/` — Validation and utility scripts

## Quality Gates

| Gate | Requirement |
|------|-------------|
| G1 | SKILL.md exists |
| G2 | SKILL.md < 300 lines |
| G3 | SKILL.md = English only |
| G4 | Frontmatter: name + description only |
| G5 | README-{name}.md exists |
| G6 | Explicit confirmation before build |
| G7 | NEVER DEGRADE (updates) |

## Session Indicator

Claude shows session state in every response:
- 🟢 fresh — Full capacity
- 🟡 mid — Focused responses
- 🔴 long — Consider new chat

## Version

v9.0.0 "Clean Slate"

---

*README-skill-architect.md | skill-architect v9.0.0*
