# Manifest

File index for skill-architect v9.0.0.

---

## Summary

| Category | Count |
|----------|-------|
| Core files | 4 |
| Protocols | 5 |
| Reference | 8 |
| Scripts | 5 |
| **Total** | **22** |

---

## Core Files

| File | Lines | Purpose |
|------|-------|---------|
| SKILL.md | 88 | Main instruction file |
| README-skill-architect.md | 73 | User documentation |
| CHANGELOG-skill-architect.md | 65 | Version history |
| MANIFEST.md | — | This file |

---

## Protocols

| File | Lines | Purpose |
|------|-------|---------|
| protocols/P00-router.md | 85 | State machine |
| protocols/P01-init.md | 102 | Activation + config |
| protocols/P02-plan.md | 128 | Planning ⛔ |
| protocols/P03-build.md | 140 | Build + validate |
| protocols/P04-deliver.md | 164 | Deliver + audit ⛔ |

---

## Reference

| File | Lines | Purpose |
|------|-------|---------|
| reference/quality-gates.md | 113 | G1-G7 validation |
| reference/templates.md | 263 | All templates |
| reference/session-indicator.md | 111 | Context tracking |
| reference/diff-format.md | 146 | Diff/Plan formats |
| reference/naming.md | 121 | Naming conventions |
| reference/project-mode.md | 151 | Project skills |
| reference/evaluations.md | 188 | Test scenarios |
| reference/evolution.md | 144 | History |

---

## Scripts

| File | Lines | Purpose |
|------|-------|---------|
| scripts/validate.sh | 289 | All validations |
| scripts/audit.sh | 213 | Full audit |
| scripts/generate-docs.sh | 295 | Documentation |
| scripts/package.sh | 72 | Packaging |
| scripts/update-version.sh | 72 | Version sync |

---

## Documentation (Generated)

| File | Purpose |
|------|---------|
| docs/v9.0.0/DIFF-skill-architect-v9.0.0.md | Changes |
| docs/v9.0.0/LOGIC-TREE-skill-architect-v9.0.0.md | Flow |
| docs/v9.0.0/SCAN-skill-architect-v9.0.0.md | Validation |

---

*MANIFEST.md | skill-architect v9.0.0*
