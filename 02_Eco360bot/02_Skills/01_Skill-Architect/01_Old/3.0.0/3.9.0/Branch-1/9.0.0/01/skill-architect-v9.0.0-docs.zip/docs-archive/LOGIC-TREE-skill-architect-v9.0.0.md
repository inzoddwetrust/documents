# LOGIC-TREE: skill-architect v9.0.0

Business logic flow visualization.

---

## Main Flow

```
[USER REQUEST]
      │
      ▼
   P01-init ─────────────── Activation + config
      │
      ▼
   P02-plan ⛔ ───────────── Planning + confirmation
      │                      WAIT for "yes/go/proceed"
      ▼
   P03-build ────────────── Create + validate
      │
      ▼
   P04-deliver ⛔ ────────── Package + deliver + audit
      │                      WAIT for user decision
      ▼
    [END]
```

---

## Blocking Points

| Protocol | Gate | Requires |
|----------|------|----------|
| P02-plan | G6 | "yes", "go", "proceed" |
| P04-deliver | — | User decision (audit/skip) |

---

## State Transitions

| From | Condition | To |
|------|-----------|-----|
| START | skill request | P01-init |
| P01-init | config complete | P02-plan |
| P02-plan | confirmed | P03-build |
| P02-plan | question | P02-plan |
| P03-build | validation pass | P04-deliver |
| P04-deliver | "audit" | Run audit |
| P04-deliver | "skip" | END |
| ANY | "checkup" | P04 audit |

---

## Command Routing

```
create skill: X ──► P01-init
update: X ────────► P01-init (+ snapshot)
refactor ─────────► P01-init (+ analysis)
checkup ──────────► P04 audit
```

---

## Quality Gates Flow

```
[BUILD START]
      │
      ▼
    G1 ──────── SKILL.md exists?
      │ YES
      ▼
    G2 ──────── < 300 lines?
      │ YES
      ▼
    G3 ──────── English only?
      │ YES
      ▼
    G4 ──────── Frontmatter valid?
      │ YES
      ▼
    G5 ──────── README exists?
      │ YES
      ▼
    G7 ──────── NEVER DEGRADE? (updates)
      │ YES
      ▼
[BUILD COMPLETE]
```

---

*LOGIC-TREE-skill-architect-v9.0.0.md | skill-architect v9.0.0*
