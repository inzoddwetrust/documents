# Changelog

All notable changes to skill-architect.

---

## [9.0.0] — 2025-12-12 "Clean Slate"

Complete rebuild from knowledge extraction.

### Added
- Session indicator (🟢🟡🔴) replacing token counter
- Consolidated scripts (12 → 5)
- Consolidated protocols (7 → 5)
- LOGIC-TREE as mandatory documentation

### Changed
- SKILL.md target: 80-100 lines (was 104)
- Total files: ~35 (was 70)
- Documentation types: 3 mandatory (was 7)
- English-only enforcement (was mixed)

### Removed
- Token counter (unreliable)
- P05-simulation (merged into P04)
- P06-audit (merged into P04)
- Redundant scripts
- Redundant documentation types

### Fixed
- Frontmatter validation (name + description only)
- Explicit confirmation enforcement
- NEVER DEGRADE consistency

---

## [8.7.0] — Previous

Final version before Clean Slate rebuild.

### Known Issues (Fixed in 9.0.0)
- Mixed language output
- Token counter unreliable
- Too many files (70)
- Too many scripts (12)
- Frontmatter validation issues

---

## Version History

| Version | Codename | Key Change |
|---------|----------|------------|
| 9.0.0 | Clean Slate | Complete rebuild |
| 8.7.0 | — | Pre-rebuild final |
| 8.x | — | Token tracking |
| 7.x | — | Explicit confirmation |
| 6.x | — | NEVER DEGRADE |
| 5.x | — | Quality gates |
| 4.x | — | Protocol introduction |
| 3.9.0 | — | Initial structure |

---

*CHANGELOG-skill-architect.md | skill-architect v9.0.0*
