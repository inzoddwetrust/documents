# LOGIC-TREE: skill-architect v9.0.0

Business logic flow.

---

## Main Flow

```
[START]
    │
    ▼
[P01-init] ─────────── Activation
    │
    ▼
[P02-plan] ⛔ ───────── Planning + confirmation
    │
    ▼
[P03-build] ────────── PRE-BUILD + create + validate
    │
    ▼
[P04-deliver] ⛔ ────── Package + deliver + audit
    │
    ▼
[END]
```

---

## Blocking Points

| Protocol | Gate | Requires |
|----------|------|----------|
| P02-plan | Confirmation | "yes/go/proceed" |
| P04-deliver | User decision | "audit" or "skip" |

---

## Quality Gates

| Gate | Check | Level |
|------|-------|-------|
| L1 | Structure | SKILL.md, README |
| L2 | Content | Purpose, triggers |
| L3 | Logic | State machine |
| L4 | Naming | kebab-case |
| L5 | Integration | MANIFEST |
| L6 | Testing | Flow works |
| L7 | Redundancy | No bloat |
| L8 | Versions | Sync |
| L9 | Docs | Naming |

---

## Inherited Genes

| Gene | Required |
|------|----------|
| Purpose Block | ✅ |
| Context Anchor | ✅ |
| Session Indicator | ✅ |
| Protocol-First | ✅ |
| NEVER DEGRADE | ✅ |

---

*LOGIC-TREE-skill-architect-v9.0.0.md | skill-architect v9.0.0*
