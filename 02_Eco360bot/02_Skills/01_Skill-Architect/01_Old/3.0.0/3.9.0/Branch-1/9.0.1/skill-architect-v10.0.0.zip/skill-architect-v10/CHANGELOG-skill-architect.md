# Changelog

All notable changes to skill-architect.

---

## [10.0.0] "Anchor" - 2025-01-XX

### Architecture Change
- **Anchor architecture**: State tracked in dialogue, not in Claude's "memory"
- **NEXT action**: Every anchor includes explicit instruction for next response
- **PRE-ACTION**: Every protocol starts with mandatory reads
- **EXIT CRITERIA**: Explicit routing between phases

### Changed
- SKILL.md reduced from <300 to <80 lines
- Protocols reduced to <50 lines each
- Anchor format extended with NEXT field
- Protocol format standardized: PRE-ACTION → Steps → EXIT CRITERIA

### Added
- `reference/anchor-format.md` — anchor specification
- Self-routing in every protocol
- Recovery protocol in P00-router

### Technical
- All v9.0.1 features preserved (NEVER DEGRADE)
- 38 features maintained

---

## [9.0.1] "Registry" - 2024-XX-XX

### Added
- FEATURE-REGISTRY.md requirement
- feature-registry.sh script
- NEVER DEGRADE enforcement

### Changed
- Validation includes feature tracking
- Documentation includes registry

---

## [9.0.0] - 2024-XX-XX

### Added
- Protocol-driven architecture
- P00-P04 protocols
- Context anchors

---

*CHANGELOG-skill-architect.md | skill-architect v10.0.0*
