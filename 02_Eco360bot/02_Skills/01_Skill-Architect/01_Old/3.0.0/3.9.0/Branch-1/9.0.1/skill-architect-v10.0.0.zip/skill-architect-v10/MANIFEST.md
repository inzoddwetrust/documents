# MANIFEST: skill-architect v10.0.0

## Core (C1)

| File | Purpose | Lines |
|------|---------|-------|
| SKILL.md | Entry point | <80 |
| README-skill-architect.md | User documentation | ~70 |
| MANIFEST.md | This file | ~60 |
| CHANGELOG-skill-architect.md | Version history | ~60 |

## Protocols (C2)

| File | Purpose | Lines |
|------|---------|-------|
| protocols/P00-router.md | State machine | <50 |
| protocols/P01-init.md | Activation | <50 |
| protocols/P02-plan.md | Planning (⛔) | <50 |
| protocols/P03-build.md | Building | <50 |
| protocols/P04-deliver.md | Delivery (⛔) | <50 |

## Reference (C5)

| File | Purpose |
|------|---------|
| reference/anchor-format.md | Anchor specification |
| reference/templates.md | File templates |
| reference/naming.md | Naming conventions |
| reference/quality-gates.md | Validation levels |
| reference/session-indicator.md | Session icons |
| reference/diff-format.md | Diff documentation |
| reference/evaluations.md | Testing guide |
| reference/docs-system.md | Documentation system |
| reference/genetic-audit.md | Feature tracking |
| reference/packaging.md | Packaging guide |
| reference/ssot-check.md | Single source of truth |

## Scripts (C4)

| File | Purpose |
|------|---------|
| scripts/validate.sh | Main validation |
| scripts/audit.sh | Full audit |
| scripts/feature-registry.sh | Feature tracking |
| scripts/genetic-audit.sh | Feature comparison |
| scripts/package.sh | Packaging |
| scripts/generate-docs.sh | Doc generation |
| scripts/generate-manifest.sh | Manifest generation |
| scripts/ssot-check.sh | SSOT validation |
| scripts/update-version.sh | Version update |

## Docs (C6)

| File | Purpose |
|------|---------|
| docs/v10.0.0/DIFF-skill-architect-v10.0.0.md | Changes from v9.0.1 |
| docs/v10.0.0/LOGIC-TREE-skill-architect-v10.0.0.md | Decision tree |
| docs/v10.0.0/SCAN-skill-architect-v10.0.0.md | Structure scan |
| docs/v10.0.0/FEATURE-REGISTRY-skill-architect-v10.0.0.md | Feature inventory |

---

*MANIFEST.md | skill-architect v10.0.0*
