#!/bin/bash
# validate.sh — Skill validation L1-L6 + modes
# Usage: bash validate.sh /path [--degrade /old /new] [--docs] [--naming] [--ssot]
# v1.1.0 | skill-architect v10.0.0

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SKILL_PATH="${1:-.}"
MODE="standard"
OLD_PATH=""
NEW_PATH=""
SCRIPT_DIR="$(dirname "$0")"

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --degrade)
            MODE="degrade"
            OLD_PATH="$2"
            NEW_PATH="$3"
            shift 3
            ;;
        --docs)
            MODE="docs"
            shift
            ;;
        --naming)
            MODE="naming"
            shift
            ;;
        --ssot)
            MODE="ssot"
            shift
            ;;
        *)
            SKILL_PATH="$1"
            shift
            ;;
    esac
done

ERRORS=0
WARNINGS=0

echo "═══════════════════════════════════════════════════════"
echo "           SKILL VALIDATOR v1.1.0"
echo "═══════════════════════════════════════════════════════"
echo "Path: $SKILL_PATH"
echo "Mode: $MODE"
echo ""

# ═══════════════════════════════════════════════════════
# STANDARD VALIDATION (L1-L6)
# ═══════════════════════════════════════════════════════

if [ "$MODE" = "standard" ]; then

    # L1: Structure
    echo -e "${BLUE}═══ L1: STRUCTURE ═══${NC}"
    
    if [ -f "$SKILL_PATH/SKILL.md" ]; then
        echo -e "${GREEN}  ✓ SKILL.md exists${NC}"
        
        LINES=$(wc -l < "$SKILL_PATH/SKILL.md")
        if [ "$LINES" -lt 300 ]; then
            echo -e "${GREEN}  ✓ SKILL.md < 300 lines ($LINES)${NC}"
        else
            echo -e "${RED}  ✗ SKILL.md >= 300 lines ($LINES)${NC}"
            ((ERRORS++))
        fi
    else
        echo -e "${RED}  ✗ SKILL.md not found${NC}"
        ((ERRORS++))
    fi
    
    SKILL_NAME=$(basename "$SKILL_PATH" | sed 's/-v[0-9].*//')
    
    if [ -f "$SKILL_PATH/README-$SKILL_NAME.md" ]; then
        echo -e "${GREEN}  ✓ README-$SKILL_NAME.md exists${NC}"
    elif [ -f "$SKILL_PATH/README.md" ]; then
        echo -e "${GREEN}  ✓ README.md exists${NC}"
    else
        echo -e "${RED}  ✗ README not found${NC}"
        ((ERRORS++))
    fi
    
    # L2: Content
    echo ""
    echo -e "${BLUE}═══ L2: CONTENT ═══${NC}"
    
    if [ -f "$SKILL_PATH/SKILL.md" ]; then
        if head -1 "$SKILL_PATH/SKILL.md" | grep -q "^---"; then
            echo -e "${GREEN}  ✓ Frontmatter present${NC}"
        else
            echo -e "${RED}  ✗ Frontmatter missing${NC}"
            ((ERRORS++))
        fi
        
        if grep -q "v[0-9]\+\.[0-9]\+\.[0-9]\+" "$SKILL_PATH/SKILL.md"; then
            echo -e "${GREEN}  ✓ Version found${NC}"
        else
            echo -e "${RED}  ✗ Version not found${NC}"
            ((ERRORS++))
        fi
    fi
    
    # L3: Logic
    echo ""
    echo -e "${BLUE}═══ L3: LOGIC ═══${NC}"
    
    if [ -f "$SKILL_PATH/SKILL.md" ]; then
        if grep -q "→\|Flow" "$SKILL_PATH/SKILL.md"; then
            echo -e "${GREEN}  ✓ Flow diagram present${NC}"
        else
            echo -e "${YELLOW}  ⚠ Flow diagram not found${NC}"
            ((WARNINGS++))
        fi
        
        if grep -q "⛔\|BLOCKING" "$SKILL_PATH/SKILL.md"; then
            echo -e "${GREEN}  ✓ Blocking points marked${NC}"
        else
            echo -e "${YELLOW}  ⚠ Blocking points not marked${NC}"
            ((WARNINGS++))
        fi
    fi
    
    # L4: Naming
    echo ""
    echo -e "${BLUE}═══ L4: NAMING ═══${NC}"
    
    if echo "$SKILL_NAME" | grep -qE "^[a-z][a-z0-9-]*$"; then
        echo -e "${GREEN}  ✓ Skill name is kebab-case${NC}"
    else
        echo -e "${RED}  ✗ Skill name not kebab-case: $SKILL_NAME${NC}"
        ((ERRORS++))
    fi
    
    # L5: Integration
    echo ""
    echo -e "${BLUE}═══ L5: INTEGRATION ═══${NC}"
    
    if [ -f "$SKILL_PATH/MANIFEST.md" ]; then
        echo -e "${GREEN}  ✓ MANIFEST.md exists${NC}"
    elif [ -d "$SKILL_PATH/reference" ]; then
        echo -e "${RED}  ✗ MANIFEST.md missing (required with reference/)${NC}"
        ((ERRORS++))
    fi
    
    # L6: Testing
    echo ""
    echo -e "${BLUE}═══ L6: TESTING ═══${NC}"
    
    if [ -d "$SKILL_PATH/protocols" ]; then
        PROTOCOL_COUNT=$(find "$SKILL_PATH/protocols" -name "*.md" | wc -l)
        echo -e "${GREEN}  ✓ Protocols: $PROTOCOL_COUNT files${NC}"
    fi
    
    if grep -q "yes\|go\|proceed" "$SKILL_PATH/SKILL.md" 2>/dev/null; then
        echo -e "${GREEN}  ✓ Confirmation rules defined${NC}"
    fi
fi

# ═══════════════════════════════════════════════════════
# NEVER DEGRADE MODE
# ═══════════════════════════════════════════════════════

if [ "$MODE" = "degrade" ]; then
    echo -e "${BLUE}═══ NEVER DEGRADE CHECK ═══${NC}"
    echo "Old: $OLD_PATH"
    echo "New: $NEW_PATH"
    echo ""
    
    # Phase 1: File Count
    echo -e "${BLUE}--- Phase 1: Files ---${NC}"
    
    OLD_FILES=$(find "$OLD_PATH" -name "*.md" -o -name "*.sh" 2>/dev/null | wc -l)
    NEW_FILES=$(find "$NEW_PATH" -name "*.md" -o -name "*.sh" 2>/dev/null | wc -l)
    
    if [ "$NEW_FILES" -ge "$OLD_FILES" ]; then
        echo -e "${GREEN}  ✓ Files: $OLD_FILES → $NEW_FILES${NC}"
    else
        LOST=$((OLD_FILES - NEW_FILES))
        echo -e "${RED}  ✗ Files lost: $LOST${NC}"
        ((ERRORS++))
    fi
    
    # Phase 2: Content Volume
    echo ""
    echo -e "${BLUE}--- Phase 2: Content ---${NC}"
    
    OLD_LINES=$(find "$OLD_PATH" -name "*.md" -exec cat {} \; 2>/dev/null | wc -l)
    NEW_LINES=$(find "$NEW_PATH" -name "*.md" -exec cat {} \; 2>/dev/null | wc -l)
    
    if [ "$OLD_LINES" -gt 0 ]; then
        PERCENT=$((NEW_LINES * 100 / OLD_LINES))
        if [ "$PERCENT" -ge 70 ]; then
            echo -e "${GREEN}  ✓ Content: $OLD_LINES → $NEW_LINES ($PERCENT%)${NC}"
        else
            echo -e "${RED}  ✗ Content loss >30%: $OLD_LINES → $NEW_LINES ($PERCENT%)${NC}"
            ((ERRORS++))
        fi
    fi
    
    # Phase 3: Key Sections
    echo ""
    echo -e "${BLUE}--- Phase 3: Sections ---${NC}"
    
    for section in "Flow" "Critical" "First Step" "Commands" "Confirmation" "Context Anchor"; do
        OLD_HAS=$(grep -c "$section" "$OLD_PATH/SKILL.md" 2>/dev/null || echo 0)
        NEW_HAS=$(grep -c "$section" "$NEW_PATH/SKILL.md" 2>/dev/null || echo 0)
        
        if [ "$OLD_HAS" -gt 0 ] && [ "$NEW_HAS" -eq 0 ]; then
            echo -e "${RED}  ✗ Section lost: $section${NC}"
            ((ERRORS++))
        elif [ "$OLD_HAS" -gt 0 ]; then
            echo -e "${GREEN}  ✓ $section${NC}"
        fi
    done
fi

# ═══════════════════════════════════════════════════════
# SSOT MODE
# ═══════════════════════════════════════════════════════

if [ "$MODE" = "ssot" ]; then
    echo -e "${BLUE}═══ SSOT CHECK ═══${NC}"
    
    # Try external script first
    if [ -f "$SCRIPT_DIR/ssot-check.sh" ]; then
        bash "$SCRIPT_DIR/ssot-check.sh" "$SKILL_PATH"
        exit $?
    fi
    
    # Inline SSOT check
    echo ""
    echo -e "${BLUE}--- Constraint Duplication ---${NC}"
    
    for pattern in "< 300" "BLOCKING" "MANDATORY" "Required"; do
        COUNT=$(grep -c "$pattern" "$SKILL_PATH/SKILL.md" 2>/dev/null || echo 0)
        if [ "$COUNT" -gt 3 ]; then
            echo -e "${RED}  ✗ '$pattern': $COUNT (SSOT violation)${NC}"
            ((ERRORS++))
        else
            echo -e "${GREEN}  ✓ '$pattern': $COUNT${NC}"
        fi
    done
    
    echo ""
    echo -e "${BLUE}--- Repeated Headers ---${NC}"
    
    REPEATED=$(grep -rh "^## " "$SKILL_PATH" --include="*.md" 2>/dev/null | sort | uniq -c | sort -rn | awk '$1 > 3 {print}' | head -3)
    if [ -n "$REPEATED" ]; then
        echo -e "${YELLOW}  ⚠ Repeated headers:${NC}"
        echo "$REPEATED" | sed 's/^/   /'
        ((WARNINGS++))
    else
        echo -e "${GREEN}  ✓ No excessive repetition${NC}"
    fi
fi

# ═══════════════════════════════════════════════════════
# DOCS MODE
# ═══════════════════════════════════════════════════════

if [ "$MODE" = "docs" ]; then
    echo -e "${BLUE}═══ L9: DOCUMENTATION ═══${NC}"
    
    if [ -d "$SKILL_PATH/docs" ]; then
        echo -e "${GREEN}  ✓ docs/ exists${NC}"
        
        DIFF_COUNT=$(find "$SKILL_PATH/docs" -name "DIFF-*.md" 2>/dev/null | wc -l)
        LOGIC_COUNT=$(find "$SKILL_PATH/docs" -name "LOGIC-TREE-*.md" 2>/dev/null | wc -l)
        REG_COUNT=$(find "$SKILL_PATH/docs" -name "FEATURE-REGISTRY-*.md" 2>/dev/null | wc -l)
        
        [ "$DIFF_COUNT" -gt 0 ] && echo -e "${GREEN}  ✓ DIFF: $DIFF_COUNT${NC}" || echo -e "${YELLOW}  ⚠ No DIFF${NC}"
        [ "$LOGIC_COUNT" -gt 0 ] && echo -e "${GREEN}  ✓ LOGIC-TREE: $LOGIC_COUNT${NC}" || echo -e "${YELLOW}  ⚠ No LOGIC-TREE${NC}"
        [ "$REG_COUNT" -gt 0 ] && echo -e "${GREEN}  ✓ FEATURE-REGISTRY: $REG_COUNT${NC}" || echo -e "${YELLOW}  ⚠ No FEATURE-REGISTRY${NC}"
    else
        echo -e "${YELLOW}  ⚠ docs/ not found${NC}"
        ((WARNINGS++))
    fi
fi

# ═══════════════════════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════════════════════

echo ""
echo "═══════════════════════════════════════════════════════"
echo "                    SUMMARY"
echo "═══════════════════════════════════════════════════════"
echo -e "Errors:   ${RED}$ERRORS${NC}"
echo -e "Warnings: ${YELLOW}$WARNINGS${NC}"

if [ "$ERRORS" -eq 0 ]; then
    echo -e "${GREEN}✅ VALIDATION PASSED${NC}"
    exit 0
else
    echo -e "${RED}❌ VALIDATION FAILED${NC}"
    exit 1
fi
