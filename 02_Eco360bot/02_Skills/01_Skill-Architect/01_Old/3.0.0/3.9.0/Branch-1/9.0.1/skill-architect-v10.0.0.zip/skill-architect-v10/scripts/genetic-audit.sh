#!/bin/bash
# genetic-audit.sh — Inheritance verification
# Usage: bash genetic-audit.sh /path/to/skill
# v1.0.0 | skill-architect v10.0.0

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SKILL_PATH="${1:-.}"

echo "═══════════════════════════════════════════════════════"
echo "              GENETIC AUDIT v1.0.0"
echo "═══════════════════════════════════════════════════════"

if [ ! -f "$SKILL_PATH/SKILL.md" ]; then
    echo -e "${RED}❌ SKILL.md not found${NC}"
    exit 1
fi

INHERITED=0
LOST=0

# Phase 1: Parent Genes
echo -e "${BLUE}═══ PHASE 1: PARENT GENES ═══${NC}"

declare -A PARENT_GENES

grep -q "< 300\|300 lines" "$SKILL_PATH/SKILL.md" 2>/dev/null && \
    PARENT_GENES["C1-F02"]="size_limit" && echo -e "${GREEN}  ✓ C1-F02 Size limit${NC}"
grep -q "NEVER DEGRADE" "$SKILL_PATH/SKILL.md" 2>/dev/null && \
    PARENT_GENES["C1-F06"]="never_degrade" && echo -e "${GREEN}  ✓ C1-F06 NEVER DEGRADE${NC}"
grep -q "🟢\|🟡\|🔴" "$SKILL_PATH/SKILL.md" 2>/dev/null && \
    PARENT_GENES["C1-F10"]="session" && echo -e "${GREEN}  ✓ C1-F10 Session indicator${NC}"
[ -d "$SKILL_PATH/protocols" ] && \
    PARENT_GENES["C2-F01"]="protocols" && echo -e "${GREEN}  ✓ C2-F01 Protocols${NC}"
grep -q "⛔" "$SKILL_PATH/SKILL.md" 2>/dev/null && \
    PARENT_GENES["C1-F09"]="blocking" && echo -e "${GREEN}  ✓ C1-F09 Blocking points${NC}"
head -1 "$SKILL_PATH/SKILL.md" | grep -q "^---" && \
    PARENT_GENES["C1-F01"]="frontmatter" && echo -e "${GREEN}  ✓ C1-F01 Frontmatter${NC}"
grep -q "FEATURE-REGISTRY" "$SKILL_PATH/SKILL.md" 2>/dev/null && \
    PARENT_GENES["C6-F13"]="registry" && echo -e "${GREEN}  ✓ C6-F13 Feature Registry${NC}"
grep -q "Purpose\|serves" "$SKILL_PATH/SKILL.md" 2>/dev/null && \
    PARENT_GENES["C1-F04"]="purpose" && echo -e "${GREEN}  ✓ C1-F04 Purpose block${NC}"
grep -q "Context Anchor\|⚙️" "$SKILL_PATH/SKILL.md" 2>/dev/null && \
    PARENT_GENES["C1-F09b"]="anchor" && echo -e "${GREEN}  ✓ C1-F09b Context anchor${NC}"
grep -q "First Step\|Protocol-First" "$SKILL_PATH/SKILL.md" 2>/dev/null && \
    PARENT_GENES["C2-F00"]="protocol_first" && echo -e "${GREEN}  ✓ C2-F00 Protocol-First${NC}"

PARENT_COUNT=${#PARENT_GENES[@]}
echo ""
echo "Parent genes found: $PARENT_COUNT"

# Phase 2: Child Requirements
echo ""
echo -e "${BLUE}═══ PHASE 2: CHILD REQUIREMENTS ═══${NC}"

declare -A CHILD_REQS
TEMPLATES="$SKILL_PATH/reference/templates.md"

if [ -f "$TEMPLATES" ]; then
    grep -q "< 300\|300 lines" "$TEMPLATES" && CHILD_REQS["C1-F02"]="✅" && \
        echo -e "${GREEN}  ✓ C1-F02 documented${NC}"
    grep -q "NEVER DEGRADE" "$TEMPLATES" && CHILD_REQS["C1-F06"]="✅" && \
        echo -e "${GREEN}  ✓ C1-F06 documented${NC}"
    grep -q "🟢\|session" "$TEMPLATES" && CHILD_REQS["C1-F10"]="✅" && \
        echo -e "${GREEN}  ✓ C1-F10 documented${NC}"
    grep -q "Protocol-First" "$TEMPLATES" && CHILD_REQS["C2-F01"]="✅" && \
        echo -e "${GREEN}  ✓ C2-F01 documented${NC}"
    grep -q "⛔" "$TEMPLATES" && CHILD_REQS["C1-F09"]="✅" && \
        echo -e "${GREEN}  ✓ C1-F09 documented${NC}"
    grep -q "frontmatter\|name:" "$TEMPLATES" && CHILD_REQS["C1-F01"]="✅" && \
        echo -e "${GREEN}  ✓ C1-F01 documented${NC}"
    grep -q "FEATURE-REGISTRY" "$TEMPLATES" && CHILD_REQS["C6-F13"]="✅" && \
        echo -e "${GREEN}  ✓ C6-F13 documented${NC}"
    grep -q "Purpose Block\|serves" "$TEMPLATES" && CHILD_REQS["C1-F04"]="✅" && \
        echo -e "${GREEN}  ✓ C1-F04 documented${NC}"
    grep -q "Context Anchor" "$TEMPLATES" && CHILD_REQS["C1-F09b"]="✅" && \
        echo -e "${GREEN}  ✓ C1-F09b documented${NC}"
    grep -q "First Step\|Protocol-First" "$TEMPLATES" && CHILD_REQS["C2-F00"]="✅" && \
        echo -e "${GREEN}  ✓ C2-F00 documented${NC}"
else
    echo -e "${YELLOW}  ⚠ templates.md not found${NC}"
fi

CHILD_COUNT=${#CHILD_REQS[@]}
echo ""
echo "Child requirements documented: $CHILD_COUNT"

# Phase 3: Compare
echo ""
echo -e "${BLUE}═══ PHASE 3: INHERITANCE MATRIX ═══${NC}"
echo ""
echo "| Gene | Name | Parent | Child | Status |"
echo "|------|------|--------|-------|--------|"

for gene in "${!PARENT_GENES[@]}"; do
    NAME="${PARENT_GENES[$gene]}"
    if [ -n "${CHILD_REQS[$gene]}" ]; then
        echo -e "| $gene | $NAME | ✅ | ✅ | ${GREEN}INHERITED${NC} |"
        ((INHERITED++))
    else
        echo -e "| $gene | $NAME | ✅ | ❌ | ${RED}LOST${NC} |"
        ((LOST++))
    fi
done

# Verdict
echo ""
echo "═══════════════════════════════════════════════════════"

PERCENT=0
[ "$PARENT_COUNT" -gt 0 ] && PERCENT=$((INHERITED * 100 / PARENT_COUNT))

echo "Inherited: $INHERITED/$PARENT_COUNT ($PERCENT%)"
echo "Lost: $LOST"
echo ""

if [ "$PERCENT" -ge 80 ]; then
    echo -e "${GREEN}✅ VERDICT: ALIGNED${NC}"
    exit 0
elif [ "$PERCENT" -ge 50 ]; then
    echo -e "${YELLOW}⚠️ VERDICT: PARTIAL${NC}"
    exit 0
else
    echo -e "${RED}❌ VERDICT: GAPS${NC}"
    exit 1
fi
