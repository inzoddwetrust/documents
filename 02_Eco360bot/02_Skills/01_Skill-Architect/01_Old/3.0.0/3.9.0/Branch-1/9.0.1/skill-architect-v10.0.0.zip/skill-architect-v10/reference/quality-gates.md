# Quality Gates L1-L10

Validation levels for skill quality.

---

## L1: Structure

| Check | Required |
|-------|----------|
| SKILL.md exists | ✅ |
| SKILL.md < 300 lines | ✅ |
| README-{name}.md exists | ✅ |
| MANIFEST.md exists (if reference/) | ✅ |

---

## L2: Content

| Check | Required |
|-------|----------|
| Frontmatter present | ✅ |
| name field | ✅ |
| description field | ✅ |
| Version in description | ✅ |
| Purpose defined | ✅ |

---

## L3: Logic

| Check | Required |
|-------|----------|
| Flow diagram | ✅ |
| Protocol references | ✅ |
| Blocking points marked | ✅ |
| State transitions defined | ✅ |

---

## L4: Naming

| Check | Required |
|-------|----------|
| Skill name kebab-case | ✅ |
| Protocol P##-name.md | ✅ |
| Docs UPPER-CASE-name.md | ✅ |
| Scripts lower-case.sh | ✅ |

---

## L5: Integration

| Check | Required |
|-------|----------|
| MANIFEST.md accurate | ✅ |
| Footers consistent | ✅ |
| Cross-references valid | ✅ |

---

## L6: Testing

| Check | Required |
|-------|----------|
| All protocols exist | ✅ |
| Scripts executable | ✅ |
| Confirmation rules defined | ✅ |

---

## L7: Knowledge Redundancy

| Check | Required |
|-------|----------|
| No LLM-native explanations | ✅ |
| No obvious pattern descriptions | ✅ |
| Delete test: still works? | ✅ |

---

## L8: Version Integrity

| Check | Required |
|-------|----------|
| All footers same version | ✅ |
| description matches | ✅ |
| CHANGELOG updated | ✅ |

---

## L9: Documentation

| Check | Required |
|-------|----------|
| docs/ directory exists | ✅ |
| DIFF present | ✅ |
| LOGIC-TREE present | ✅ |
| SCAN present | ✅ |

---

## L10: Feature Registry

| Check | Required |
|-------|----------|
| FEATURE-REGISTRY.md exists | ✅ |
| All features numbered | ✅ |
| Line counts present | ✅ |
| Categories complete | ✅ |

---

## Validation Commands

```bash
bash scripts/validate.sh /path           # L1-L6
bash scripts/validate.sh --degrade /a /b # NEVER DEGRADE
bash scripts/validate.sh --docs /path    # L9
bash scripts/validate.sh --ssot /path    # SSOT check
bash scripts/ssot-check.sh /path         # Standalone SSOT
bash scripts/feature-registry.sh /path   # L10
bash scripts/audit.sh /path              # Full L1-L10
bash scripts/genetic-audit.sh /path      # Inheritance
```

---

*quality-gates.md v1.0.0 | skill-architect v10.0.0*
