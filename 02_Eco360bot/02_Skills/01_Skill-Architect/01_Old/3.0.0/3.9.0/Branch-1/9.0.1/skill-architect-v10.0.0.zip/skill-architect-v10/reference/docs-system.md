# Documentation System

Versioned documentation architecture.

---

## Structure

```
skill-name/
├── SKILL.md                  ← Claude (minimal)
├── README-{skill}.md         ← Human (full)
├── CHANGELOG-{skill}.md      ← History
├── MANIFEST.md               ← Index
└── docs/
    └── vX.Y.Z/
        ├── DIFF-{skill}-vX.Y.Z.md
        ├── LOGIC-TREE-{skill}-vX.Y.Z.md
        ├── SCAN-{skill}-vX.Y.Z.md
        └── FEATURE-REGISTRY-{skill}-vX.Y.Z.md
```

---

## Document Types

| Document | Required | Content |
|----------|----------|---------|
| DIFF | ✅ | What changed |
| LOGIC-TREE | ✅ | Business logic flow |
| SCAN | ✅ | Validation results |
| FEATURE-REGISTRY | ✅ | Feature tracking |

---

## Lean Principle

| Layer | Content | Audience |
|-------|---------|----------|
| SKILL.md | Minimal instructions | Claude |
| README | Full documentation | Human |
| docs/ | Version archives | Reference |

**Rule:** SKILL.md contains ONLY what Claude needs to execute.

---

*docs-system.md v1.0.0 | skill-architect v10.0.0*
