# DIFF: skill-architect v9.0.1 → v10.0.0

## Summary

| Metric | v9.0.1 | v10.0.0 | Change |
|--------|--------|---------|--------|
| SKILL.md lines | ~93 | <80 | -14% |
| Protocol lines (each) | ~95 avg | <50 | -47% |
| Total features | 38 | 38 | 0 |
| New files | - | anchor-format.md | +1 |

## Architecture Change

### v9.0.1: Memory-dependent
- Protocols assumed Claude remembers previous steps
- Anchor showed status only
- No explicit next action

### v10.0.0: Anchor-based
- Every response is treated as fresh start
- Anchor includes NEXT action (self-instruction)
- PRE-ACTION and EXIT CRITERIA in every protocol

## New Anchor Format

```
v9.0.1:
⚙️ skill-architect v9.0.1 · P02-plan · awaiting confirmation
🟢 fresh

v10.0.0:
⚙️ skill-architect v10.0.0 · P02-plan · awaiting confirmation ⛔
🟢 fresh | NEXT: user confirms → read P03-build.md → build
```

## New Protocol Structure

```
v9.0.1:
# P##-name
[content without structure]

v10.0.0:
# P##-name
## ⚠️ PRE-ACTION
## Steps
## ✅ EXIT CRITERIA
## Anchor
```

## Files Changed

| File | Change |
|------|--------|
| SKILL.md | Reduced, added FIRST ACTION |
| All protocols | Restructured with PRE/EXIT |
| reference/anchor-format.md | NEW |
| reference/templates.md | Updated for v10 patterns |

## NEVER DEGRADE Status

✅ All 38 features from v9.0.1 preserved

---

*DIFF-skill-architect-v10.0.0.md | skill-architect v10.0.0*
