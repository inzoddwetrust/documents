#!/bin/bash
# validate.sh - Skill validation for monolithic architecture
# skill-architect v11.0.0

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Path
SKILL_PATH="${1:-.}"
ERRORS=0
WARNINGS=0

echo "═══════════════════════════════════════════════════════"
echo "           SKILL VALIDATOR v11.0.0 (Monolith)"
echo "═══════════════════════════════════════════════════════"
echo "Path: $SKILL_PATH"
echo ""

# Get skill name from SKILL.md
if [ -f "$SKILL_PATH/SKILL.md" ]; then
    SKILL_NAME=$(grep "^name:" "$SKILL_PATH/SKILL.md" | head -1 | sed 's/name: *//' | tr -d '"')
else
    SKILL_NAME="unknown"
fi

# L1: Structure
echo -e "${BLUE}═══ L1: STRUCTURE ═══${NC}"

if [ -f "$SKILL_PATH/SKILL.md" ]; then
    echo -e "${GREEN}  ✓ SKILL.md exists${NC}"
    
    LINES=$(wc -l < "$SKILL_PATH/SKILL.md")
    if [ "$LINES" -lt 500 ]; then
        echo -e "${GREEN}  ✓ SKILL.md < 500 lines ($LINES)${NC}"
    else
        echo -e "${YELLOW}  ⚠ SKILL.md has $LINES lines (limit: 500)${NC}"
        ((WARNINGS++))
    fi
else
    echo -e "${RED}  ✗ SKILL.md missing${NC}"
    ((ERRORS++))
fi

if ls "$SKILL_PATH"/README-*.md 1>/dev/null 2>&1; then
    echo -e "${GREEN}  ✓ README exists${NC}"
else
    echo -e "${RED}  ✗ README-{name}.md missing${NC}"
    ((ERRORS++))
fi

if ls "$SKILL_PATH"/CHANGELOG-*.md 1>/dev/null 2>&1; then
    echo -e "${GREEN}  ✓ CHANGELOG exists${NC}"
else
    echo -e "${YELLOW}  ⚠ CHANGELOG-{name}.md missing${NC}"
    ((WARNINGS++))
fi

echo ""

# L2: Content
echo -e "${BLUE}═══ L2: CONTENT ═══${NC}"

if [ -f "$SKILL_PATH/SKILL.md" ]; then
    if grep -q "^---" "$SKILL_PATH/SKILL.md"; then
        echo -e "${GREEN}  ✓ Frontmatter present${NC}"
    else
        echo -e "${RED}  ✗ Frontmatter missing${NC}"
        ((ERRORS++))
    fi
    
    if grep -q "^name:" "$SKILL_PATH/SKILL.md"; then
        echo -e "${GREEN}  ✓ Name field present${NC}"
    else
        echo -e "${RED}  ✗ Name field missing${NC}"
        ((ERRORS++))
    fi
    
    if grep -q "^description:" "$SKILL_PATH/SKILL.md"; then
        echo -e "${GREEN}  ✓ Description field present${NC}"
    else
        echo -e "${RED}  ✗ Description field missing${NC}"
        ((ERRORS++))
    fi
fi

echo ""

# L3: Logic
echo -e "${BLUE}═══ L3: LOGIC ═══${NC}"

if [ -f "$SKILL_PATH/SKILL.md" ]; then
    if grep -qE "Flow|→|P01|P02" "$SKILL_PATH/SKILL.md"; then
        echo -e "${GREEN}  ✓ Flow/phases documented${NC}"
    else
        echo -e "${YELLOW}  ⚠ No flow diagram found${NC}"
        ((WARNINGS++))
    fi
    
    if grep -qE "⛔|BLOCKING|confirmation" "$SKILL_PATH/SKILL.md"; then
        echo -e "${GREEN}  ✓ Blocking points marked${NC}"
    else
        echo -e "${YELLOW}  ⚠ No blocking points found${NC}"
        ((WARNINGS++))
    fi
    
    if grep -qE "NEXT:|Anchor" "$SKILL_PATH/SKILL.md"; then
        echo -e "${GREEN}  ✓ Anchor format defined${NC}"
    else
        echo -e "${YELLOW}  ⚠ No anchor format found${NC}"
        ((WARNINGS++))
    fi
fi

echo ""

# L4: Naming
echo -e "${BLUE}═══ L4: NAMING ═══${NC}"

if [[ "$SKILL_NAME" =~ ^[a-z0-9-]+$ ]]; then
    echo -e "${GREEN}  ✓ Skill name is kebab-case ($SKILL_NAME)${NC}"
else
    echo -e "${YELLOW}  ⚠ Skill name should be kebab-case: $SKILL_NAME${NC}"
    ((WARNINGS++))
fi

echo ""

# L5: Scripts
echo -e "${BLUE}═══ L5: SCRIPTS ═══${NC}"

if [ -d "$SKILL_PATH/scripts" ]; then
    echo -e "${GREEN}  ✓ scripts/ directory exists${NC}"
    
    if [ -f "$SKILL_PATH/scripts/validate.sh" ]; then
        echo -e "${GREEN}  ✓ validate.sh exists${NC}"
    else
        echo -e "${YELLOW}  ⚠ validate.sh missing${NC}"
        ((WARNINGS++))
    fi
else
    echo -e "${YELLOW}  ⚠ scripts/ directory missing${NC}"
    ((WARNINGS++))
fi

echo ""

# L6: No forbidden files
echo -e "${BLUE}═══ L6: MONOLITH CHECK ═══${NC}"

if [ -d "$SKILL_PATH/protocols" ]; then
    echo -e "${YELLOW}  ⚠ protocols/ exists (monolith should not have separate protocols)${NC}"
    ((WARNINGS++))
else
    echo -e "${GREEN}  ✓ No separate protocols (monolith)${NC}"
fi

if [ -d "$SKILL_PATH/reference" ]; then
    echo -e "${YELLOW}  ⚠ reference/ exists (monolith should not have separate reference)${NC}"
    ((WARNINGS++))
else
    echo -e "${GREEN}  ✓ No separate reference (monolith)${NC}"
fi

echo ""

# Summary
echo "═══════════════════════════════════════════════════════"
echo "                    SUMMARY"
echo "═══════════════════════════════════════════════════════"
echo -e "Errors:   ${RED}$ERRORS${NC}"
echo -e "Warnings: ${YELLOW}$WARNINGS${NC}"

if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}✅ VALIDATION PASSED${NC}"
    exit 0
else
    echo -e "${RED}❌ VALIDATION FAILED${NC}"
    exit 1
fi
