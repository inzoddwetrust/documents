#!/bin/bash
# audit.sh - Full skill audit with feature counting
# skill-architect v11.0.0



# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SKILL_PATH="${1:-.}"

echo "═══════════════════════════════════════════════════════"
echo "           SKILL AUDIT v11.0.0 (Monolith)"
echo "═══════════════════════════════════════════════════════"
echo "Path: $SKILL_PATH"
echo ""

# Get skill info
if [ -f "$SKILL_PATH/SKILL.md" ]; then
    SKILL_NAME=$(grep "^name:" "$SKILL_PATH/SKILL.md" | head -1 | sed 's/name: *//' | tr -d '"')
    VERSION=$(grep "^description:" "$SKILL_PATH/SKILL.md" | grep -oE "v[0-9]+\.[0-9]+\.[0-9]+" | head -1)
else
    SKILL_NAME="unknown"
    VERSION="unknown"
fi

echo "Skill: $SKILL_NAME"
echo "Version: $VERSION"
echo ""

# File inventory
echo -e "${BLUE}═══ FILE INVENTORY ═══${NC}"

TOTAL_FILES=0
TOTAL_LINES=0

for file in "$SKILL_PATH"/*.md; do
    if [ -f "$file" ]; then
        lines=$(wc -l < "$file")
        name=$(basename "$file")
        printf "  %-40s %4d lines\n" "$name" "$lines"
        ((TOTAL_FILES++))
        ((TOTAL_LINES+=lines))
    fi
done

if [ -d "$SKILL_PATH/scripts" ]; then
    for file in "$SKILL_PATH/scripts"/*.sh; do
        if [ -f "$file" ]; then
            lines=$(wc -l < "$file")
            name="scripts/$(basename "$file")"
            printf "  %-40s %4d lines\n" "$name" "$lines"
            ((TOTAL_FILES++))
            ((TOTAL_LINES+=lines))
        fi
    done
fi

if [ -d "$SKILL_PATH/docs" ]; then
    find "$SKILL_PATH/docs" -name "*.md" | while read file; do
        if [ -f "$file" ]; then
            lines=$(wc -l < "$file")
            name=${file#$SKILL_PATH/}
            printf "  %-40s %4d lines\n" "$name" "$lines"
        fi
    done
fi

echo ""
echo "─────────────────────────────────────────────────────"
printf "  %-40s %4d files, %d lines\n" "TOTAL" "$TOTAL_FILES" "$TOTAL_LINES"
echo ""

# Feature counting
echo -e "${BLUE}═══ FEATURE ANALYSIS ═══${NC}"

C1_FEATURES=0
C2_FEATURES=0
C3_FEATURES=0
C4_FEATURES=0
C5_FEATURES=0

# C1: Core files
[ -f "$SKILL_PATH/SKILL.md" ] && ((C1_FEATURES++))
ls "$SKILL_PATH"/README-*.md 1>/dev/null 2>&1 && ((C1_FEATURES++))
ls "$SKILL_PATH"/CHANGELOG-*.md 1>/dev/null 2>&1 && ((C1_FEATURES++))

# C2: Logic (count phases in SKILL.md)
if [ -f "$SKILL_PATH/SKILL.md" ]; then
    C2_FEATURES=$(grep -cE "^## P[0-9]|^# PHASE|^# ═.*PHASE" "$SKILL_PATH/SKILL.md" 2>/dev/null || echo 0)
fi

# C3: Templates
if [ -f "$SKILL_PATH/SKILL.md" ]; then
    C3_FEATURES=$(grep -cE "^## .* TEMPLATE|TEMPLATE$" "$SKILL_PATH/SKILL.md" 2>/dev/null || echo 0)
fi

# C4: Scripts
[ -f "$SKILL_PATH/scripts/validate.sh" ] && ((C4_FEATURES++))
[ -f "$SKILL_PATH/scripts/audit.sh" ] && ((C4_FEATURES++))

# C5: Docs
if [ -d "$SKILL_PATH/docs" ]; then
    C5_FEATURES=$(find "$SKILL_PATH/docs" -name "*.md" | wc -l)
fi

TOTAL_FEATURES=$((C1_FEATURES + C2_FEATURES + C3_FEATURES + C4_FEATURES + C5_FEATURES))

echo "  C1 Core:      $C1_FEATURES features"
echo "  C2 Logic:     $C2_FEATURES features"
echo "  C3 Templates: $C3_FEATURES features"
echo "  C4 Scripts:   $C4_FEATURES features"
echo "  C5 Docs:      $C5_FEATURES features"
echo ""
echo "─────────────────────────────────────────────────────"
echo "  TOTAL:        $TOTAL_FEATURES features"
echo ""

# Monolith check
echo -e "${BLUE}═══ MONOLITH STATUS ═══${NC}"

MONOLITH_SCORE=0
MONOLITH_MAX=4

if [ ! -d "$SKILL_PATH/protocols" ]; then
    echo -e "${GREEN}  ✓ No separate protocols${NC}"
    ((MONOLITH_SCORE++))
else
    echo -e "${YELLOW}  ⚠ Has protocols/ directory${NC}"
fi

if [ ! -d "$SKILL_PATH/reference" ]; then
    echo -e "${GREEN}  ✓ No separate reference${NC}"
    ((MONOLITH_SCORE++))
else
    echo -e "${YELLOW}  ⚠ Has reference/ directory${NC}"
fi

if [ ! -f "$SKILL_PATH/MANIFEST.md" ]; then
    echo -e "${GREEN}  ✓ No MANIFEST (not needed for monolith)${NC}"
    ((MONOLITH_SCORE++))
else
    echo -e "${YELLOW}  ⚠ Has MANIFEST.md (unnecessary)${NC}"
fi

if [ -f "$SKILL_PATH/SKILL.md" ]; then
    skill_lines=$(wc -l < "$SKILL_PATH/SKILL.md")
    if [ "$skill_lines" -gt 100 ]; then
        echo -e "${GREEN}  ✓ SKILL.md has substantial logic ($skill_lines lines)${NC}"
        ((MONOLITH_SCORE++))
    else
        echo -e "${YELLOW}  ⚠ SKILL.md too small for monolith ($skill_lines lines)${NC}"
    fi
fi

echo ""
echo "  Monolith Score: $MONOLITH_SCORE/$MONOLITH_MAX"
echo ""

# Summary
echo "═══════════════════════════════════════════════════════"
echo "                    AUDIT COMPLETE"
echo "═══════════════════════════════════════════════════════"
echo "  Skill:    $SKILL_NAME"
echo "  Version:  $VERSION"
echo "  Files:    $TOTAL_FILES"
echo "  Lines:    $TOTAL_LINES"
echo "  Features: $TOTAL_FEATURES"
echo "  Type:     $([ $MONOLITH_SCORE -ge 3 ] && echo "Monolith ✓" || echo "Distributed")"
echo ""
