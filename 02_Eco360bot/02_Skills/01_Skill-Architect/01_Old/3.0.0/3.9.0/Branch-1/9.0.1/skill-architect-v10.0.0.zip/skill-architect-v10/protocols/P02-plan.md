# P02-plan: Planning ⛔ BLOCKING

Plan skill structure. Requires explicit confirmation.

---

## ⚠️ PRE-ACTION

1. Read: `reference/templates.md`
2. If update: run `bash scripts/feature-registry.sh [path]`

---

## Steps

1. Present PLAN document with:
   - Purpose (serves/goal/method/success)
   - Structure (file tree)
   - Features (preliminary count)
   - NEVER DEGRADE commitment

2. Ask for confirmation

---

## ⛔ BLOCKING

| ✅ Proceed | ❌ Stay |
|------------|---------|
| yes, go, proceed, давай, да | anything else |

---

## ✅ EXIT CRITERIA

On valid confirmation:
→ Read P03-build.md → execute PRE-ACTION → build

---

## Anchor

```
⚙️ skill-architect v10.0.0 · P02-plan · awaiting confirmation ⛔
[session] | NEXT: user confirms → read P03-build.md → build
```

---

*P02-plan.md | skill-architect v10.0.0*
