# Changelog

All notable changes to skill-architect.

---

## [11.0.0] "Monolith" - 2025-01-XX

### Philosophy Change

> "Микросервисы — это самый успешный обман доверия в индустрии разработки" — DHH

Returned to monolithic architecture. One file, full context, no jumping.

### Changed
- All logic consolidated into single SKILL.md (~500 lines)
- Removed separate protocol files (P00-P04)
- Removed reference directory
- Removed MANIFEST.md (obvious for 6 files)
- Simplified structure: 6 files instead of 40

### Structure

```
Before (v10):               After (v11):
40 files                    6 files
├── protocols/ (5)          ├── SKILL.md (all logic)
├── reference/ (11)         ├── README
├── scripts/ (9)            ├── CHANGELOG
├── docs/                   ├── scripts/ (2)
└── ...                     └── docs/
```

### Preserved
- Anchor with NEXT action
- PRE/DO/EXIT structure (inline)
- NEVER DEGRADE principle
- Validation scripts

---

## [10.0.0] "Anchor" - 2025-01-XX

### Added
- Anchor architecture with NEXT action
- PRE-ACTION and EXIT CRITERIA in protocols
- Self-routing between phases

### Problem
- Still required jumping between files
- Context distributed across 40 files

---

## [9.0.1] "Registry" - 2024-XX-XX

### Added
- FEATURE-REGISTRY requirement
- NEVER DEGRADE enforcement

---

*CHANGELOG-skill-architect.md | skill-architect v11.0.0*
