# Genetic Audit

Inheritance verification for child skills.

---

## Purpose

Verify skill inherits core genes from parent patterns.

---

## Core Genes

| Gene | Code | Required |
|------|------|----------|
| Size limit (<300) | C1-F02 | ✅ |
| NEVER DEGRADE | C1-F06 | ✅ |
| Session indicator | C1-F10 | ✅ |
| Protocols exist | C2-F01 | ✅ |
| Blocking points | C1-F09 | ✅ |
| Frontmatter | C1-F01 | ✅ |
| Purpose block | C1-F04 | ✅ |
| Context anchor | C1-F09b | ✅ |
| FEATURE-REGISTRY | C6-F13 | ✅ |
| Protocol-First | C2-F00 | ✅ |

---

## Audit Process

1. **Phase 1:** Extract parent genes from SKILL.md
2. **Phase 2:** Extract child requirements from templates.md
3. **Phase 3:** Build inheritance matrix
4. **Phase 4:** Calculate inheritance percentage

---

## Verdicts

| Percentage | Verdict |
|------------|---------|
| ≥80% | ✅ ALIGNED |
| 50-79% | ⚠️ PARTIAL |
| <50% | ❌ GAPS |

---

## Command

```bash
bash scripts/genetic-audit.sh /path
```

---

*genetic-audit.md v1.0.0 | skill-architect v10.0.0*
