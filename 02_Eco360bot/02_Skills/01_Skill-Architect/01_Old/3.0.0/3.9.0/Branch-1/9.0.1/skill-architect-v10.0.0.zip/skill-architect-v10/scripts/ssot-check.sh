#!/bin/bash
# ssot-check.sh — Single Source of Truth validation
# Usage: bash ssot-check.sh /path/to/skill
# v1.0.0 | skill-architect v10.0.0

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SKILL_PATH="${1:-.}"

echo "═══════════════════════════════════════════════════════"
echo "              SSOT CHECK v1.0.0"
echo "═══════════════════════════════════════════════════════"

if [ ! -f "$SKILL_PATH/SKILL.md" ]; then
    echo -e "${RED}❌ SKILL.md not found${NC}"
    exit 1
fi

ISSUES=0
WARNINGS=0

# Phase 1: Constraint Duplication
echo -e "${BLUE}═══ PHASE 1: CONSTRAINT DUPLICATION ═══${NC}"

declare -A CONSTRAINTS=(
    ["< 300"]="Line limit"
    ["English"]="Language rule"
    ["BLOCKING"]="Blocking markers"
    ["MANDATORY"]="Mandatory markers"
    ["Required"]="Requirement markers"
)

for pattern in "${!CONSTRAINTS[@]}"; do
    COUNT=$(grep -c "$pattern" "$SKILL_PATH/SKILL.md" 2>/dev/null || echo 0)
    NAME="${CONSTRAINTS[$pattern]}"
    
    if [ "$COUNT" -gt 3 ]; then
        echo -e "${RED}  ✗ '$pattern' ($NAME): $COUNT — SSOT violation${NC}"
        ((ISSUES++))
    elif [ "$COUNT" -gt 2 ]; then
        echo -e "${YELLOW}  ⚠ '$pattern' ($NAME): $COUNT — consider consolidating${NC}"
        ((WARNINGS++))
    else
        echo -e "${GREEN}  ✓ '$pattern' ($NAME): $COUNT${NC}"
    fi
done

# Phase 2: Command Duplication
echo ""
echo -e "${BLUE}═══ PHASE 2: COMMAND DUPLICATION ═══${NC}"

COMMANDS=("zip -r" "cp -r" "bash scripts/")

for cmd in "${COMMANDS[@]}"; do
    TOTAL=$(grep -r "$cmd" "$SKILL_PATH" --include="*.md" 2>/dev/null | wc -l || echo 0)
    
    if [ "$TOTAL" -gt 5 ]; then
        echo -e "${YELLOW}  ⚠ '$cmd': $TOTAL occurrences${NC}"
        ((WARNINGS++))
    else
        echo -e "${GREEN}  ✓ '$cmd': $TOTAL${NC}"
    fi
done

# Phase 3: Section Overlap
echo ""
echo -e "${BLUE}═══ PHASE 3: SECTION OVERLAP ═══${NC}"

CONSTRAINT_SECTIONS=$(grep -c "^## .*[Rr]ule\|[Cc]heck\|[Rr]equired" "$SKILL_PATH/SKILL.md" 2>/dev/null || echo 0)

if [ "$CONSTRAINT_SECTIONS" -gt 4 ]; then
    echo -e "${YELLOW}  ⚠ $CONSTRAINT_SECTIONS sections mention rules${NC}"
    ((WARNINGS++))
else
    echo -e "${GREEN}  ✓ Constraint sections: $CONSTRAINT_SECTIONS${NC}"
fi

# Phase 4: Repeated Headers
echo ""
echo -e "${BLUE}═══ PHASE 4: REPEATED HEADERS ═══${NC}"

REPEATED=$(grep -rh "^## " "$SKILL_PATH" --include="*.md" 2>/dev/null | sort | uniq -c | sort -rn | awk '$1 > 3 {print}' | head -5)

if [ -n "$REPEATED" ]; then
    echo -e "${YELLOW}  ⚠ Repeated headers:${NC}"
    echo "$REPEATED" | sed 's/^/   /'
    ((WARNINGS++))
else
    echo -e "${GREEN}  ✓ No excessive repetition${NC}"
fi

# Summary
echo ""
echo "═══════════════════════════════════════════════════════"
echo "                 SSOT SUMMARY"
echo "═══════════════════════════════════════════════════════"
echo -e "Issues:   ${RED}$ISSUES${NC}"
echo -e "Warnings: ${YELLOW}$WARNINGS${NC}"

if [ "$ISSUES" -eq 0 ]; then
    echo -e "${GREEN}✅ SSOT CHECK PASSED${NC}"
    exit 0
else
    echo -e "${RED}❌ SSOT CHECK FAILED${NC}"
    exit 1
fi
