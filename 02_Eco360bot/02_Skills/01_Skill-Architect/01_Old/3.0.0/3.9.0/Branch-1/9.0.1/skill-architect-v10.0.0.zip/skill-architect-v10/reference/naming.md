# Naming Convention

Standard naming for all skill components.

---

## Skill Names

| Rule | Example |
|------|---------|
| kebab-case | skill-architect |
| lowercase | ✅ |
| descriptive | ✅ |
| no version | ❌ skill-v1 |

---

## Files

| Type | Pattern | Example |
|------|---------|---------|
| Core | UPPER.md | SKILL.md |
| Readme | README-{name}.md | README-skill-architect.md |
| Changelog | CHANGELOG-{name}.md | CHANGELOG-skill-architect.md |
| Protocol | P##-name.md | P00-router.md |
| Reference | lowercase.md | templates.md |
| Script | lowercase.sh | validate.sh |
| Docs | UPPER-{name}-v{X.Y.Z}.md | DIFF-skill-architect-v10.0.0.md |

---

## Versions

| Format | Example |
|--------|---------|
| Semantic | vX.Y.Z |
| In description | "v10.0.0 \| ..." |
| In folder | skill-name-v10.0.0/ |

---

## Categories

| Code | Name |
|------|------|
| C1 | Core |
| C2 | Protocols |
| C3 | Validation |
| C4 | Scripts |
| C5 | Reference |
| C6 | Documentation |
| C7 | Inheritance |

---

## Features

| Format | Example |
|--------|---------|
| C#-F## | C1-F01, C4-F14 |

---

*naming.md v1.0.0 | skill-architect v10.0.0*
