# Anchor Format Specification

Defines the self-routing anchor that ends every response.

---

## Structure

```
⚙️ skill-architect v10.0.0 · [protocol] · [status]
[session] | NEXT: [explicit next action]
```

---

## Components

| Part | Values |
|------|--------|
| protocol | P01-init, P02-plan, P03-build, P04-deliver |
| status | configured, awaiting confirmation ⛔, building, validating, ready, complete |
| session | 🟢 fresh (<5), 🟡 mid (5-15), 🔴 long (>15) |
| NEXT | literal instruction for next response |

---

## NEXT Action Examples

| State | NEXT |
|-------|------|
| P01 complete | read P02-plan.md → present plan |
| P02 awaiting | user confirms → read P03-build.md → build |
| P03 building | validate C2 → continue to C5 |
| P03 ready | run validate.sh → read P04-deliver.md |
| P04 ready | user confirms → copy to outputs → END |

---

## Why NEXT Matters

Claude has no memory between responses. NEXT is a self-instruction that tells Claude exactly what to do when processing the next user message.

---

*anchor-format.md | skill-architect v10.0.0*
