# P01-init: Activation

Initialize skill session.

---

## ⚠️ PRE-ACTION

Read: `reference/naming.md` (if new skill)

---

## Steps

1. **Detect mode:** new / update / refactor
2. **Locate skill:** check `/mnt/skills/user/` and `/mnt/user-data/uploads/`
3. **Output config:**
   ```
   Mode: [mode]
   Skill: [name]
   Path: [path]
   Previous: [version or "none"]
   ```

---

## ✅ EXIT CRITERIA

When config displayed:
→ Proceed to P02-plan (read it first)

---

## Anchor

```
⚙️ skill-architect v10.0.0 · P01-init · configured
[session] | NEXT: read P02-plan.md → present plan
```

---

*P01-init.md | skill-architect v10.0.0*
