#!/bin/bash
# update-version.sh — Update version across all files
# Usage: bash update-version.sh /path OLD_VERSION NEW_VERSION
# v1.0.0 | skill-architect v10.0.0

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

SKILL_PATH="${1:-.}"
OLD_VERSION="$2"
NEW_VERSION="$3"

if [ -z "$OLD_VERSION" ] || [ -z "$NEW_VERSION" ]; then
    echo "Usage: bash update-version.sh /path OLD_VERSION NEW_VERSION"
    echo "Example: bash update-version.sh . v9.0.0 v10.0.0"
    exit 1
fi

echo "═══════════════════════════════════════════════════════"
echo "          VERSION UPDATE: $OLD_VERSION → $NEW_VERSION"
echo "═══════════════════════════════════════════════════════"

UPDATED=0

# Update .md files
for f in $(find "$SKILL_PATH" -name "*.md" -type f); do
    if grep -q "$OLD_VERSION" "$f" 2>/dev/null; then
        sed -i "s/$OLD_VERSION/$NEW_VERSION/g" "$f"
        echo -e "${GREEN}  ✓ $(basename $f)${NC}"
        ((UPDATED++))
    fi
done

# Update .sh files
for f in $(find "$SKILL_PATH" -name "*.sh" -type f); do
    if grep -q "$OLD_VERSION" "$f" 2>/dev/null; then
        sed -i "s/$OLD_VERSION/$NEW_VERSION/g" "$f"
        echo -e "${GREEN}  ✓ $(basename $f)${NC}"
        ((UPDATED++))
    fi
done

echo ""
echo "═══════════════════════════════════════════════════════"
echo -e "${GREEN}Updated: $UPDATED files${NC}"
echo "═══════════════════════════════════════════════════════"
