# DIFF Document Format

Version comparison template.

---

## Template

```markdown
# DIFF: {skill-name} v{OLD} → v{NEW}

## Summary

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Files | N | N | ±N |
| Lines | N | N | ±N |
| Features | N | N | ±N |

---

## Added

| Feature | File | Lines |
|---------|------|-------|
| C#-F## Description | file.md | N |

---

## Changed

| Feature | Before | After | Delta |
|---------|--------|-------|-------|
| C#-F## Description | N | N | ±N |

---

## Removed

| Feature | Reason |
|---------|--------|
| None | NEVER DEGRADE |

---

## NEVER DEGRADE Status

| Check | Result |
|-------|--------|
| Features lost | 0 |
| >30% line loss | 0 |
| Categories removed | 0 |

**VERDICT:** ✅ PASSED

---

*DIFF-{skill-name}-v{X.Y.Z}.md*
```

---

*diff-format.md v1.0.0 | skill-architect v10.0.0*
