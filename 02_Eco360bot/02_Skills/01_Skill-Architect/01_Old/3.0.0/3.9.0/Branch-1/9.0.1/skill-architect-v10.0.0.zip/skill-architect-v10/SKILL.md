---
name: skill-architect
description: "v10.0.0 | Anchor architecture for reliable skill creation. Triggers: create skill, update, refactor, checkup."
---

# Skill Architect v10.0.0 "Anchor"

Self-routing skill creation with explicit state tracking.

---

## ⚠️ FIRST ACTION

Every request → read router first:
```
view protocols/P00-router.md
```

---

## Commands

| Command | Route |
|---------|-------|
| create skill: [purpose] | P01-init |
| update: [changes] | P01-init |
| refactor | P01-init |
| checkup | `bash scripts/audit.sh` |

---

## Flow

```
P01-init → P02-plan ⛔ → P03-build → P04-deliver ⛔
```

---

## Critical Rules

| # | Rule |
|---|------|
| 1 | SKILL.md = English, < 80 lines |
| 2 | Protocols < 50 lines each |
| 3 | Every protocol has PRE-ACTION + EXIT CRITERIA |
| 4 | Anchor includes NEXT action |
| 5 | NEVER DEGRADE = 0 features lost |

---

## Anchor Format

End EVERY response:
```
⚙️ skill-architect v10.0.0 · [protocol] · [status]
[session] | NEXT: [explicit next action]
```

Session: 🟢 fresh (<5) | 🟡 mid (5-15) | 🔴 long (>15)

---

## Confirmation Words

| ✅ Valid | ❌ Invalid |
|----------|------------|
| yes, go, proceed, давай, да | ok, got it, understood, ок, понял |

---

*v10.0.0 "Anchor" | Self-routing protocol architecture*
