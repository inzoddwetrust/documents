# Templates Reference

All templates for skill creation.

---

## Frontmatter

```yaml
---
name: skill-name
description: "vX.Y.Z | Brief. Triggers: t1, t2."
---
```

Only `name` and `description` allowed.

---

## SKILL.md Template (< 80 lines)

```markdown
---
name: {skill-name}
description: "vX.Y.Z | Brief. Triggers: t1, t2."
---

# {Skill Name} vX.Y.Z

One-line purpose.

---

## ⚠️ FIRST ACTION

view protocols/P00-router.md

---

## Commands

| Command | Route |
|---------|-------|
| ... | P01-init |

---

## Flow

P01 → P02 ⛔ → P03 → P04 ⛔

---

## Critical Rules

| # | Rule |
|---|------|
| 1 | ... |

---

## Anchor Format

⚙️ {skill-name} vX.Y.Z · [protocol] · [status]
[session] | NEXT: [action]

---

*vX.Y.Z*
```

---

## Protocol Template (< 50 lines)

```markdown
# P##-name: Title [⛔ BLOCKING]

One-line purpose.

---

## ⚠️ PRE-ACTION

- Read: [file]
- Run: [command]

---

## Steps

1. Step one
2. Step two
3. Step three

---

## ✅ EXIT CRITERIA

When done:
→ [next action]

---

## Anchor

⚙️ {skill} v{X.Y.Z} · P##-name · [status]
[session] | NEXT: [explicit action]

---

*P##-name.md | {skill} v{X.Y.Z}*
```

---

## README Template (user's language)

```markdown
# {Skill Name}

{1-2 sentence description}

## Quick Start

{Command example}

## Commands

| Command | Description |
|---------|-------------|
| ... | ... |

## Examples

{Concrete examples}
```

---

## Anchor with NEXT

```
⚙️ {skill} vX.Y.Z · [protocol] · [status]
[session] | NEXT: [literal instruction for next response]
```

NEXT tells Claude what to do when processing next message.

---

*templates.md | skill-architect v10.0.0*
