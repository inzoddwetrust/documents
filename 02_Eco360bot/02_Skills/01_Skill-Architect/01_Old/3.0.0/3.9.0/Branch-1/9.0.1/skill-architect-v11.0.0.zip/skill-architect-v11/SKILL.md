---
name: skill-architect
description: "v11.0.0 | Monolithic skill creation. All logic in one file. Triggers: create skill, update, refactor, checkup."
---

# Skill Architect v11.0.0 "Monolith"

One file. Full context. No jumping.

---

## Purpose

| Field | Value |
|-------|-------|
| serves | Claude + Human operator |
| goal | Create skills without losing context |
| method | Everything in SKILL.md, scripts for validation only |
| success | Zero "follow your protocol" reminders needed |

---

## Commands

| Command | Action |
|---------|--------|
| create skill: [purpose] | New skill → P01 |
| update: [changes] | Modify existing → P01 |
| refactor | Restructure → P01 |
| checkup | `bash scripts/audit.sh` |

---

## Flow

```
P01-init → P02-plan ⛔ → P03-build → P04-deliver ⛔ → END
```

⛔ = explicit confirmation required

---

## Critical Rules

| # | Rule |
|---|------|
| 1 | SKILL.md = English, < 500 lines |
| 2 | All logic in SKILL.md (no separate protocols) |
| 3 | Scripts for validation only, not logic |
| 4 | README in user's language |
| 5 | Anchor with NEXT at end of every response |
| 6 | NEVER DEGRADE = 0 features lost on update |

---

## Confirmation

| ✅ Valid (proceed) | ❌ Invalid (stay) |
|--------------------|-------------------|
| yes, go, proceed | ok, got it, understood |
| давай, да | ок, понял |

---

# ═══════════════════════════════════════════════════════
# PHASE 01: INIT
# ═══════════════════════════════════════════════════════

## P01: Activation

**Purpose:** Initialize session, detect mode, locate skill.

### PRE
- None (entry point)

### DO

1. **Detect mode:**
   - "create skill: X" → mode: new
   - "update: X" → mode: update
   - "refactor" → mode: refactor

2. **Locate skill (if update/refactor):**
   ```bash
   ls /mnt/skills/user/{skill-name}/
   ls /mnt/user-data/uploads/{skill-name}/
   ```

3. **Output config:**
   ```
   Mode: [new/update/refactor]
   Skill: [name]
   Path: [path or "new"]
   Previous: [version or "none"]
   ```

### EXIT
→ Proceed to P02 (below)

### Anchor
```
⚙️ skill-architect v11.0.0 · P01-init · configured
[session] | NEXT: present plan for confirmation
```

---

# ═══════════════════════════════════════════════════════
# PHASE 02: PLAN ⛔ BLOCKING
# ═══════════════════════════════════════════════════════

## P02: Planning

**Purpose:** Define skill structure, get explicit confirmation.

### PRE
- P01 must be complete
- If update: run `bash scripts/audit.sh [old-path]` to capture baseline

### DO

1. **Present PLAN document:**

```markdown
# PLAN: {skill-name}

## Purpose
| Field | Value |
|-------|-------|
| serves | [who] |
| goal | [what] |
| method | [how] |
| success | [measure] |

## Structure
{skill-name}/
├── SKILL.md              # All logic (< 500 lines)
├── README-{name}.md      # User docs (user's language)
├── CHANGELOG-{name}.md   # Version history
├── scripts/
│   ├── validate.sh
│   └── audit.sh
└── docs/
    └── v{X.Y.Z}/
        └── FEATURE-REGISTRY-{name}-v{X.Y.Z}.md

## NEVER DEGRADE
Previous: [version or "none"]
Status: [will verify at delivery]
```

2. **Ask for confirmation**

### ⛔ BLOCKING
Wait for valid confirmation before proceeding.

### EXIT
On "yes/go/proceed/давай/да" → P03

### Anchor
```
⚙️ skill-architect v11.0.0 · P02-plan · awaiting confirmation ⛔
[session] | NEXT: user confirms → build skill
```

---

# ═══════════════════════════════════════════════════════
# PHASE 03: BUILD
# ═══════════════════════════════════════════════════════

## P03: Building

**Purpose:** Create all skill files, validate.

### PRE
- P02 confirmed
- If update: baseline captured

### DO

1. **Create directory:**
   ```bash
   mkdir -p /home/claude/{skill-name}/{scripts,docs/vX.Y.Z}
   ```

2. **Create SKILL.md** (use SKILL TEMPLATE below)

3. **Create README-{name}.md** (user's language)

4. **Create CHANGELOG-{name}.md**

5. **Create scripts:**
   - validate.sh (copy from skill-architect)
   - audit.sh (copy from skill-architect)

6. **Validate:**
   ```bash
   bash scripts/validate.sh /home/claude/{skill-name}
   ```

### Validation Checklist
```
□ SKILL.md exists and < 500 lines
□ SKILL.md has frontmatter (name + description only)
□ SKILL.md has flow diagram
□ README-{name}.md exists
□ CHANGELOG-{name}.md exists
□ scripts/validate.sh exists and executable
□ All commands documented
□ Anchor format defined
```

### EXIT
- PASS → P04
- FAIL → fix and re-validate

### Anchor
```
⚙️ skill-architect v11.0.0 · P03-build · [building|validating|ready]
[session] | NEXT: [current step or "validate → deliver"]
```

---

# ═══════════════════════════════════════════════════════
# PHASE 04: DELIVER ⛔ BLOCKING
# ═══════════════════════════════════════════════════════

## P04: Delivery

**Purpose:** Package, verify NEVER DEGRADE, deliver.

### PRE
- P03 validation PASSED
- Run `bash scripts/audit.sh [path]`

### DO

1. **Generate FEATURE-REGISTRY:**
   - Count features per category
   - Calculate total lines
   - Save to docs/vX.Y.Z/

2. **NEVER DEGRADE check (if update):**
   - Compare with baseline
   - 0 features may be lost
   - Categories cannot be removed

3. **Package:**
   ```bash
   cd /home/claude && zip -r {skill-name}-vX.Y.Z.zip {skill-name}
   ```

4. **Copy to outputs:**
   ```bash
   cp {skill-name}-vX.Y.Z.zip /mnt/user-data/outputs/
   cp -r {skill-name} /mnt/user-data/outputs/
   ```

5. **Present delivery:**
   - Link to zip
   - Feature summary
   - NEVER DEGRADE status

6. **Ask for confirmation**

### ⛔ BLOCKING
Wait for valid confirmation.

### EXIT
On confirmation → END

### Anchor
```
⚙️ skill-architect v11.0.0 · P04-deliver · [packaging|ready] ⛔
[session] | NEXT: user confirms → END
```

---

# ═══════════════════════════════════════════════════════
# TEMPLATES
# ═══════════════════════════════════════════════════════

## SKILL TEMPLATE

```markdown
---
name: {skill-name}
description: "vX.Y.Z | Brief description. Triggers: trigger1, trigger2."
---

# {Skill Name} vX.Y.Z

One-line purpose.

---

## Purpose

| Field | Value |
|-------|-------|
| serves | [who] |
| goal | [what] |
| method | [how] |
| success | [measure] |

---

## Commands

| Command | Action |
|---------|--------|
| command1 | What it does |
| command2 | What it does |

---

## Flow

[Describe the workflow, phases, or steps]

---

## [Main Logic Sections]

[All phases/protocols inline - no separate files]

---

## Anchor

End EVERY response:
⚙️ {skill-name} vX.Y.Z · [state] · [status]
[session] | NEXT: [explicit next action]

Session: 🟢 fresh (<5) | 🟡 mid (5-15) | 🔴 long (>15)

---

*vX.Y.Z*
```

---

## README TEMPLATE

Language: User's language (Russian if user speaks Russian)

```markdown
# {Skill Name}

{1-2 sentence description}

## Быстрый старт

{Primary command example}

## Команды

| Команда | Описание |
|---------|----------|
| cmd1 | Что делает |

## Примеры

{Concrete examples}

---

*{skill-name} vX.Y.Z*
```

---

# ═══════════════════════════════════════════════════════
# ANCHOR SPECIFICATION
# ═══════════════════════════════════════════════════════

## Format

```
⚙️ skill-architect v11.0.0 · [phase] · [status]
[session] | NEXT: [explicit instruction for next response]
```

## Components

| Part | Values |
|------|--------|
| phase | P01-init, P02-plan, P03-build, P04-deliver, complete |
| status | configured, awaiting confirmation ⛔, building, validating, ready, delivered |
| session | 🟢 fresh (<5 msgs), 🟡 mid (5-15), 🔴 long (>15) |
| NEXT | Literal instruction for what to do next |

## Why NEXT Matters

Claude has no memory between responses. Each response is a fresh start.
NEXT is a self-instruction that tells Claude exactly what to do when processing the next user message.

## Examples

| State | NEXT |
|-------|------|
| P01 done | present plan for confirmation |
| P02 waiting | user confirms → build skill |
| P03 building | validate → if pass → deliver |
| P04 ready | user confirms → END |

---

# ═══════════════════════════════════════════════════════
# QUALITY GATES
# ═══════════════════════════════════════════════════════

## Validation Levels

| Level | Check |
|-------|-------|
| L1 Structure | SKILL.md exists, < 500 lines |
| L2 Content | Frontmatter present, version in description |
| L3 Logic | Flow diagram, phases documented |
| L4 Naming | kebab-case for skill name |
| L5 Docs | README exists, CHANGELOG exists |
| L6 Scripts | validate.sh exists and executable |

## validate.sh Checks

```bash
# L1
[ -f SKILL.md ] && [ $(wc -l < SKILL.md) -lt 500 ]

# L2
grep -q "^---" SKILL.md && grep -q "^name:" SKILL.md

# L3
grep -q "Flow\|flow\|→" SKILL.md

# L4
[[ "$skill_name" =~ ^[a-z0-9-]+$ ]]

# L5
[ -f README-*.md ] && [ -f CHANGELOG-*.md ]

# L6
[ -x scripts/validate.sh ]
```

---

# ═══════════════════════════════════════════════════════
# NEVER DEGRADE
# ═══════════════════════════════════════════════════════

## Principle

When updating a skill, no features may be lost.

## Rules

| Rule | Description |
|------|-------------|
| Zero loss | Feature count must not decrease |
| No removal | Categories cannot be removed |
| Warning | >30% line reduction per feature = investigate |

## Process

1. **Before update:** Run audit on old version → baseline
2. **After build:** Run audit on new version → current
3. **Compare:** baseline vs current
4. **Verify:** current.features >= baseline.features

## Feature Categories

| Code | Category |
|------|----------|
| C1 | Core (SKILL.md, README, CHANGELOG) |
| C2 | Logic (phases, workflows) |
| C3 | Templates |
| C4 | Scripts |
| C5 | Documentation |

---

# ═══════════════════════════════════════════════════════
# RECOVERY
# ═══════════════════════════════════════════════════════

## If Context Lost

1. Find last anchor in conversation
2. Read phase and status from anchor
3. Read NEXT instruction
4. Continue from that point

## Session Indicators

| Icon | Meaning | Action |
|------|---------|--------|
| 🟢 | Fresh (<5 msgs) | Normal operation |
| 🟡 | Mid (5-15 msgs) | Stay focused |
| 🔴 | Long (>15 msgs) | Consider summarizing progress |

---

*v11.0.0 "Monolith" | One file. Full context. No jumping.*
