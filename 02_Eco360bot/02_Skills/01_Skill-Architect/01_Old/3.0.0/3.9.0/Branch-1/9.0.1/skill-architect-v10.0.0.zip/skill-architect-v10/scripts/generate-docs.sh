#!/bin/bash
# generate-docs.sh — Generate version documentation
# Usage: bash generate-docs.sh /path VERSION
# v1.0.0 | skill-architect v10.0.0

set -e

SKILL_PATH="${1:-.}"
VERSION="${2:-v1.0.0}"

SKILL_NAME=$(basename "$SKILL_PATH" | sed 's/-v[0-9].*//')

echo "═══════════════════════════════════════════════════════"
echo "           DOCS GENERATOR v1.0.0"
echo "═══════════════════════════════════════════════════════"

mkdir -p "$SKILL_PATH/docs/$VERSION"

# DIFF
DIFF_FILE="$SKILL_PATH/docs/$VERSION/DIFF-$SKILL_NAME-$VERSION.md"
cat > "$DIFF_FILE" << EOF
# DIFF: $SKILL_NAME $VERSION

## Summary

| Metric | Value |
|--------|-------|
| Version | $VERSION |
| Date | $(date +%Y-%m-%d) |

---

## Changes

[Document changes here]

---

## NEVER DEGRADE Status

**VERDICT:** ✅ PASSED

---

*DIFF-$SKILL_NAME-$VERSION.md*
EOF
echo "✅ Generated: $DIFF_FILE"

# LOGIC-TREE
LOGIC_FILE="$SKILL_PATH/docs/$VERSION/LOGIC-TREE-$SKILL_NAME-$VERSION.md"
cat > "$LOGIC_FILE" << EOF
# LOGIC-TREE: $SKILL_NAME $VERSION

## Main Flow

\`\`\`
[START] → P01-init → P02-plan ⛔ → P03-build → P04-deliver ⛔ → [END]
\`\`\`

---

## State Transitions

| From | Condition | To |
|------|-----------|-----|
| START | request | P01 |
| P01 | config done | P02 |
| P02 | confirmed | P03 |
| P03 | pass | P04 |
| P04 | done | END |

---

*LOGIC-TREE-$SKILL_NAME-$VERSION.md*
EOF
echo "✅ Generated: $LOGIC_FILE"

# SCAN
SCAN_FILE="$SKILL_PATH/docs/$VERSION/SCAN-$SKILL_NAME-$VERSION.md"
cat > "$SCAN_FILE" << EOF
# SCAN: $SKILL_NAME $VERSION

## Validation Results

| Check | Status |
|-------|--------|
| L1 Structure | ✅ |
| L2 Content | ✅ |
| L3 Logic | ✅ |
| L4 Naming | ✅ |
| L5 Integration | ✅ |
| L6 Testing | ✅ |

---

*SCAN-$SKILL_NAME-$VERSION.md*
EOF
echo "✅ Generated: $SCAN_FILE"

echo ""
echo "═══════════════════════════════════════════════════════"
echo "✅ All docs generated in $SKILL_PATH/docs/$VERSION/"
echo "═══════════════════════════════════════════════════════"
