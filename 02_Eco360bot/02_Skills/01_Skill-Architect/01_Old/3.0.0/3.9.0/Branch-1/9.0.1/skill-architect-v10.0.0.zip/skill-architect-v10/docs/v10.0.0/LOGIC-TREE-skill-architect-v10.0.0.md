# LOGIC-TREE: skill-architect v10.0.0

## Decision Flow

```
[User Request]
     │
     ▼
┌─────────────────┐
│ Read SKILL.md   │
│ → FIRST ACTION  │
└─────────────────┘
     │
     ▼
┌─────────────────┐
│ Read P00-router │
│ → Classify      │
└─────────────────┘
     │
     ├── "create/update/refactor" ──► P01-init
     │                                    │
     │                                    ▼
     │                              ┌──────────┐
     │                              │ PRE-ACT  │
     │                              │ → Steps  │
     │                              │ → EXIT   │
     │                              └──────────┘
     │                                    │
     │                                    ▼
     │                              ┌──────────┐
     │                              │ P02-plan │
     │                              │ ⛔ BLOCK │
     │                              └──────────┘
     │                                    │
     │                         ┌──────────┴──────────┐
     │                         │                     │
     │                    [invalid]              [valid]
     │                         │                     │
     │                         ▼                     ▼
     │                    Stay P02            ┌──────────┐
     │                                        │ P03-build│
     │                                        │ → Create │
     │                                        │ → Valid  │
     │                                        └──────────┘
     │                                              │
     │                                    ┌────────┴────────┐
     │                                    │                 │
     │                               [FAIL]            [PASS]
     │                                    │                 │
     │                                    ▼                 ▼
     │                               Fix + retry     ┌──────────┐
     │                                               │P04-deliver│
     │                                               │ ⛔ BLOCK  │
     │                                               └──────────┘
     │                                                     │
     │                                          ┌─────────┴─────────┐
     │                                          │                   │
     │                                     [invalid]            [valid]
     │                                          │                   │
     │                                          ▼                   ▼
     │                                     Stay P04            [END]
     │
     └── "checkup" ──► bash scripts/audit.sh ──► [REPORT]
```

## Self-Routing Mechanism

Each protocol contains:
1. **PRE-ACTION**: What to read/run before work
2. **Steps**: What to do
3. **EXIT CRITERIA**: When done, where to go
4. **Anchor with NEXT**: Self-instruction for next response

## Recovery Logic

```
[Context Lost]
     │
     ▼
Find last anchor in conversation
     │
     ▼
Extract: protocol + status + NEXT
     │
     ▼
Read that protocol file
     │
     ▼
Execute PRE-ACTION
     │
     ▼
Resume
```

---

*LOGIC-TREE-skill-architect-v10.0.0.md | skill-architect v10.0.0*
