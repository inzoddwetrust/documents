# Session Indicator

Context tracking for conversation state.

---

## Format

```
🟢 fresh | 🟡 mid | 🔴 long
```

---

## Thresholds

| Indicator | Condition |
|-----------|-----------|
| 🟢 fresh | <5 messages AND no heavy files |
| 🟡 mid | 5-15 messages OR 1-2 large files |
| 🔴 long | >15 messages OR many files/code |

---

## Aggravating Factors

Shift level up if:
- File >500 lines loaded
- >5 tool calls in session
- Large artifact generated
- Many code blocks in history

---

## Usage

End every response with context anchor including session:

```
⚙️ skill-architect v10.0.0 · P03-build · building
🟡 mid
```

---

*session-indicator.md v1.0.0 | skill-architect v10.0.0*
