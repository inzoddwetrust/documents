#!/bin/bash
# audit.sh — Full skill audit L1-L10
# Usage: bash audit.sh /path/to/skill
# v1.0.0 | skill-architect v10.0.0

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

SKILL_PATH="${1:-.}"
SCRIPT_DIR="$(dirname "$0")"

echo "═══════════════════════════════════════════════════════"
echo "               FULL SKILL AUDIT v1.0.0"
echo "═══════════════════════════════════════════════════════"
echo "Path: $SKILL_PATH"
echo "Time: $(date)"
echo ""

TOTAL_ERRORS=0
TOTAL_WARNINGS=0

# Phase 1: Standard Validation
echo -e "${CYAN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║         PHASE 1: STANDARD VALIDATION (L1-L6)         ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""

bash "$SCRIPT_DIR/validate.sh" "$SKILL_PATH" || ((TOTAL_ERRORS++))

# Phase 2: SSOT Check
echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║         PHASE 2: SSOT CHECK                          ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""

if [ -f "$SCRIPT_DIR/ssot-check.sh" ]; then
    bash "$SCRIPT_DIR/ssot-check.sh" "$SKILL_PATH" || ((TOTAL_WARNINGS++))
fi

# Phase 3: Documentation
echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║         PHASE 3: DOCUMENTATION (L9)                  ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""

bash "$SCRIPT_DIR/validate.sh" --docs "$SKILL_PATH" || ((TOTAL_WARNINGS++))

# Phase 4: Feature Registry
echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║         PHASE 4: FEATURE REGISTRY (L10)              ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""

if [ -f "$SCRIPT_DIR/feature-registry.sh" ]; then
    bash "$SCRIPT_DIR/feature-registry.sh" "$SKILL_PATH" || ((TOTAL_WARNINGS++))
fi

# Phase 5: Genetic Audit
echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║         PHASE 5: GENETIC AUDIT                       ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""

if [ -f "$SCRIPT_DIR/genetic-audit.sh" ]; then
    bash "$SCRIPT_DIR/genetic-audit.sh" "$SKILL_PATH" || ((TOTAL_WARNINGS++))
fi

# Summary
echo ""
echo "═══════════════════════════════════════════════════════"
echo "                  AUDIT SUMMARY"
echo "═══════════════════════════════════════════════════════"
echo -e "Errors:   ${RED}$TOTAL_ERRORS${NC}"
echo -e "Warnings: ${YELLOW}$TOTAL_WARNINGS${NC}"

if [ "$TOTAL_ERRORS" -eq 0 ]; then
    echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              ✅ AUDIT PASSED                          ║${NC}"
    echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
    exit 0
else
    echo -e "${RED}╔═══════════════════════════════════════════════════════╗${NC}"
    echo -e "${RED}║              ❌ AUDIT FAILED                          ║${NC}"
    echo -e "${RED}╚═══════════════════════════════════════════════════════╝${NC}"
    exit 1
fi
