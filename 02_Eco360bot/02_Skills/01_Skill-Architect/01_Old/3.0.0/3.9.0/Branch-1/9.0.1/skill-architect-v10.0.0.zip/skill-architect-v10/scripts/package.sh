#!/bin/bash
# package.sh — Create .skill archive
# Usage: bash package.sh /path/to/skill
# v1.0.0 | skill-architect v10.0.0

set -e

SKILL_PATH="${1:-.}"
SKILL_NAME=$(basename "$SKILL_PATH")

cd "$(dirname "$SKILL_PATH")"

echo "═══════════════════════════════════════════════════════"
echo "              SKILL PACKAGER v1.0.0"
echo "═══════════════════════════════════════════════════════"

OUTPUT="$SKILL_NAME.skill"

zip -r "$OUTPUT" "$SKILL_NAME/" -x "*.DS_Store" -x "*__MACOSX*"

echo ""
echo "Verifying archive..."
file "$OUTPUT"
unzip -t "$OUTPUT" > /dev/null

echo ""
echo "═══════════════════════════════════════════════════════"
echo "✅ Created: $OUTPUT"
echo "═══════════════════════════════════════════════════════"
