#!/bin/bash
# generate-manifest.sh — Generate MANIFEST.md for skill
# Usage: bash generate-manifest.sh /path/to/skill
# v1.0.0 | skill-architect v10.0.0

set -e

SKILL_PATH="${1:-.}"

if [ ! -f "$SKILL_PATH/SKILL.md" ]; then
    echo "❌ SKILL.md not found"
    exit 1
fi

SKILL_NAME=$(grep "^name:" "$SKILL_PATH/SKILL.md" | sed 's/name: *//' | tr -d '"' || basename "$SKILL_PATH")
VERSION=$(grep -oP 'v\d+\.\d+\.\d+' "$SKILL_PATH/SKILL.md" | head -1 || echo "v1.0.0")

OUTPUT="$SKILL_PATH/MANIFEST.md"

cat > "$OUTPUT" << EOF
# MANIFEST: $SKILL_NAME $VERSION

## Core Files

| File | Lines | Required |
|------|-------|----------|
EOF

# Core files
for f in SKILL.md README-*.md CHANGELOG-*.md; do
    if [ -f "$SKILL_PATH/$f" ]; then
        LINES=$(wc -l < "$SKILL_PATH/$f")
        echo "| $f | $LINES | ✅ |" >> "$OUTPUT"
    fi
done

# Protocols
if [ -d "$SKILL_PATH/protocols" ]; then
    echo "" >> "$OUTPUT"
    echo "## Protocols" >> "$OUTPUT"
    echo "" >> "$OUTPUT"
    echo "| File | Lines |" >> "$OUTPUT"
    echo "|------|-------|" >> "$OUTPUT"
    
    for f in "$SKILL_PATH/protocols"/*.md; do
        [ -f "$f" ] || continue
        NAME=$(basename "$f")
        LINES=$(wc -l < "$f")
        echo "| $NAME | $LINES |" >> "$OUTPUT"
    done
fi

# Reference
if [ -d "$SKILL_PATH/reference" ]; then
    echo "" >> "$OUTPUT"
    echo "## Reference" >> "$OUTPUT"
    echo "" >> "$OUTPUT"
    echo "| File | Lines |" >> "$OUTPUT"
    echo "|------|-------|" >> "$OUTPUT"
    
    for f in "$SKILL_PATH/reference"/*.md; do
        [ -f "$f" ] || continue
        NAME=$(basename "$f")
        LINES=$(wc -l < "$f")
        echo "| $NAME | $LINES |" >> "$OUTPUT"
    done
fi

# Scripts
if [ -d "$SKILL_PATH/scripts" ]; then
    echo "" >> "$OUTPUT"
    echo "## Scripts" >> "$OUTPUT"
    echo "" >> "$OUTPUT"
    echo "| File | Lines |" >> "$OUTPUT"
    echo "|------|-------|" >> "$OUTPUT"
    
    for f in "$SKILL_PATH/scripts"/*.sh; do
        [ -f "$f" ] || continue
        NAME=$(basename "$f")
        LINES=$(wc -l < "$f")
        echo "| $NAME | $LINES |" >> "$OUTPUT"
    done
fi

# Footer
echo "" >> "$OUTPUT"
echo "---" >> "$OUTPUT"
echo "" >> "$OUTPUT"
echo "*MANIFEST.md | Generated $(date +%Y-%m-%d)*" >> "$OUTPUT"

echo "✅ Generated: $OUTPUT"
