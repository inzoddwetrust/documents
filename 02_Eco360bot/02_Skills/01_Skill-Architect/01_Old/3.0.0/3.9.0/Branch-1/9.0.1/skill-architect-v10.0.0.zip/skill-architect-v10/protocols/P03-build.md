# P03-build: Build

Create skill files with validation.

---

## ⚠️ PRE-ACTION

1. If update: capture baseline `bash scripts/feature-registry.sh [old-path]`
2. Read: `reference/quality-gates.md`

---

## Steps

1. **Create structure:**
   ```
   mkdir -p {protocols,reference,scripts,docs/vX.Y.Z}
   ```

2. **Build in order:**
   - C1: SKILL.md, README, MANIFEST, CHANGELOG
   - C2: protocols/P00-P04
   - C5: reference/*.md
   - C4: scripts/*.sh

3. **Validate after each category:**
   ```bash
   bash scripts/validate.sh [path] --phase=C#
   ```

---

## ✅ EXIT CRITERIA

Run: `bash scripts/validate.sh [path]`
- PASS → read P04-deliver.md
- FAIL → fix, re-run

---

## Anchor

```
⚙️ skill-architect v10.0.0 · P03-build · [building|validating|ready]
[session] | NEXT: [current action or "validate → P04"]
```

---

*P03-build.md | skill-architect v10.0.0*
