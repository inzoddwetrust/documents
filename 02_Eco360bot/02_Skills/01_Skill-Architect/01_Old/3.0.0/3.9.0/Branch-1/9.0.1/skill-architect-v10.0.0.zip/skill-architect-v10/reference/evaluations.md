# Test Evaluations

Scenarios for skill validation.

---

## E1: New Skill Creation

| Step | Expected |
|------|----------|
| "create skill: X" | P01-init activates |
| Config complete | → P02-plan |
| Present plan | Wait for confirmation |
| "yes" | → P03-build |
| Create files | Run validate.sh |
| Validation pass | → P04-deliver |
| Package + deliver | Present files |

---

## E2: Skill Update

| Step | Expected |
|------|----------|
| "update: changes" | P01-init activates |
| Locate existing | Load previous |
| Plan changes | Show C#-F## impact |
| "go" | → P03-build |
| Run --degrade | Must PASS |
| Compare registries | 0 features lost |
| Deliver | Show comparison |

---

## E3: Checkup

| Step | Expected |
|------|----------|
| "checkup" | → audit.sh |
| Run all validations | L1-L10 |
| Run genetic-audit | Inheritance % |
| Generate report | Show results |

---

## E4: Invalid Confirmation

| Input | Expected |
|-------|----------|
| "ok" | ❌ Stay in P02 |
| "got it" | ❌ Re-ask |
| "yes" | ✅ Proceed |

---

## E5: NEVER DEGRADE Trigger

| Action | Expected |
|--------|----------|
| Remove feature | ⛔ BLOCKED |
| >30% line loss | ⚠️ WARNING |
| Remove category | ⛔ BLOCKED |

---

*evaluations.md v1.0.0 | skill-architect v10.0.0*
