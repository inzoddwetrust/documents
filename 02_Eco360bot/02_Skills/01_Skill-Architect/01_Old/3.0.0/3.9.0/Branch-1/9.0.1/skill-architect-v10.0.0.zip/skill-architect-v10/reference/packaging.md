# Packaging

Skill archive structure and rules.

---

## Archive Structure

```
skill-name-vX.Y.Z.skill (ZIP)
└── skill-name-vX.Y.Z/
    ├── SKILL.md          (required)
    ├── README-{name}.md  (required)
    ├── MANIFEST.md       (required if reference/)
    ├── CHANGELOG-{name}.md
    ├── protocols/
    ├── reference/
    ├── scripts/
    └── docs/
```

---

## Rules

| Rule | Value |
|------|-------|
| Extension | .skill (ZIP format) |
| Root | Single folder, not loose files |
| Folder name | skill-name-vX.Y.Z (with version!) |
| SKILL.md | Root of folder |
| Format | ZIP (not tar, not gzip) |

---

## ⛔ PRE-PACKAGE CHECKLIST

```
□ Folder name = skill-name-vX.Y.Z
□ SKILL.md in root
□ README-{name}.md exists
□ MANIFEST.md exists (if reference/)
□ No temp files (PLAN, scratch)
□ All scripts tested
□ FEATURE-REGISTRY generated
```

---

## Commands

```bash
cd /home/claude
zip -r skill-name-vX.Y.Z.skill skill-name-vX.Y.Z/

# Verify:
file skill-name-vX.Y.Z.skill  # Must: "Zip archive"
unzip -t skill-name-vX.Y.Z.skill  # Must: "No errors"

cp *.skill /mnt/user-data/outputs/
```

---

*packaging.md v1.0.0 | skill-architect v10.0.0*
