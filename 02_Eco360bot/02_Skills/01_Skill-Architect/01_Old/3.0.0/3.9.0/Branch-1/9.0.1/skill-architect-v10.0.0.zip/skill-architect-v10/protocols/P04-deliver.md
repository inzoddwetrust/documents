# P04-deliver: Delivery ⛔ BLOCKING

Package and deliver skill.

---

## ⚠️ PRE-ACTION

1. Run: `bash scripts/validate.sh [path]` — must PASS
2. Run: `bash scripts/feature-registry.sh [path]`
3. If update: compare registries (NEVER DEGRADE)

---

## Steps

1. Generate docs: `bash scripts/generate-docs.sh [path]`
2. Package: `bash scripts/package.sh [path]`
3. Present: link + registry + NEVER DEGRADE status
4. Ask confirmation

---

## ⛔ BLOCKING

| ✅ | ❌ |
|----|-----|
| yes, go, proceed | anything else |

---

## ✅ EXIT CRITERIA

On confirm → copy to `/mnt/user-data/outputs/` → END

---

## Anchor

```
⚙️ skill-architect v10.0.0 · P04-deliver · [status] ⛔
[session] | NEXT: user confirms → outputs → END
```

---

*P04-deliver.md | skill-architect v10.0.0*
