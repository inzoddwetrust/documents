# SSOT Check

Single Source of Truth validation documentation.

---

## Purpose

Ensure no duplicate definitions across skill files.

---

## SSOT Rules

| Element | Canonical Source | ❌ Duplicate In |
|---------|------------------|-----------------|
| Frontmatter rules | templates.md | other files |
| Version format | naming.md | SKILL.md |
| Context anchor | templates.md | protocols |
| Commands | SKILL.md | protocols |
| Confirmation rules | SKILL.md | P02-plan |

---

## What Script Checks

1. **Constraint duplication** — "< 300", "BLOCKING", etc.
2. **Command duplication** — "zip -r", "bash scripts/"
3. **Section overlap** — repeated rule sections
4. **Repeated headers** — same ## headers across files

---

## Thresholds

| Pattern | OK | Warning | Error |
|---------|-----|---------|-------|
| Constraint mentions | ≤2 | 3 | >3 |
| Command repeats | ≤3 | 4-5 | >5 |
| Same header | ≤2 | 3 | >3 |

---

## Command

```bash
bash scripts/ssot-check.sh /path
```

---

## Output

```
SSOT CHECK v1.0.0

PHASE 1: CONSTRAINT DUPLICATION
  ✓ '< 300': 2
  ✗ 'BLOCKING': 5 — SSOT violation

PHASE 2: COMMAND DUPLICATION
  ✓ 'zip -r': 2

SSOT SUMMARY
Issues: 1
Warnings: 0
❌ SSOT CHECK FAILED
```

---

*ssot-check.md v1.0.0 | skill-architect v10.0.0*
