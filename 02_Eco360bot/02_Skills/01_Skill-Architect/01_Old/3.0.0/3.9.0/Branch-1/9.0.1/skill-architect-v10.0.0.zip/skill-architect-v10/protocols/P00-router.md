# P00-router: State Machine

Routes requests and manages recovery.

---

## Decision Table

| Input | Route |
|-------|-------|
| "create skill" / "update" / "refactor" | → P01-init |
| "checkup" | → `bash scripts/audit.sh` |
| confirmation at P02 ⛔ | → P03-build |
| validation pass at P03 | → P04-deliver |
| confirmation at P04 ⛔ | → END |

---

## State Flow

```
[REQUEST] → P00 → P01 → P02 ⛔ → P03 → P04 ⛔ → [END]
```

---

## Recovery Protocol

If context lost:
1. Find last anchor in conversation
2. Read protocol file for that state
3. Execute PRE-ACTION
4. Resume

---

## Self-Check

Before ANY response, verify:
- Did I read current protocol's PRE-ACTION?
- Does my anchor include NEXT action?

---

*P00-router.md | skill-architect v10.0.0*
