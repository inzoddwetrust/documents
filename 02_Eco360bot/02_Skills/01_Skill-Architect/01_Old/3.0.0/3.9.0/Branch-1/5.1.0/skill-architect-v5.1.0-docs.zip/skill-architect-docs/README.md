# Skill Architect v5.1.0 "Restoration"

> Создаёт скиллы Claude (инструменты) и базы знаний проектов.

---

## Что это?

Skill Architect — мета-скилл для создания других скиллов. Работает в двух режимах:

| Режим | Создаёт | Для чего |
|-------|---------|----------|
| **Tool Mode** | Инструменты Claude | Генераторы, анализаторы, процессоры |
| **Project Mode** | Базы знаний | Бизнес-проекты, стартапы, SSOT |

---

## Быстрый старт

### Tool Mode (по умолчанию)

```
create skill: генератор промптов для fashion контента
```

```
update: добавить поддержку видео
[прикрепить .skill файл]
```

```
refactor
[прикрепить .skill файл]
```

### Project Mode

```
create project: CloudSync
```

```
import project
[прикрепить pitch deck / one-pager]
```

Внутри созданного project-skill:
```
update team      # обновить данные
generate pitch-deck    # создать документ
```

---

## Workflow

Все операции следуют одному процессу:

```
Plan → Confirm → Build → Validate → Deliver
```

1. **Plan** — создание Planning Document
2. **Confirm** — ожидание явного подтверждения ("да", "go")
3. **Build** — создание файлов
4. **Validate** — запуск скриптов проверки
5. **Deliver** — 3 шага: SKILL → DOCS → SCAN

---

## Tool Mode

Создаёт скиллы-инструменты с `reference/` папкой.

### Шаблоны

| Тип | Ключевые слова |
|-----|----------------|
| Analysis | analyze, assess, review |
| Investigation | research, find, explore |
| Content | create, generate, write |
| Data | process, transform, extract |
| Code | build, implement, develop |

### Движки

- **INoT** — для критического анализа
- **Multi-Perspective** — для полного охвата
- **Security** — для пользовательского ввода
- **Validation** — для критичного вывода

---

## Project Mode

Создаёт базы знаний с `data/` папкой (YAML модули).

### Модули данных (10)

| Модуль | Содержит |
|--------|----------|
| core | миссия, стадия, статус |
| team | основатели, команда, найм |
| product | фичи, метрики, ценообразование |
| market | TAM/SAM/SOM, конкуренты |
| finances | revenue, funding, unit economics |
| tech | стек, архитектура |
| roadmap | vision, OKRs, milestones |
| risks | риски, assumptions |
| clients | аккаунты, testimonials |
| decisions | ADR записи |

### Генерация документов

Формула: `DOCUMENT = [MODULES] × FORMAT × AUDIENCE × PURPOSE × TONE`

Поддерживаемые документы:
- Pitch Deck
- One-Pager
- Investor Update
- Sales Deck
- Press Release
- Job Posting

---

## Файловая структура

### Tool Mode
```
skill-name/
├── SKILL.md        # English, <300 строк
├── README.md       # Язык пользователя
├── MANIFEST.md     # Трекинг файлов
├── reference/      # Шаблоны, примеры
└── scripts/        # Валидация
```

### Project Mode
```
project-name-project/
├── SKILL.md        # English, <300 строк
├── README.md       # Язык пользователя
├── MANIFEST.md     # Трекинг файлов
├── CHANGELOG.md    # История версий
└── data/           # YAML модули
    ├── core.yaml
    ├── team.yaml
    └── ...
```

---

## Принципы Clean Skill

1. **Density** — каждая строка несёт смысл
2. **No fluff** — никаких "Sure!", дисклеймеров
3. **N/2** — запросили N слов, выдай N/2

---

## Валидация

```bash
# Структура скилла
bash scripts/validate-skill.sh /path/to/skill

# Соглашения именования
bash scripts/validate-naming.sh /path/to/skill

# Глубокий аудит (Tool Mode)
bash scripts/audit-skill.sh /path/to/skill

# Глубокий аудит (Project Mode)
bash scripts/audit-project.sh /path/to/project
```

---

## Доставка (3 шага)

| Шаг | Что | Ждём |
|-----|-----|------|
| 1 | .skill файл | "да" |
| 2 | docs.zip | "да" |
| 3 | Final Scan | — |

---

## Версионирование

- **MAJOR** — breaking changes, новые режимы
- **MINOR** — новые фичи, reference файлы
- **PATCH** — баг-фиксы, опечатки

---

## Что нового в v5.1.0

### Восстановлено из v3.9.0
- **Activation** — `Skill Architect ready. Purpose?`
- **Config** — сбор требований
- **REFACTOR Protocol** — полный, с bash командами
- **UPDATE Protocol** — полный, с bash командами
- **Diff Report** — формат отчёта
- **Critical Rules** — таблица правил

### Добавлено
- **⛔ NEVER DEGRADE** — защита от деградации качества
- **Reference Reading** — обязательное чтение reference/
- **Project REFACTOR** — рефакторинг Project Mode
- **SSOT Rules** — правила против дублирования
- **audit-project.sh** — аудит Project Mode

### Исправлено
- validate-skill.sh баг парсинга MANIFEST
- Синхронизация 300 vs 350 во всех файлах
- Token Counter формат

---

*Skill Architect v5.1.0 "Restoration"*
