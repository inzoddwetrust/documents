# skill-architect v4.0.0 — Action Plan

Quick reference for implementing improvements.

---

## TL;DR

**Current Score:** 84/100 ⭐⭐⭐⭐ (Good)  
**Target Score:** 92/100 ⭐⭐⭐⭐⭐ (Excellent)

**Main Issues:**
1. Activation ceremony wastes tokens
2. Token tracking not enforced
3. Too many protocols (cognitive overload)
4. SKILL.md could be 26% shorter

**Estimated Impact:** +8 points, -1200 tokens per load, -30 lines

---

## Priority Matrix

| Priority | Change | Impact | Effort | ROI |
|----------|--------|--------|--------|-----|
| 🔴 P0 | Mandatory token counter | High | Low | ⭐⭐⭐⭐⭐ |
| 🔴 P0 | Remove activation ceremony | High | Low | ⭐⭐⭐⭐⭐ |
| 🔴 P0 | Add Quick Start | High | Low | ⭐⭐⭐⭐⭐ |
| 🟡 P1 | Unify protocols | Medium | Medium | ⭐⭐⭐⭐ |
| 🟡 P1 | Compress tables → prose | Medium | Medium | ⭐⭐⭐⭐ |
| 🟢 P2 | Add Planning Doc examples | Low | Low | ⭐⭐⭐ |
| 🟢 P2 | Update description | Low | Low | ⭐⭐⭐ |

---

## Phase 1: Quick Wins (30 min)

### Change 1: Add Mandatory Token Counter

**Location:** Top of SKILL.md (after frontmatter)

**Add:**
```markdown
## ⚠️ MANDATORY: Token Counter

**NON-NEGOTIABLE — EVERY response MUST end with:**

```
🟡 -[cost] | ~[remaining] 🟢
```

### Self-Test (Run on Activation)

Before responding, verify:

1. ✅ Token counter WILL appear at end of THIS response
2. ✅ Counter WILL appear on ALL future responses

If any check fails → fix immediately.

---
```

**Why:** Prevents token loss, increases transparency. Seen in clean-protocol, idea-pipeline.

---

### Change 2: Remove Activation Ceremony

**Location:** Line 13-14

**Remove:**
```markdown
Response: `Skill Architect ready. Purpose?`
```

**Replace with:**
```markdown
Start immediately. If unclear, ask: `Purpose? Triggers?`
```

**Why:** Saves tokens, reduces friction. Matches public skills.

---

### Change 3: Add Quick Start

**Location:** After "Activation" section (line ~20)

**Add:**
```markdown
## Quick Start

**Create new skill:**
```
create skill: [purpose and triggers]
```

**Update existing skill:**
```
[attach .skill file] + "update: [changes]"
```

**Refactor skill:**
```
[attach .skill file] + "refactor this skill"
```

All workflows follow: Plan → Confirm → Build → Validate → Deliver

---
```

**Why:** Faster onboarding. Seen in pdf, product-self-knowledge.

---

## Phase 2: Compression (1 hour)

### Change 4: Unify Protocols

**Location:** Lines 66-102 (REFACTOR + UPDATE sections)

**Replace both with:**
```markdown
## Skill Modification Workflow

Universal steps (adjust based on task):

1. **Snapshot** — Copy original (if exists)
2. **Analyze** — Understand current state
   - CREATE: Skip to step 3
   - UPDATE: Light analysis
   - REFACTOR: Deep dive + audit script
3. **Plan** — Planning Document + Chat Verification
4. **Confirm** — Wait for user approval
5. **Build** — Implement changes
6. **Validate** — Run validation script
7. **Report** — Diff Report + confirm
8. **Package** — Zip and deliver

Complexity determined by trigger, not separate protocol.

---
```

**Savings:** 110 lines → 75 lines = 35 lines

---

### Change 5: Compress Tables

**Target sections:**
- Critical Rules (line 197-207) → Prose
- Versioning (line 177-184) → Compact list

**Example (Critical Rules):**

**Before:**
```markdown
| Rule | Requirement |
|------|-------------|
| SKILL.md | English, < 300 lines |
| README.md | Required |
...
```

**After:**
```markdown
## Requirements

Files: SKILL.md (English, <300), README.md, MANIFEST.md (if reference/)  
Before changes: Planning Document + Chat Verification  
After changes: Diff Report + user confirm
```

**Savings:** 15 lines → 8 lines = 7 lines

---

## Phase 3: Polish (30 min)

### Change 6: Add Planning Doc Example

**Location:** Line 53-60 (Planning Document section)

**Add inline example:**
```markdown
Example:
```markdown
### KEEP
- Validation scripts (core feature)

### REMOVE
- Python config (unused)

### ADD
- Token counter (mandatory)
```

Full template: `reference/planning-document.md`
```

**Why:** Shows format without needing to open reference.

---

### Change 7: Update Description

**Location:** Frontmatter (line 3)

**Before:**
```yaml
description: "v3.9.0 | Professional skill creation with MANIFEST integrity. Triggers: create skill, build skill, architect skill, создай скилл, обнови скилл, refactor skill."
```

**After:**
```yaml
description: "v4.0.0 | Pro creation + MANIFEST integrity. Mandatory tracking. Triggers: create/build/refactor skill, создай скилл."
```

**Savings:** 30 characters, removes redundancy

---

## Testing Checklist

After all changes:

```bash
# Validate structure
bash scripts/validate-skill.sh /home/claude/skill-architect

# Check line count
wc -l SKILL.md
# Expected: 160-180 lines (down from 223)

# Regenerate MANIFEST
bash scripts/generate-manifest.sh /home/claude/skill-architect 4.0.0

# Package
cd /home/claude && zip -r skill-architect-v4.0.0.skill skill-architect/
```

---

## Expected Outcomes

| Metric | v3.9.0 | v4.0.0 | Change |
|--------|--------|--------|--------|
| SKILL.md lines | 223 | ~165 | -26% |
| Quality score | 84/100 | 92/100 | +8 pts |
| Clarity | 17/20 | 19/20 | +2 |
| Speed | 6/10 | 9/10 | +3 |
| UX | 6/10 | 9/10 | +3 |
| Token cost/load | ~450 | ~330 | -27% |

---

## Changelog Preview

```markdown
### v4.0.0 (2025-11-29)

**BREAKING CHANGES:**
- Added: Mandatory token counter with self-test
- Changed: No activation ceremony (immediate start)

**NEW FEATURES:**
- Added: Quick Start section
- Added: Inline Planning Document example
- Added: Unified Skill Modification Workflow

**IMPROVEMENTS:**
- Changed: SKILL.md 223→165 lines (-26%)
- Changed: Compressed tables to prose
- Changed: Merged REFACTOR/UPDATE protocols
- Changed: Updated description (removed redundancy)

**UNCHANGED:**
- All reference/ files
- All scripts/
- README.md (update separately)
- Core workflow logic
```

---

## Migration Notes

### For Users

No action required. v4.0.0 is backward compatible. Old .skill files work as before.

### For skill-architect

New behavior:
1. **No longer responds** with "Skill Architect ready. Purpose?"
2. **Always outputs** token counter at end of response
3. **Uses unified workflow** (no separate REFACTOR/UPDATE)

Old behavior still supported if user explicitly says "use REFACTOR protocol".

---

## Risk Assessment

| Change | Risk Level | Mitigation |
|--------|------------|------------|
| Mandatory tracking | 🟢 Low | Self-test catches failures |
| Remove ceremony | 🟢 Low | Immediate start is standard |
| Unified workflow | 🟡 Medium | Document trigger mapping clearly |
| Compression | 🟢 Low | No logic changes, just format |

**Overall Risk:** 🟢 LOW (no data loss, backward compatible)

---

## Success Criteria

v4.0.0 is successful if:

✅ SKILL.md < 180 lines  
✅ Quality score ≥ 90/100  
✅ Token counter appears in 100% of responses  
✅ All validation scripts pass  
✅ No regressions in skill creation quality  
✅ User feedback positive (faster, clearer)

---

## Next Steps

1. **Review** this action plan
2. **Create** Planning Document for v4.0.0
3. **Run** Chat Verification
4. **Get** user confirmation
5. **Implement** in phases
6. **Test** thoroughly
7. **Package** and deliver

---

*Action Plan — skill-architect v3.9.0 → v4.0.0*  
*Estimated Total Time: 2 hours*  
*Confidence: HIGH*
