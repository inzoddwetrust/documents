# Skill Architect: План обновления v4.0.0 → v5.0.0

**Дата:** 2025-11-30  
**Модель:** Claude Opus 4.5  
**Тип:** MAJOR (breaking changes)

---

## 1. Контекст

Полная переработка архитектуры skill-architect на основе обсуждения:
- Модульность и переиспользование
- State machine с auto-reinit
- Разделение runtime/docs
- Clean protocol как базовый слой
- Single responsibility rule

---

## 2. Проблемы текущей версии (v4.0.0)

| Проблема | Где | Влияние |
|----------|-----|---------|
| Дублирование clean principles | SKILL.md:68-77 | Копипаста вместо ссылки |
| zip команда 8 раз | packaging, workflow, SKILL | Bloat |
| Нет state machine | — | Забываем инструкции |
| MANIFEST в скилле | skill/ | Техника в runtime |
| engines.md 372 строки | reference/ | Слишком большой |
| Нет single responsibility rule | — | Скиллы-монолиты |
| Нет CHANGELOG протокола | — | Теряем историю |
| Нет LOGIC-TREE | — | Логика не трассируется |

---

## 3. План изменений

### 3.1 УДАЛЯЕМ из скилла

| Что | Почему безопасно | Куда переносим |
|-----|------------------|----------------|
| MANIFEST.md | Техническая мета-информация | → docs/ |
| Clean Skill Principles (SKILL.md:68-77) | Дублирование | → @requires: clean-protocol |
| Повторы zip команд | Консолидация | → Одно место в packaging.md |
| Evaluation-Driven Development section | Мета-информация | → docs/development-guide.md |

### 3.2 ДОБАВЛЯЕМ в скилл

| Что | Зачем | Где |
|-----|-------|-----|
| State Machine | Auto-reinit каждый ответ | modules/state-machine.md |
| @requires: clean-protocol | Зависимость вместо копии | SKILL.md frontmatter |
| Single Responsibility Rule | Микро-скиллы > монолиты | SKILL.md |
| Question Protocol | Когда спрашивать | modules/question-protocol.md |
| Per-Response Protocol | Обязательная проверка на каждом ответе | SKILL.md (начало) |

### 3.3 ДОБАВЛЯЕМ в docs (новое)

| Что | Зачем |
|-----|-------|
| CHANGELOG.md | История версий с контекстом |
| LOGIC-TREE.md | Пайплайн в numbered tree + mermaid |
| VERSION-ANALYSIS.md | Ретроспективы (после 5 версий) |
| development-guide.md | Как развивать скилл |

### 3.4 ИЗМЕНЯЕМ

| Что | Было | Станет |
|-----|------|--------|
| SKILL.md размер | 290 строк | Target: 150-180 строк |
| engines.md | 372 строки, монолит | Разбить на 4 файла по движку |
| packaging.md | zip команды разбросаны | Единый источник |
| templates.md | Нет @requires | Добавить clean-protocol во все шаблоны |
| Структура | Плоская reference/ | modules/ + reference/ разделение |

### 3.5 НЕ ТРОГАЕМ

- scripts/validate-skill.sh (работает)
- scripts/audit-skill.sh (работает)
- scripts/generate-manifest.sh (работает, но вызов из docs)
- reference/planning-document.md (работает)
- reference/quality-checklist.md (работает)

---

## 4. Новая структура

### 4.1 Runtime (skill-architect-v5.0.0.skill)

```
skill-architect/
├── SKILL.md                      # 150-180 строк, чистая логика
├── README.md                     # Для пользователя
│
├── modules/                      # Runtime зависимости
│   ├── state-machine.md          # NEW: Фазы + переходы
│   └── question-protocol.md      # NEW: Когда спрашивать
│
├── reference/                    # Runtime справка
│   ├── planning-document.md      # Шаблон плана
│   ├── templates.md              # Шаблоны скиллов (обновить)
│   ├── packaging.md              # Консолидированный
│   ├── quality-checklist.md      # Без изменений
│   └── engines/                  # NEW: Разбитый engines.md
│       ├── inot.md
│       ├── multi-perspective.md
│       ├── security.md
│       └── validation.md
│
└── scripts/
    ├── validate-skill.sh
    ├── audit-skill.sh
    └── generate-manifest.sh
```

### 4.2 Docs (skill-architect-docs/)

```
skill-architect-docs/
├── MANIFEST.md                   # Перенесён из скилла
├── CHANGELOG.md                  # NEW: История версий
├── LOGIC-TREE.md                 # NEW: Пайплайн логика
├── VERSION-ANALYSIS.md           # NEW: После 5 версий
├── development-guide.md          # NEW: Evaluation-driven и др.
└── decisions/
    └── v5.0.0-decisions.md       # NEW: Контекст этого обновления
```

---

## 5. Детальные изменения по файлам

### 5.1 SKILL.md (полная переработка)

**Новая структура:**

```markdown
---
name: skill-architect
description: "v5.0.0 | Creates skills with modular architecture. Triggers: create skill, refactor skill, создай скилл."
requires:
  - clean-protocol
---

# Skill Architect v5.0.0

## ⚠️ Per-Response Protocol (MANDATORY)

BEFORE each response:
1. Determine current phase → load modules/state-machine.md
2. Check if questions needed → modules/question-protocol.md
3. Verify clean-protocol active

AFTER each response:
4. Token counter: 🟡 -[cost] | ~[remaining] 🟢

## Quick Start
[3-4 строки]

## Activation
[Триггеры, первый шаг]

## Core Rules

### Single Responsibility
One skill = one responsibility.
If skill does two things → split into two skills + @requires.

### Output Separation
- skill.skill = runtime only (SKILL, README, modules, reference, scripts)
- skill-docs/ = everything else (MANIFEST, CHANGELOG, LOGIC-TREE)

## Process
[Ссылка на state-machine.md]

## File Requirements
[Минимум: что должно быть в скилле]

## Resources
[Ссылки на modules/ и reference/]
```

**Строк:** ~150-180 (было 290)

### 5.2 modules/state-machine.md (NEW)

```markdown
# State Machine

## Phases

| # | Phase | Action | Next |
|---|-------|--------|------|
| 1 | INIT | Config dialog | 2 |
| 2 | RESEARCH | Analyze/snapshot | 3 |
| 3 | DESIGN | Template + engines | 4 |
| 4 | PLAN | Planning Document | 5 |
| 5 | CONFIRM | Wait for user | 6 |
| 6 | BUILD | Create files | 7 |
| 7 | VALIDATE | Run scripts | 8 |
| 8 | DELIVER | Package + docs | END |

## Auto-Reinit

Each response:
1. Parse user message → determine phase
2. Load phase-specific instructions
3. Execute
4. Update state

## Phase Detection

| User says | Phase |
|-----------|-------|
| "create skill", purpose unclear | INIT |
| "here's the info..." | RESEARCH |
| "use X template" | DESIGN |
| "looks good", "да" | CONFIRM → BUILD |
| "package it" | DELIVER |

## Transitions
[Mermaid diagram]
```

### 5.3 modules/question-protocol.md (NEW)

```markdown
# Question Protocol

## MUST ASK (blocks progress)

- Purpose undefined
- Triggers undefined  
- Risk > 30% when removing feature
- Architectural choice with trade-offs
- Ambiguous confirmation

## NEVER ASK

- Styling details
- Obvious clarifications
- "Are you sure?" confirmations
- Permission to proceed after explicit approval

## Format

DO:
```
Clarify: [specific question]
```

DON'T:
```
"Would you like me to...?"
"May I ask...?"
"Should I...?"
```
```

### 5.4 reference/engines/ (разбиение)

**Было:** engines.md (372 строки)

**Станет:**
- engines/inot.md (~80 строк)
- engines/multi-perspective.md (~60 строк)
- engines/security.md (~70 строк)
- engines/validation.md (~50 строк)
- engines/README.md (~30 строк) — обзор и выбор

### 5.5 templates.md (обновление)

**Добавить в каждый шаблон:**

```markdown
---
name: template-skill-name
description: "v1.0.0 | ..."
requires:
  - clean-protocol
---
```

**Добавить секцию:**

```markdown
## Output Separation

Runtime (.skill):
- SKILL.md, README.md
- modules/, reference/, scripts/ (if needed)

Docs (skill-docs/):
- MANIFEST.md, CHANGELOG.md, LOGIC-TREE.md
```

---

## 6. Docs файлы (создаём)

### 6.1 CHANGELOG.md

```markdown
# Changelog: skill-architect

## [5.0.0] - 2025-11-30

**Model:** Claude Opus 4.5  
**Type:** MAJOR (breaking)

### Added
- modules/state-machine.md: Auto-reinit protocol
- modules/question-protocol.md: When to ask
- Single Responsibility Rule
- Output Separation (runtime/docs)
- @requires: clean-protocol

### Changed
- SKILL.md: 290 → ~160 lines
- engines.md → engines/ (4 files)
- MANIFEST.md → docs/

### Removed
- Clean Skill Principles section (→ @requires)
- Evaluation-Driven section (→ docs/)
- Duplicate zip commands

### Decision Context
See: decisions/v5.0.0-decisions.md

### Regression Risks
- Старые скиллы без @requires не получат clean-protocol
- Mitigation: Добавить fallback проверку
```

### 6.2 LOGIC-TREE.md

[Уже создан пример — адаптируем под v5.0.0]

### 6.3 decisions/v5.0.0-decisions.md

```markdown
# Decisions: v5.0.0

## Context
Обсуждение с пользователем 2025-11-30.
Основные требования: модульность, state machine, разделение runtime/docs.

## Key Decisions

### D1: Clean Protocol как зависимость
**Было:** Копия принципов в SKILL.md
**Решение:** @requires: clean-protocol
**Причина:** Single source of truth, меньше дублирования

### D2: MANIFEST в docs
**Было:** MANIFEST.md в скилле
**Решение:** Переносим в skill-docs/
**Причина:** Техническая мета-информация ≠ runtime

### D3: Разбиение engines.md
**Было:** 372 строки в одном файле
**Решение:** 4 файла по движку
**Причина:** Легче поддерживать, читать, обновлять

### D4: Single Responsibility Rule
**Новое правило:** Один скилл = одна ответственность
**Причина:** Микро-скиллы надёжнее монолитов

### D5: State Machine
**Было:** Статичный workflow
**Решение:** Динамический state machine + auto-reinit
**Причина:** Context degrades, нужна реинициализация
```

---

## 7. Риски

| Риск | Вероятность | Митигация |
|------|-------------|-----------|
| Сломаем существующий функционал | Medium | Тестируем каждую фазу |
| State machine слишком сложный | Low | Начнём с простого, итерируем |
| Забудем перенести что-то важное | Medium | Чеклист + diff report |
| clean-protocol не готов | Medium | Обновляем сразу после |

---

## 8. План выполнения

### Phase 1: Подготовка
- [ ] Snapshot текущей версии
- [ ] Создать skill-architect-docs/ структуру
- [ ] Перенести MANIFEST.md

### Phase 2: Модули
- [ ] Создать modules/state-machine.md
- [ ] Создать modules/question-protocol.md
- [ ] Разбить engines.md на 4 файла

### Phase 3: SKILL.md
- [ ] Переписать с Per-Response Protocol
- [ ] Добавить @requires: clean-protocol
- [ ] Добавить Single Responsibility Rule
- [ ] Сократить до 150-180 строк

### Phase 4: Reference
- [ ] Консолидировать packaging.md
- [ ] Обновить templates.md с @requires
- [ ] Убрать дублирование

### Phase 5: Docs
- [ ] Создать CHANGELOG.md
- [ ] Создать LOGIC-TREE.md
- [ ] Создать decisions/v5.0.0-decisions.md

### Phase 6: Валидация
- [ ] Run validate-skill.sh
- [ ] Run audit-skill.sh
- [ ] Diff Report

### Phase 7: Доставка
- [ ] Package skill-architect-v5.0.0.skill
- [ ] Package skill-architect-docs/
- [ ] Ссылки пользователю

---

## 9. Чеклист подтверждения

- [ ] План понятен
- [ ] Структура согласована
- [ ] Разделение runtime/docs ок
- [ ] State machine подход ок
- [ ] Single responsibility rule ок
- [ ] Риски приемлемы
- [ ] Можно начинать

---

## 10. Языковая политика

| Компонент | Язык | Причина |
|-----------|------|---------|
| SKILL.md | English | Нативный для LLM |
| modules/*.md | English | Runtime |
| reference/*.md | English | Runtime |
| scripts/*.sh | English | Code |
| README.md | Русский | Для пользователя |
| docs/*.md | Русский | Для пользователя |

---

## 11. AI-Friendly разметка (NEW)

### Phase Tags
```markdown
<!-- @phase:INIT -->
<!-- @phase:BUILD -->
<!-- @checkpoint:blocking -->
```

### Load Directives
```markdown
<!-- @load:always -->
<!-- @load:on-demand -->
<!-- @reinit:per-response -->
```

### Cross-References
```markdown
<!-- @ref:packaging#zip-commands -->
<!-- @see:engines/inot.md -->
```

### Navigation
```markdown
## TL;DR
[Краткая суть в начале длинных файлов]

## Quick Nav
- [Phase 1](#phase-1)
- [Phase 2](#phase-2)
```

### Checklists (mental tracking)
```markdown
- [ ] Step 1
- [ ] Step 2  
- [x] Completed
```

---

## 12. Наследование практик (CRITICAL)

**Skill Architect = источник истины для всех создаваемых скиллов.**

### Автоматически наследуется в новые скиллы:

| Практика | Как внедряется |
|----------|----------------|
| @requires: clean-protocol | В frontmatter каждого шаблона |
| State Machine | Шаблон в templates.md (опционально) |
| Question Protocol | Секция в каждом шаблоне |
| Single Responsibility | Проверка при создании |
| Runtime/Docs separation | Стандартная структура вывода |
| AI-friendly разметка | Теги в шаблонах |
| Token counter | В каждом шаблоне |

### Чеклист перед созданием скилла:

```
□ @requires: clean-protocol добавлен
□ Question protocol секция есть
□ Single responsibility проверен
□ Docs структура создана отдельно
□ AI-теги расставлены
□ Token counter в конце
```

---

## 13. Новые скрипты

### scripts/init-docs.sh (NEW)
```bash
# Создаёт docs/ структуру для нового скилла
mkdir -p skill-name-docs/decisions
touch skill-name-docs/MANIFEST.md
touch skill-name-docs/CHANGELOG.md
touch skill-name-docs/LOGIC-TREE.md
```

### scripts/generate-manifest.sh (UPDATE)
```bash
# Теперь пишет в docs/ вместо skill/
OUTPUT_DIR="$SKILL_NAME-docs"
```

---

## 14. Чеклист подтверждения (обновлённый)

- [ ] План понятен
- [ ] Структура runtime/docs согласована
- [ ] Языковая политика (EN/RU) ок
- [ ] AI-friendly разметка ок
- [ ] Наследование практик в дочерние скиллы ок
- [ ] Новые скрипты ок
- [ ] Риски приемлемы
- [ ] **Можно начинать**

---

**Ожидаю подтверждение для старта.**

---

*Planning Document v5.0.0 | Model: Claude Opus 4.5 | Updated: 2025-11-30*
