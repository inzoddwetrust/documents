# Changelog — skill-tester

All notable changes to this skill.

---

## [1.0.1] — 2025-06-02

### Fixed
- Removed Cyrillic from SKILL.md (EN-only policy)
- Deleted orphan `{reference,scripts}` folder

### Changed
- Moved RU triggers to README.md
- Updated generator to skill-architect v6.2.0

### Unchanged
- 6-level testing framework
- Quick/Full modes
- TEST_REPORT.md output format
- All reference files

---

## [1.0.0] — 2025-06-02

### Added
- Initial release
- 6-level testing framework (L1-L6)
  - L1: Structural Audit
  - L2: Logic Consistency
  - L3: Coverage Analysis
  - L4: Simulation Testing
  - L5: Methodology Viability
  - L6: Interpretation Test
- Quick mode (L1-L3) and Full mode (L1-L6)
- TEST_REPORT.md output format
- Integration with skill-architect

---

*CHANGELOG.md v1.0.0 | skill-tester v1.0.1*
