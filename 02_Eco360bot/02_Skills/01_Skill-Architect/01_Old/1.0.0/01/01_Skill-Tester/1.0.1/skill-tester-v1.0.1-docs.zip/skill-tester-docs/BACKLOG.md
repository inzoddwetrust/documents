# Backlog — skill-tester

Future ideas and known issues.

---

## Planned: v1.1.0

| # | Feature | Priority | Effort |
|---|---------|----------|--------|
| 1 | Custom test cases from user | High | Medium |
| 2 | Comparison mode (v1 vs v2) | High | High |
| 3 | Deeper skill-architect integration | Medium | Low |
| 4 | Partial re-test (only changed files) | Medium | Medium |

---

## Planned: v2.0.0

| # | Feature | Priority | Effort |
|---|---------|----------|--------|
| 1 | Regression testing (baseline save) | High | High |
| 2 | Automated fix suggestions | Medium | High |
| 3 | CI/CD integration concept | Low | Medium |
| 4 | Benchmark database | Low | High |

---

## Known Issues

| # | Issue | Severity | Workaround |
|---|-------|----------|------------|
| 1 | L4 simulation limited accuracy | 🟡 | Disclaimer in report |
| 2 | Long sessions not fully testable | 🟡 | Manual testing recommended |
| 3 | False positives possible | 🟡 | Human review required |

---

## Open Questions

1. **Simulation depth** — optimal number of test cases per category?
2. **Self-testing** — can skill-tester test itself reliably?
3. **Benchmarks** — need reference "good skills" database?

---

## Ideas Parking

- Web search for best practices comparison
- Integration with other testing tools
- Visual report output (HTML)
- Severity auto-adjustment based on skill type

---

*BACKLOG.md v1.0.0 | skill-tester v1.0.1*
