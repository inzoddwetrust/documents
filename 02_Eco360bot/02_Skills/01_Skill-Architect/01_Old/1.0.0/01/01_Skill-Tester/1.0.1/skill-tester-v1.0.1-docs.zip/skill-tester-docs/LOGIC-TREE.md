# Logic Tree — skill-tester

Decision flow and routing logic.

---

## Main Flow

```
[INPUT: .skill or folder]
        │
        ▼
┌───────────────────┐
│ Is .skill file?   │
└───────────────────┘
    │ yes      │ no
    ▼          ▼
[Unpack]    [Use as-is]
    │          │
    └────┬─────┘
         ▼
┌───────────────────┐
│ Mode selection?   │
└───────────────────┘
    │ quick    │ full    │ specific
    ▼          ▼         ▼
[L1-L3]    [L1-L6]   [Ln only]
    │          │         │
    └────┬─────┴─────────┘
         ▼
[Generate TEST_REPORT.md]
         │
         ▼
[Deliver to /outputs/]
```

---

## Mode Selection

```
User input contains:
├── "full" / "полный" → Full mode (L1-L6)
├── "quick" / "быстр" → Quick mode (L1-L3)
├── "L4" / "L5" / "L6" → Specific level
└── nothing → Default: Quick mode
```

---

## Test Level Flow

```
[L1: Structural Audit]
    │ issues?
    ├── critical → flag, continue
    └── pass → continue
         │
         ▼
[L2: Logic Consistency]
    │ contradictions?
    ├── found → log, continue
    └── pass → continue
         │
         ▼
[L3: Coverage Analysis]
    │ gaps?
    ├── found → log, continue
    └── pass → continue
         │
    ┌────┴──── Quick mode stops here
    │
    ▼ (Full mode continues)
[L4: Simulation Testing]
    │ failures?
    ├── found → log, continue
    └── pass → continue
         │
         ▼
[L5: Methodology Viability]
    │ red flags?
    ├── found → log, continue
    └── pass → continue
         │
         ▼
[L6: Interpretation Test]
    │ ambiguities?
    ├── found → log
    └── pass
         │
         ▼
[Aggregate results]
```

---

## Severity Decision

```
Issue found:
├── Blocks functionality → 🔴 Critical
├── Degrades quality → 🟡 Warning
└── Minor improvement → 🟢 Observation
```

---

## Overall Status Decision

```
Results aggregated:
├── Any 🔴 Critical → FAIL
├── Only 🟡 + 🟢 → PASS WITH WARNINGS
└── Only 🟢 or none → PASS
```

---

## Report Generation

```
[Collect all findings]
        │
        ▼
[Sort by severity]
        │
        ▼
[Format per template]
        │
        ▼
[Add recommendations]
        │
        ▼
[Save TEST_REPORT.md]
```

---

*LOGIC-TREE.md v1.0.0 | skill-tester v1.0.1*
