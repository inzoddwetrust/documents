# Skill Tester

**Версия:** 1.0.0  
**Назначение:** Всестороннее тестирование Claude Skills

---

## Проблема

Скилы создаются, но не тестируются системно:
- Логические противоречия между секциями
- Неработающие edge cases
- Методики которые звучат хорошо, но не применимы
- Пробелы в покрытии
- Инструкции которые Claude интерпретирует не так

---

## Решение

6-уровневый аудит любого скила.

```
INPUT:  .skill файл или папка
OUTPUT: TEST_REPORT.md с находками и рекомендациями
```

---

## Уровни тестирования

| Уровень | Название | Что проверяет |
|---------|----------|---------------|
| L1 | Structural Audit | Файлы, naming, frontmatter |
| L2 | Logic Consistency | Противоречия, конфликты |
| L3 | Coverage Analysis | Пробелы в покрытии |
| L4 | Simulation Testing | Happy path, edge cases |
| L5 | Methodology Viability | Реалистичность методик |
| L6 | Interpretation Test | Как Claude понимает |

---

## Режимы

| Режим | Уровни | Время | Когда |
|-------|--------|-------|-------|
| **Quick** | L1-L3 | ~5 мин | Быстрая проверка |
| **Full** | L1-L6 | ~15 мин | Перед релизом |

По умолчанию: Quick.

---

## Использование

```
# Quick test
"тестируй скил" + attachment

# Full test  
"полный тест скила" + attachment

# Конкретный уровень
"проверь L4" + attachment
```

---

## Триггеры

**English:**
- `test skill` / `audit skill` / `validate skill`
- `quick test` / `full test`

**Русский:**
- `тестируй скил` / `аудит скила` / `проверь скил`
- `быстрый тест` / `полный тест`

---

## Output

TEST_REPORT.md содержит:
- Executive Summary (таблица по уровням)
- Critical Issues (must fix)
- Warnings (should fix)
- Observations (nice to fix)
- Test Results (pass/fail по тестам)
- Recommendations (приоритезированные действия)

---

## Severity

| Уровень | Значение | Действие |
|---------|----------|----------|
| 🔴 Critical | Блокирует работу | Must fix |
| 🟡 Warning | Снижает качество | Should fix |
| 🟢 Observation | Улучшение | Nice to fix |

---

## Интеграция

После тестирования:
```
skill-tester → находит проблемы
     ↓
skill-architect → "refactor" для исправления
```

TEST_REPORT формат понятен skill-architect.

---

## Ограничения

- Симуляция ≠ реальное использование
- Не тестирует внешние интеграции
- Возможны false positives
- Длинные сессии тестируются ограниченно

---

## Структура скила

```
skill-tester/
├── SKILL.md              # Core protocol (EN)
├── README.md             # Документация (RU)
├── MANIFEST.md           # Integrity tracking
├── reference/
│   ├── test-levels.md    # Детали L1-L6
│   ├── report-template.md# Шаблон отчёта
│   └── test-cases.md     # Генерация тестов
└── scripts/
    └── unpack-skill.sh   # Распаковка .skill
```

---

## Roadmap

### v1.1.0 (planned)
- Custom test cases от пользователя
- Comparison mode (v1 vs v2)
- Глубже интеграция с skill-architect

### v2.0.0 (future)
- Regression testing
- Automated fix suggestions
- Baseline сохранение

---

## Open Questions

1. Глубина симуляции — сколько test cases оптимально?
2. Self-testing — может ли тестировать сам себя?
3. Partial testing — только изменения?

→ Feedback welcome.

---

*v1.0.1 — EN/RU triggers separated*
