# 📋 Skills Ecosystem: Краткий список

---

## 🔧 МЕХАНИКИ (встраиваемые engines)

| Engine | Что делает | Когда использовать |
|--------|------------|-------------------|
| **INoT** | Виртуальные дебаты Agent_A vs Agent_B внутри одного вызова. Аргумент→Критика→Опровержение→Консенсус | Критический анализ, проверка выводов, снижение галлюцинаций |
| **Multi-Perspective** | 4+ независимых точки зрения с синтезом | Полный обзор, плюсы/минусы, stakeholder analysis |
| **Security** | Prompt scaffolding + validation + sanitization | User input, production, sensitive data |
| **Validation** | Самопроверка: completeness, consistency, accuracy | Критичный output, высокие требования к качеству |

---

## 🏗️ МЕТА-СКИЛЛЫ (создают скиллы)

| Скилл | Описание | Статус |
|-------|----------|--------|
| **skill-architect** | Создаёт скиллы с нуля через 7-фазный процесс | ✅ Есть |
| **skill-optimizer** | Анализирует и улучшает существующие скиллы | 🆕 Создать |
| **skill-composer** | Собирает сложные скиллы из простых (композиция) | 🆕 Создать |
| **skill-library** | Каталог механик, паттернов, готовых блоков | 🆕 Создать |

---

## 📦 ПРИКЛАДНЫЕ СКИЛЛЫ

| Скилл | Механики | Триггеры |
|-------|----------|----------|
| **deep-analysis** | INoT + Multi-Perspective + Validation | "глубокий анализ", "критический разбор" |
| **decision-maker** | INoT + Multi-Perspective | "помоги решить", "что выбрать", "плюсы минусы" |
| **risk-assessor** | Multi-Perspective + INoT | "оцени риски", "что может пойти не так" |
| **secure-skill-wrapper** | Security + Validation | "сделай безопасным", "production-ready" |
| **research-synthesizer** | Multi-Perspective + INoT + Validation | "синтезируй", "обобщи источники" |

---

## 🎯 Приоритеты создания

```
P0 (сейчас):     skill-library → deep-analysis
P1 (следующий):  skill-optimizer → decision-maker → secure-skill-wrapper  
P2 (потом):      skill-composer → risk-assessor → research-synthesizer
```

---

## ⚡ Quick Start: Как использовать механики

### Встроить INoT в скилл:
```xml
<include engine="inot">
  agents: [Analyst, Critic]
  max_rounds: 5
</include>
```

### Встроить Multi-Perspective:
```xml
<include engine="multi-perspective">
  perspectives: [Optimist, Pessimist, Pragmatist]
</include>
```

### Комбинации:
- **Light:** Validation only
- **Standard:** Multi-Perspective + Validation
- **Deep:** INoT + Multi-Perspective + Validation
- **Production:** Security + Validation
- **Maximum:** All engines

---

[📄 Полный Blueprint](./SKILLS_BLUEPRINT.md)
