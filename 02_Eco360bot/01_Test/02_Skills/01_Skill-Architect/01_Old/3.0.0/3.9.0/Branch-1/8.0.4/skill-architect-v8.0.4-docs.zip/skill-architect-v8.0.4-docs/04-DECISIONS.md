# Architectural Decisions

---

## ADR-001: Add "Protocol First, Always" Section

**Status:** Accepted

**Context:**  
Claude repeatedly skipped reading protocols before acting, leading to errors and rework. This happened even when protocols existed with clear instructions.

**Decision:**  
Add explicit anti-skip rules at SKILL.md level with forbidden patterns.

**Consequences:**
- (+) Explicit rule against "I know what to do"
- (+) Clear mandate: Following = Work
- (-) +15 lines to SKILL.md

---

## ADR-002: Add Iteration Principles Section

**Status:** Accepted

**Context:**  
Research on neural network / autistic cognition parallels revealed patterns applicable to skill iteration:
- ABA ↔ Reinforcement Learning → Gradient Feedback
- Dropout ↔ Context focus → Context Regularization
- TEACCH ↔ Structure → Single Component Rule

**Decision:**  
Add dedicated section with 3 principles derived from research.

**Consequences:**
- (+) Science-backed iteration methodology
- (+) Clear rules for debugging
- (-) +23 lines to SKILL.md

---

## ADR-003: Gradient Feedback Principle

**Status:** Accepted

**Context:**  
Gradient descent works through small iterative changes with verification. Same applies to skill development.

**Decision:**  
One small step → verify → next. No multi-change iterations.

**Consequences:**
- (+) Errors caught early
- (+) Clear cause identification
- (-) Potentially slower for simple changes

---

## ADR-004: Single Component Rule

**Status:** Accepted

**Context:**  
When multiple components change simultaneously, it's impossible to determine which change caused an error.

**Decision:**  
Don't change >1 component per iteration. Verify between changes.

**Consequences:**
- (+) Clear debugging
- (+) Prevents cascading errors
- (-) More commits/checkpoints

---

## ADR-005: Context Regularization

**Status:** Accepted

**Context:**  
Neural network dropout prevents overfitting by limiting active neurons. In skill development, focusing on one protocol/file at a time prevents context overload.

**Decision:**  
Formalize existing practice: one protocol at a time, one file in focus.

**Consequences:**
- (+) Explicit rule for implicit behavior
- (+) Reduced cognitive load

---

## ADR-006: Placement After BEFORE EVERY RESPONSE

**Status:** Accepted

**Context:**  
New sections need logical placement in SKILL.md structure.

**Decision:**  
Place Protocol First after BEFORE EVERY RESPONSE (reinforces it), then Iteration Principles before Context Anchor.

**Consequences:**
- (+) Logical flow: checks → rules → iteration → anchor
- (+) No disruption to existing structure

---

*04-DECISIONS.md v1.0.0 | skill-architect v8.0.4*
