# Backlog: skill-architect

Future improvements and ideas.

---

## ✅ Completed in v8.3.0

| ID | Item | Status |
|----|------|--------|
| B-006 | Version sync check in validate-skill.sh | ✅ Done (L8) |
| B-007 | Footer update automation | ✅ Done (update-version.sh) |
| B-017 | Project Mode evaluations | ✅ Done (E-006 to E-008) |
| B-018 | Diff Report format restoration | ✅ Done (diff-report.md) |
| B-019 | Active Purpose? prompt | ✅ Done (P01) |
| B-020 | Clean Skill Principle #3 | ✅ Done (P04) |

---

## 🟡 Next Priority

| ID | Item | Effort | Impact |
|----|------|--------|--------|
| B-021 | Automated evaluation runner | Medium | High |
| B-022 | genetic-audit.sh exit code fix | Low | Low |
| B-023 | Quality Gates in workflow.md | Medium | Medium |
| B-024 | PRE-BUILD CHECKPOINT in SKILL.md | Low | Medium |

---

## 🔵 Future Ideas

| ID | Item | Notes |
|----|------|-------|
| B-025 | Self-healing version sync | Auto-fix on validation fail |
| B-026 | Interactive skill wizard | Step-by-step creation mode |
| B-027 | Skill diff visualization | Visual before/after |
| B-028 | Cross-skill dependency check | For @requires |
| B-029 | Automated MANIFEST generation | On every build |
| B-030 | Skill templates library | Pre-built patterns |

---

## 🔴 Known Issues

| ID | Issue | Workaround |
|----|-------|------------|
| I-001 | genetic-audit.sh exit 1 on partial pass | Manual review |
| I-002 | SSOT warnings for bash scripts/ | Acceptable, protocol refs |

---

## Parking Lot

Ideas discussed but not prioritized:

- AI-assisted skill optimization
- Multi-language README generation
- Skill marketplace integration
- Version migration assistant

---

*05-BACKLOG.md v1.0.0 | skill-architect v8.3.0*
