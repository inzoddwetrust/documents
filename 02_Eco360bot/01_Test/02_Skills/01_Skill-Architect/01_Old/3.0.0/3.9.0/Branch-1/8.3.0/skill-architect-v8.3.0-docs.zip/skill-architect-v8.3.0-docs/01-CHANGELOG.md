# Changelog

All notable changes to Skill Architect.

---

## [8.3.0] - 2025-12-12 "Restoration+"

### Restored (from v3.9.0 golden standard)
- **P01-activation**: Active prompt `Skill Architect ready. Purpose?`
- **P02-config**: Active questions `Purpose? Triggers?` instead of passive extraction
- **Diff Report format**: Full format with Deviation from Plan section
- **Critical Rules table**: Consolidated 8 rules in single table (was scattered)

### Added
- **reference/diff-report.md**: Standard Diff Report format documentation
- **reference/evaluations.md**: E-006, E-007, E-008 Project Mode scenarios
- **scripts/update-version.sh**: Automated footer version sync
- **validate-skill.sh L8**: Version sync check across all files

### Changed
- SKILL.md: Consolidated Critical Rules section
- P01-activation.md: v1.4.0 → v1.5.0 (active prompt)
- P02-config.md: v1.1.0 → v1.2.0 (ask-first approach)
- P06-delivery-skill.md: v1.4.0 → v1.5.0 (diff-report.md reference)
- validate-skill.sh: v1.7 → v1.8 (L8 version sync)

### Philosophy
> "Restoration+" = v3.9.0 active prompting + v8.x Protocol-Driven architecture
> Best of both worlds: concrete instructions + modular protocols

---

## [8.2.2] - 2025-12-12 "Package Guard"

### Added
- **packaging.md**: ⛔ BEFORE PACKAGING — MANDATORY section
- **packaging.md**: Post-packaging verify commands (file + unzip -t)
- **validate-skill.sh**: ZIP format validation (prevents tar+gzip mistake)
- **P06-delivery-skill.md**: Pre-packaging checklist

### Fixed
- Prevented "Invalid zip file" errors from tar+gzip usage
- Prevented wrong folder names (without version) in archives
- Prevented temp files (DIFF-REPORT) in .skill packages

### Technical
- validate-skill.sh v1.6 → v1.7
- packaging.md v2.0.0 → v2.1.0
- P06-delivery-skill.md v1.3.0 → v1.4.0

---

## [8.2.1] - 2025-12-11

### Added
- Frontmatter key validation in validate-skill.sh
- SSOT check script

### Fixed
- Version sync validation

---

## [8.2.0] - 2025-12-10 "Lean Core"

### Added
- L7 Knowledge Redundancy checks
- Aggressive pruning protocols
- Frontmatter validation

---

*CHANGELOG.md | skill-architect v8.3.0*
