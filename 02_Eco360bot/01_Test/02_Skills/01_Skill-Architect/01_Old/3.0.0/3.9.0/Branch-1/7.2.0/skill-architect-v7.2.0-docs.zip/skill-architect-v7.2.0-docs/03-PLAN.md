# Plan: v7.1.1 → v7.2.0

## 2025-12-07 | Docs Reorder

---

## Context

Проблемы v7.1.1:
1. P07→P08 нелогично — доки до скана
2. decisions/ подпапка — избыточно
3. Файлы без порядка — непонятно что читать
4. Context Anchor — inline backticks не копируются
5. Нет validate-docs.sh

---

## Tasks

| # | Task | Priority | Status |
|---|------|----------|--------|
| B-012 | Swap P07↔P08 | High | ✅ Done |
| B-013 | Flat numbered docs | High | ✅ Done |
| B-014 | Add 06-SCAN.md | High | ✅ Done |
| B-015 | Remove decisions/ | Medium | ✅ Done |
| B-016 | Create validate-docs.sh | Medium | ✅ Done |
| B-017 | Fix Context Anchor | High | ✅ Done |

---

## Changes

### Adding
- scripts/validate-docs.sh
- P07-scan.md
- P08-docs-closure.md
- 06-SCAN.md template

### Changing
- P00-router.md (state machine)
- docs-packaging.md (8-file structure)
- templates.md (code block anchor)
- SKILL.md (Protocol Router)
- P01-activation.md (version + anchor)

### Removing
- P07-delivery-docs.md
- P08-scan.md
- decisions/ pattern

### Not touching
- P02-P06 logic
- Testing files
- Project mode files
- Other scripts

---

## Outcome

All 6 tasks completed. v7.2.0 ready.

---

*03-PLAN v1.0.0 | skill-architect v7.2.0*
