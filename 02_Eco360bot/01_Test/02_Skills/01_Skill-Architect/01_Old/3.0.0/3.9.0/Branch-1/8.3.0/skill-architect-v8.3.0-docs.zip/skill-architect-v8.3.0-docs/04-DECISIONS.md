# Architectural Decisions

## skill-architect v8.3.0 "Restoration+"

---

## ADR-001: Active Prompting Restoration

**Date:** 2025-12-12  
**Status:** Accepted

### Context
Analysis of 18 versions (v5.3.0 → v8.2.1) revealed that active prompting from v3.9.0 was lost during Protocol-Driven refactoring (v6.0.0+).

v3.9.0 had: `Skill Architect ready. Purpose?`
v8.2.2 had: Passive banner without question

### Decision
Restore active prompting in P01 and P02 while keeping Protocol-Driven architecture.

### Rationale
- Active questions get better requirements
- v3.9.0 was "golden standard" that worked well
- Protocol-Driven + Active Prompting are not mutually exclusive

### Consequences
- P01-activation.md: v1.4.0 → v1.5.0
- P02-config.md: v1.1.0 → v1.2.0
- Better requirement gathering from users

---

## ADR-002: Diff Report Format Documentation

**Date:** 2025-12-12  
**Status:** Accepted

### Context
Diff Report format existed in v3.9.0-v5.1.0 inline in SKILL.md. After Protocol-Driven refactor, only "Diff Report created" mention remained without actual format.

### Decision
Create dedicated `reference/diff-report.md` with full format template.

### Rationale
- Format was lost, not intentionally removed
- "Deviation from plan" section is valuable for quality control
- Dedicated file prevents future loss

### Consequences
- New file: reference/diff-report.md (97 lines)
- P06 references diff-report.md
- Consistent diff reports across all builds

---

## ADR-003: Critical Rules Consolidation

**Date:** 2025-12-12  
**Status:** Accepted

### Context
v3.9.0 had 7 Critical Rules in single table. v8.2.2 had rules scattered across "Platform Constraints" and "Never Degrade" sections.

### Decision
Consolidate into single 8-rule table in SKILL.md.

### Rationale
- Single source of truth for rules
- Easier to check compliance
- Matches v3.9.0 pattern that worked

### Consequences
- SKILL.md restructured
- 8 rules with enforcement column
- NEVER DEGRADE preserved as footnote

---

## ADR-004: Version Sync Automation (B-006, B-007)

**Date:** 2025-12-12  
**Status:** Accepted

### Context
Footer version desync was recurring issue (found in v8.2.1 audit: 9 files with wrong version). Manual sync is error-prone.

### Decision
- Add L8 Version Sync Check to validate-skill.sh
- Create update-version.sh automation script

### Rationale
- Backlog items B-006, B-007 open since v5.3.0
- Automation prevents human error
- Validation catches issues before release

### Consequences
- validate-skill.sh: v1.7 → v1.8
- New script: update-version.sh
- Automated footer management

---

## ADR-005: Keep Protocol-Driven Architecture

**Date:** 2025-12-12  
**Status:** Retained (from v6.0.0)

### Context
Could have reverted to v3.9.0 monolithic style or kept Protocol-Driven from v8.x.

### Decision
Keep Protocol-Driven with blocking points, add restorations on top.

### Rationale
- Protocols enforce step-by-step execution
- Blocking points prevent skipping confirmation
- Modular files easier to maintain
- v8.x architecture is sound, just missing v3.9.0 behaviors

### Consequences
- P00-P09 protocol chain preserved
- Blocking points preserved
- Active prompting added without structural changes

---

## Rejected Alternatives

### Full Revert to v3.9.0
**Reason:** Would lose Protocol-Driven benefits, L7 Redundancy, Virtual Testing

### Decomposition into Multiple Skills
**Reason:** 90% logic overlap, sync overhead not worth it (ADR-001 from v8.2.0)

---

*04-DECISIONS.md v1.0.0 | skill-architect v8.3.0*
