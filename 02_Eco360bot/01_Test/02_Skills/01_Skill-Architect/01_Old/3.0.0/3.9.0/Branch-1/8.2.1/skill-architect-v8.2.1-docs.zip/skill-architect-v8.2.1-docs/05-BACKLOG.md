# BACKLOG: skill-architect

Current and future work items.

---

## ✅ Completed in v8.2.1

| ID | Item | Status |
|----|------|--------|
| B-001 | Fix footer version sync (9 files) | ✅ Done |
| B-002 | Document protocol_first gene | ✅ Done |
| B-003 | Add Req 9 to genetic-audit.sh | ✅ Done |
| B-004 | Self-audit compliance | ✅ Done |

---

## 🔜 Planned for v8.3.0

| ID | Item | Priority | Effort |
|----|------|----------|--------|
| B-005 | Merge testing-framework.md into quality-checklist.md | Medium | 2h |
| B-006 | Add version sync check to validate-skill.sh | High | 1h |
| B-007 | Add footer update script (update-version.sh) | Medium | 1h |
| B-008 | Blocking points gene validation | Low | 2h |

---

## 📋 Future Ideas

| ID | Item | Notes |
|----|------|-------|
| B-100 | Auto-generate CHANGELOG from git commits | Requires git integration |
| B-101 | Web UI for skill validation | Out of scope for CLI |
| B-102 | Multi-language SKILL.md support | Currently English-only |
| B-103 | Skill dependency graph visualization | Mermaid integration |
| B-104 | Real-time token counter integration | Platform-dependent |

---

## 🐛 Known Issues

| ID | Issue | Workaround | Target |
|----|-------|------------|--------|
| I-001 | SSOT warnings for `bash scripts/` | Acceptable, documented | — |
| I-002 | Section header repetition in protocols | By design | — |
| I-003 | genetic-audit.sh returns exit code 1 on partial pass | Check output, not code | v8.3.0 |

---

## 📊 Metrics

### v8.2.1 Release Stats
| Metric | Value |
|--------|-------|
| Files | 41 |
| Lines (md) | ~2,755 |
| Lines (sh) | ~1,862 |
| Total | ~4,617 |
| Size (.skill) | 53 KB |

### Quality Gates
| Gate | v8.2.0 | v8.2.1 |
|------|--------|--------|
| Structure (L1) | ✅ | ✅ |
| Content (L2) | ✅ | ✅ |
| Logic (L3) | ✅ | ✅ |
| Naming (L4) | ✅ | ✅ |
| Integration (L5) | ❌ | ✅ |
| Testing (L6) | ✅ | ✅ |
| Redundancy (L7) | ✅ | ✅ |

---

## 🎯 Next Version Goals

### v8.3.0 "Self-Sufficient"
- [ ] B-006: Version sync validation
- [ ] B-007: Footer update automation
- [ ] I-003: Fix exit codes

### v9.0.0 "Ecosystem"
- [ ] Multi-skill dependency management
- [ ] Shared reference library
- [ ] Ecosystem-wide validation

---

*05-BACKLOG.md v1.0.0 | skill-architect v8.2.1*
