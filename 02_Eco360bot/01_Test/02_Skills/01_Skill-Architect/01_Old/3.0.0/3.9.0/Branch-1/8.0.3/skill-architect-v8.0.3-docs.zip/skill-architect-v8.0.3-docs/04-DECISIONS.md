# Decisions

## skill-architect v8.0.3

---

## D-001: P07+P08 Merge Strategy

**Date:** 2025-12-08

**Context:** B-003 required restructuring of final protocols. Two options existed:
1. Merge P07+P08 into single protocol, delete P08
2. Keep 9 protocols, reassign responsibilities

**Decision:** Option 2 — Keep 9 protocols
- P07-closure = Scan + Docs + Delivery (merged from P07-scan + P08-docs-closure)
- P08-simulation = New optional virtual testing

**Rationale:**
- Preserves protocol count (muscle memory)
- Adds new capability without removing
- Follows NEVER DEGRADE principle (add, don't merge destructively)

---

## D-002: P08-simulation as Optional

**Date:** 2025-12-08

**Context:** Simulation/smoke test before delivery is valuable but adds time.

**Decision:** P08 is optional, triggered by user choice after P07.

**Rationale:**
- Not all updates need full simulation
- User controls workflow depth
- Quick updates remain quick

---

## D-003: Broken Refs Fix Approach

**Date:** 2025-12-08

**Context:** P06 referenced non-existent protocols (P07-delivery-docs, P08-scan).

**Decision:** Fix refs in P06 to point to P07-closure.

**Rationale:**
- Minimal change
- Doesn't require P06 restructure
- Clean forward path

---

*04-DECISIONS v1.0.0 | skill-architect v8.0.3*
