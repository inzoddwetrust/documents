# CHANGELOG

## skill-architect

---

### v8.0.1 (2025-12-07) — Bugfix Release

**Fixed:**
- Token counter format: `~[cost]` → `~[used]` (15 locations)
- Token counter order consistency across all files (8 locations)
- Broken link: `test-levels.md` → `testing-framework.md` (3 links)
- Version sync: all footers now v8.0.1 (21 files)
- Bug in ssot-check.sh: integer parsing error on lines 55, 58
- README.md version: v7.1.0 → v8.0.1
- P01-activation.md example version: v7.2.0 → v8.0.1

**Root Cause:**
Self-audit revealed inconsistent token counter format that would propagate to all child skills through templates.md inheritance.

---

### v8.0.0 (2025-12-07) — "Testing Evolution"

**Added:**
- Genetic Audit — inheritance verification
- Consolidated Testing — unified testing-framework.md
- Self-audit flow — `self-audit` / `diagnose` commands
- genetic-audit.sh script
- testing-framework.md (merged from separate files)

**Changed:**
- P05-validate.md — added VT integration
- quality-checklist.md — added VT gate criteria

---

### v7.2.0 (2025-12-06) — Protocol-First Architecture

**Added:**
- 9 protocol files (P00-P08)
- Protocol router system
- Blocking points enforcement
- SSOT compliance checking

---

### v7.1.0 (2025-12-05) — Standardization

**Added:**
- Geo-bias rules (language ≠ country)
- Standard Activation Response template
- Token counter format (initial, later fixed in v8.0.1)

---

### v7.0.0 (2025-12-04) — Initial Release

**Added:**
- Core skill creation workflow
- Tool and Project modes
- Validation scripts
- Templates system

---

*01-CHANGELOG v1.0.0 | skill-architect v8.0.1*
