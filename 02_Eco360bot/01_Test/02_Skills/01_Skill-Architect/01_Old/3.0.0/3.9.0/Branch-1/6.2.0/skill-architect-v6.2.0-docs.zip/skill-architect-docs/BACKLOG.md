# Backlog

Future ideas, known issues, technical debt.

---

## Ideas

| # | Idea | Priority | Notes |
|---|------|----------|-------|
| 1 | Auto-detect protocol from context | Medium | Reduce manual routing |
| 2 | Protocol execution logging | Low | Debug aid |
| 3 | Template generator script | Low | Automate SKILL.md creation |

---

## Known Issues

| # | Issue | Severity | Workaround |
|---|-------|----------|------------|
| 1 | Claude may skip FIRST STEP | Medium | Explicit ⛔ added in v6.2.0 |
| 2 | validate-skill.sh warns on "." folder | Low | Ignore, cosmetic |

---

## Technical Debt

| # | Debt | Effort | Notes |
|---|------|--------|-------|
| 1 | MANIFEST.md generation incomplete | Medium | Needs descriptions |
| 2 | Some protocol footers outdated | Low | Update on next release |

---

## Completed (moved from above)

| # | Item | Version |
|---|------|---------|
| 1 | Protocol-Driven architecture | v6.1.0 |
| 2 | Self-compliance fixes | v6.2.0 |

---

*BACKLOG.md v1.0.0 | skill-architect v6.2.0*
