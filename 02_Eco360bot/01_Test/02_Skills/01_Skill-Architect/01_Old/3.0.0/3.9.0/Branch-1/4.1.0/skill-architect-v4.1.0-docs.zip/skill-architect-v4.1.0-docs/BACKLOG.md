# Backlog: skill-architect

Идеи, эксперименты, хотелки для будущих версий.

**Обновлено:** 2025-11-30  
**Версия скилла:** 4.1.0

---

## 🔴 High Priority (v4.2.0)

### B-001: Обновить clean-protocol для композиции
**Источник:** v5.0.0 planning  
**Суть:** Добавить в clean-protocol поддержку `@requires` чтобы скиллы могли его наследовать без дублирования Clean Skill Principles.  
**Блокирует:** Полноценное использование @requires в skill-architect

### B-014: Unified Naming Convention + Checker
**Источник:** Чат 2025-11-30 (Final Scan v4.1.0)  
**Суть:**
1. `reference/naming-convention.md` — единая политика именования:
   - Runtime files: `SKILL.md`, `README.md`, `MANIFEST.md` (без версий)
   - Versioned docs: `v{X.Y.Z}-PLAN.md`, `v{X.Y.Z}-DIFF.md`
   - Packages: `{skill-name}-v{X.Y.Z}.skill`, `{skill-name}-v{X.Y.Z}-docs.zip`
   - Docs folder: `{skill-name}-docs/` (единая, без версии)
2. `scripts/validate-naming.sh` — чекер именования
3. `scripts/init-docs.sh` — автогенерация правильной структуры

**Ценность:** Консистентность, меньше ошибок, автоматизация

---

## 🟡 Medium Priority (v4.2.0+)

### B-005: development-guide.md
**Источник:** v5.0.0 план, Final Scan  
**Суть:** Создать `docs/development-guide.md`:
- Как развивать skill-architect
- Evaluation-driven development
- Когда делать MAJOR/MINOR/PATCH
- Как работать с BACKLOG

### B-006: Claude A/B development pattern
**Источник:** ADDENDUM (Anthropic best practices)  
**Суть:** Документировать паттерн:
- Claude A: создаёт/улучшает скилл
- Claude B: тестирует на реальных задачах
- Iterate based on observations

### B-007: JSON schema для конфигов
**Источник:** v5.0.0 planning (Anthropic "degrees of freedom")  
**Суть:** Добавить JSON schema как "medium freedom" вариант.  
**Пример:** `skill-config.schema.json` для валидации структуры

### B-008: Git integration для Diff Report
**Источник:** v5.0.0 planning  
**Суть:** Использовать `git diff` для автоматической генерации.  
**Блокирует:** Нужен git в рабочей среде

---

## 🟢 Low Priority (future)

### B-010: VERSION-ANALYSIS.md после 5 версий
**Источник:** v5.0.0 docs structure  
**Суть:** Ретроспективный анализ:
- Какие практики выжили
- Какие были убраны
- Паттерны по моделям (Opus vs Sonnet)

**Когда:** После v4.3.0

### B-011: Skill dependency graph
**Источник:** Обсуждение 2025-11-30  
**Суть:** Визуализация зависимостей (@requires tree)  
**Формат:** Mermaid diagram

### B-012: Auto-migration tool
**Источник:** v5.0.0 lessons  
**Суть:** Скрипт миграции старых скиллов:
- Добавление @requires
- Обновление frontmatter
- Генерация docs

### B-013: Переименование в gerund form
**Источник:** ADDENDUM (Anthropic naming convention)  
**Суть:** `skill-architect` → `architecting-skills`  
**Статус:** Cosmetic, breaking change

---

## ✅ Done (реализовано)

### v4.1.0

| # | Задача | Реализовано |
|---|--------|-------------|
| B-002 | evaluations.md | reference/evaluations.md (5 сценариев) |
| B-003 | 3-Step Delivery Protocol | SKILL.md секция Delivery Protocol |
| B-004 | Final Chat Scan | Интегрировано в Delivery Protocol Step 3 |
| PATCH | PRE-BUILD CHECKPOINT | SKILL.md секция |
| P-001 | Document naming convention | Constraints Reminder в planning-document.md |

### v4.0.0

| # | Задача | Реализовано |
|---|--------|-------------|
| D-001 | LOGIC-TREE.md | docs (не runtime) |
| D-002 | decisions/v4.0.0-decisions.md | docs |

---

## ❌ Rejected (не будем делать)

### R-001: modules/state-machine.md
**Источник:** v5.0.0  
**Причина:** Over-engineering. Claude помнит контекст.  
**Альтернатива:** LOGIC-TREE.md в docs

### R-002: modules/question-protocol.md
**Источник:** v5.0.0  
**Причина:** Базовая способность Claude.

### R-003: AI-теги `<!-- @phase:X -->`
**Источник:** v5.0.0  
**Причина:** Claude их не использует реально.

### R-004: Разбиение engines.md на 5 файлов
**Источник:** v5.0.0  
**Причина:** 1 файл проще поддерживать.

---

## Процесс работы с backlog

```
1. DISCOVER  → Идея в чате/эксплуатации
2. ADD       → В соответствующую секцию с источником
3. PRIORITIZE → High/Medium/Low по value/effort
4. PLAN      → При планировании версии: review backlog
5. IMPLEMENT → Реализовать, перенести в Done
6. REJECT    → Если решили НЕ делать: в Rejected с причиной
```

---

*Backlog v1.2.0 | skill-architect v4.1.0 | Updated: 2025-11-30*
