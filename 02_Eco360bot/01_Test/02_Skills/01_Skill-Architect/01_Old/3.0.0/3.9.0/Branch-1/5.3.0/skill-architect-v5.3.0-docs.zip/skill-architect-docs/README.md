# skill-architect Documentation

Документация разработки skill-architect.

---

## Текущая версия: v5.3.0 "Version Sync"

**Дата:** 2025-12-02

### Что нового

- **docs-packaging.md** — инструкции по созданию docs для скиллов
- **Phase 6: DOCS** — опциональная фаза в workflow
- **Синхронизация версий** — все футеры обновлены

---

## Структура документации

```
skill-architect-docs/
├── v5.3.0-PLAN.md        # План v5.3.0
├── v5.3.0-DIFF.md        # Изменения v5.2.0 → v5.3.0
├── CHANGELOG.md          # История всех версий
├── BACKLOG.md            # Задачи и идеи
├── LOGIC-TREE.md         # Дерево логики
├── development-guide.md  # Руководство разработки
├── README.md             # Этот файл
└── decisions/            # Архитектурные решения
    ├── v4.0.0-decisions.md
    ├── v4.1.0-decisions.md
    ├── v5.0.0-decisions.md
    ├── v5.1.0-decisions.md
    ├── v5.2.0-decisions.md
    └── v5.3.0-decisions.md
```

---

## История версий

| Версия | Название | Ключевое |
|--------|----------|----------|
| v5.3.0 | Version Sync | Синхронизация версий, docs-packaging |
| v5.2.0 | Full Cycle | Self-diagnostic, Skill Dependencies |
| v5.1.0 | Restoration | NEVER DEGRADE, восстановление протоколов |
| v5.0.0 | Project Mode | Dual-mode: Tool + Project |
| v4.1.0 | Delivery Protocol | 3-Step Delivery |
| v4.0.0 | Unified + Docs | Token Counter, docs структура |

---

## Как использовать docs

1. **PLAN** — что планировали сделать
2. **DIFF** — что реально изменилось
3. **CHANGELOG** — краткая история
4. **BACKLOG** — что ещё хотим
5. **LOGIC-TREE** — как работает логика
6. **decisions/** — почему так решили

---

## Правило версионирования

```
Footer: *FileName vX.Y.Z | skill-architect vA.B.C*
         ↑                  ↑
         Версия файла       Версия скилла
```

- Версия файла меняется только если контент изменился
- Версия скилла всегда актуальная

---

*Documentation v1.0.0 | skill-architect v5.3.0*
