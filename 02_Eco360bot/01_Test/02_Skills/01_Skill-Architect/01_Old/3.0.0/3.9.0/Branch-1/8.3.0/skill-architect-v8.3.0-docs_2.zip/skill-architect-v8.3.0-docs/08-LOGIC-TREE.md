# Logic Tree: skill-architect v8.3.0

Business logic flow and decision points.

---

## Main Flow

```
┌─────────────────────────────────────────────────────────────┐
│                      ACTIVATION                              │
│                                                              │
│  User triggers skill-architect                               │
│         ↓                                                    │
│  P01: "Skill Architect v8.3.0. Purpose? Triggers?"          │
│         ↓                                                    │
│  ┌─────────────────┐                                        │
│  │ Purpose stated? │                                        │
│  └────────┬────────┘                                        │
│      YES  │  NO → Wait                                       │
│           ↓                                                  │
└───────────┼─────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────┐
│           ↓         CONFIG                                   │
│  P02: Extract/Ask                                           │
│         ↓                                                    │
│  ┌─────────────────┐                                        │
│  │ Mode detected?  │                                        │
│  └────────┬────────┘                                        │
│     ┌─────┴─────┐                                           │
│     ↓           ↓                                           │
│   TOOL      PROJECT                                          │
│     │           │                                           │
│     └─────┬─────┘                                           │
│           ↓                                                  │
└───────────┼─────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────┐
│           ↓         PLANNING ⛔                              │
│  P03: Create Planning Document                               │
│         ↓                                                    │
│  Chat Verification                                           │
│         ↓                                                    │
│  ┌─────────────────┐                                        │
│  │ User confirms?  │ "да/yes/go"                            │
│  └────────┬────────┘                                        │
│      YES  │  NO → Wait / Revise                              │
│           ↓                                                  │
└───────────┼─────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────┐
│           ↓         BUILD                                    │
│  P04: NEVER DEGRADE check                                    │
│         ↓                                                    │
│  ┌─────────────────┐                                        │
│  │ DEGRADE risk?   │                                        │
│  └────────┬────────┘                                        │
│      NO   │  YES → ⛔ STOP, discuss                          │
│           ↓                                                  │
│  Implement per plan                                          │
│  Apply 5 Clean Skill Principles                              │
│           ↓                                                  │
└───────────┼─────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────┐
│           ↓         VALIDATE                                 │
│  P05: Run validators                                         │
│         ↓                                                    │
│  ┌─────────────────┐                                        │
│  │ All pass?       │                                        │
│  └────────┬────────┘                                        │
│      YES  │  NO → Fix issues                                 │
│           ↓                                                  │
│  Create Diff Report (diff-report.md format)                  │
│           ↓                                                  │
└───────────┼─────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────┐
│           ↓         DELIVERY ⛔                              │
│  P06: Package .skill                                         │
│         ↓                                                    │
│  Verify ZIP format                                           │
│         ↓                                                    │
│  Present Diff Report + Link                                  │
│         ↓                                                    │
│  ┌─────────────────┐                                        │
│  │ User confirms?  │                                        │
│  └────────┬────────┘                                        │
│      YES  │  NO → Wait                                       │
│           ↓                                                  │
└───────────┼─────────────────────────────────────────────────┘
            ↓
┌───────────┼─────────────────────────────────────────────────┐
│           ↓         CLOSURE ⛔                               │
│  P07: Scan + Generate 8 docs                                 │
│         ↓                                                    │
│  Package docs.zip                                            │
│         ↓                                                    │
│  Final delivery                                              │
│         ↓                                                    │
│  ┌─────────────────┐                                        │
│  │ Simulation?     │                                        │
│  └────────┬────────┘                                        │
│     YES   │  NO                                              │
│     ↓     ↓                                                  │
│   P08   END                                                  │
│           ↓                                                  │
└───────────┴─────────────────────────────────────────────────┘
```

---

## Decision Points Summary

| Point | Options | Default |
|-------|---------|---------|
| Mode | Tool / Project | Tool |
| Plan confirm | да/yes/go / revise | Wait |
| DEGRADE check | Continue / STOP | Continue |
| Validation | Pass / Fix | Fix loop |
| Skill delivery | Confirm / Wait | Wait |
| Simulation | Yes / No | No |

---

## Blocking Points (⛔)

| Protocol | Gate | Requires |
|----------|------|----------|
| P03 | Planning confirm | Explicit "да/yes/go" |
| P06 | Skill delivery | Explicit confirmation |
| P07 | Closure | All 8 docs |

---

## Quality Gates

| Phase | Check |
|-------|-------|
| Config | Purpose + Triggers clear |
| Planning | Chat Verification passed |
| Build | NEVER DEGRADE passed |
| Validate | L1-L8 all green |
| Delivery | ZIP verified |
| Closure | Scan clean |

---

*08-LOGIC-TREE.md v1.0.0 | skill-architect v8.3.0*
