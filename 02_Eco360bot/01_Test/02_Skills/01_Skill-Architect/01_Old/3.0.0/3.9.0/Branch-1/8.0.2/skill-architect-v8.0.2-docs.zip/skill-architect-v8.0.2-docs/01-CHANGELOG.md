# Changelog

## skill-architect

---

### v8.0.2 "Purpose & Consistency" (2025-12-08)

**Added:**
- Purpose блок (serves/goal/method/success) в SKILL.md
- Обязательный Purpose блок в templates.md
- Purpose Check в P05-validate.md Layer 1
- Purpose в quality-checklist.md Critical секцию
- Правило "код >3 строк → артефакт"

**Changed:**
- Context Anchor → однострочный формат `⚙️ skill · state · status`
- P01-activation меню синхронизировано с SKILL.md
- 7 файлов обновлены с v8.0.0 → v8.0.2

**Files changed:** 14

---

### v8.0.1 (2025-12-07)

**Fixed:**
- Token counter формат `~[cost]` → `~[used]` (15 locations)
- Token counter порядок во всех файлах
- Битая ссылка `test-levels.md` → `testing-framework.md`
- Version sync — все footers на v8.0.1
- Bug в ssot-check.sh integer parsing

---

### v8.0.0 "Testing Evolution" (2025-12-07)

**Initial release:**
- Protocol-driven архитектура P00-P08
- Virtual Testing (+vt)
- Genetic Audit
- Self-diagnostic
- Project Mode

---

*01-CHANGELOG v1.0.0 | skill-architect v8.0.2*
