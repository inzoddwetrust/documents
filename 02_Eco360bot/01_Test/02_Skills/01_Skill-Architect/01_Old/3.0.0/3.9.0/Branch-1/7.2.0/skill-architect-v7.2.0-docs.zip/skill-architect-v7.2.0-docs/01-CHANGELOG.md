# Changelog

All notable changes to skill-architect.

---

## [v7.2.0] - 2025-12-07 "Docs Reorder"

### Added
- P07-scan.md — new scan protocol
- P08-docs-closure.md — new docs + closure protocol
- scripts/validate-docs.sh — docs structure validation
- 06-SCAN.md template in docs-packaging.md
- Context Anchor section in templates.md
- Dynamic Token Counter section in templates.md

### Changed
- P07↔P08 swapped: Scan before Docs
- docs-packaging.md — flat 8-file structure, no subfolders
- Context Anchor format: code block instead of inline backticks
- P00-router.md — state machine and decision table
- P01-activation.md — Standard Activation Response with code block anchor
- SKILL.md — Protocol Router table updated

### Removed
- P07-delivery-docs.md (replaced by P07-scan.md)
- P08-scan.md (replaced by P08-docs-closure.md)
- decisions/ subfolder pattern

---

## [v7.1.1] - 2025-12-07 "Self-Heal"

### Added
- Context Anchor in templates.md
- Dynamic Token Counter colors
- Context Anchor validation in quality-checklist.md

### Fixed
- P01 Standard Activation Response (was minimal)

---

## [v7.1.0] - 2025-12-07 "Standardization"

### Added
- Geo-bias prohibition rule
- Standard Activation Response template

### Changed
- Token counter format sync with clean-protocol

---

## [v7.0.1] - 2025-12-05

### Fixed
- Footer version drift in 21 files
- self-diagnostic.sh false negative

---

## [v7.0.0] - 2025-12-05 "Virtual Testing"

### Added
- virtual-testing.md
- test-levels.md (L1-L6)
- test-cases.md
- personas.md
- adversarial.md
- expert-panel.md

---

## [v6.2.0] - 2025-12-04

### Added
- Project Mode
- Import flow
- Modular architecture

---

*01-CHANGELOG v1.0.0 | skill-architect v7.2.0*
