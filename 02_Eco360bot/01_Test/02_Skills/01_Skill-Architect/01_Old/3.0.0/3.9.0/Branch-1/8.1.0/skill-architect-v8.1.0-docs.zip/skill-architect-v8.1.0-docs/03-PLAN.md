# Skill-Architect: План обновления v8.0.4 → v8.1.0

**Дата:** 2025-12-12
**Контекст:** Self-audit + Полный аудит выявил отсутствие единого протокола чекапа

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 (текущие 238) |
| README language | Russian |
| Frontmatter | name + description only |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

Пользователь запросил "чекап" скилла. Выявлен паттерн проблемы:

```
Запрос "чекап" → базовый self-diagnostic
"Нет, реально проверь" → + genetic audit  
"ВКЛЮЧИСЬ НА МАКСИМУМ" → + web search + VT
```

**Корневая причина:** Нет единого протокола full audit. Триггер "чекап" должен СРАЗУ запускать полную проверку, а не в три захода.

**Результаты текущего аудита:**
- Self-Diagnostic: 94% (34/36)
- Genetic Inheritance: 87.5% (7/8)
- Virtual Testing: 82/100
- Industry Alignment: 91%

---

## 2. Проблемы / Задачи

| # | Проблема | Источник | Приоритет |
|---|----------|----------|-----------|
| 1 | Нет единого протокола full audit | Чат | HIGH |
| 2 | Нет скрипта full-audit.sh | Чат | HIGH |
| 3 | Version desync (8.0.4 vs 8.0.3 в footers) | Self-diagnostic | MEDIUM |
| 4 | Нет документации context compaction | VT Adversarial | MEDIUM |
| 5 | Context Anchor vs Context Tracking naming | Self-diagnostic | LOW |
| 6 | P07→P08 табличный формат не парсится | Self-diagnostic | LOW |

**Отклонено пользователем:**
- ~~5-min Quickstart~~ → "на новичков пофиг"

---

## 3. План изменений

### Добавляем

| Что | Зачем | Где |
|-----|-------|-----|
| P09-full-audit.md | Единый протокол полного аудита | reference/protocols/ |
| full-audit.sh | Автоматизация полного аудита | scripts/ |
| context-management.md | Документация context compaction | reference/ |

### Изменяем

| Что | Было | Станет | Зачем |
|-----|------|--------|-------|
| SKILL.md version | v8.0.4 | v8.1.0 | Новая функциональность |
| Все footers | v8.0.3 | v8.1.0 | Version sync |
| P00-router.md | 8 protocols | 9 protocols (+ P09) | Добавление маршрута |
| SKILL.md Protocol Router | Нет P09 | + P09-full-audit | Таблица роутинга |

### Удаляем

| Что | Почему безопасно удалить |
|-----|--------------------------|
| Ничего | NEVER DEGRADE |

### Не трогаем

- P01-P08 протоколы (кроме footers)
- Все reference файлы (кроме footers)
- Все scripts кроме добавления нового
- README.md структура
- MANIFEST.md (обновится автоматически)
- templates.md, engines.md, quality-checklist.md
- Логика existing скриптов

---

## 4. Было → Стало (Preview)

### SKILL.md

| Секция | v8.0.4 | v8.1.0 |
|--------|--------|--------|
| Description | v8.0.4 | v8.1.0 |
| Protocol Router table | 8 rows | 9 rows (+P09) |
| Quick Start | Без full-audit | + `full-audit` trigger |
| Resources/Testing | 4 files | 5 files (+context-management.md) |

### Структура файлов

**До (v8.0.4):**
```
reference/protocols/
├── P00-router.md
├── P01-P08...
└── (8 files)

scripts/
├── audit-skill.sh
├── genetic-audit.sh
├── self-diagnostic.sh
└── (9 files)
```

**После (v8.1.0):**
```
reference/protocols/
├── P00-router.md (updated)
├── P01-P08...
├── P09-full-audit.md  ← NEW
└── (9 files)

reference/
├── context-management.md  ← NEW
└── ...

scripts/
├── full-audit.sh  ← NEW
└── (10 files)
```

---

## 5. P09-full-audit.md Спецификация

### Триггеры
```
чекап, self-audit, full audit, проверь себя, 
diagnose, validate +full, полный аудит
```

### Phases

| Phase | Что делает | Скрипт/Действие |
|-------|-----------|-----------------|
| 1. Structure | Проверка файлов, размеров, naming | self-diagnostic.sh |
| 2. Genetics | Проверка наследования генов | genetic-audit.sh |
| 3. Industry | Web search по трендам 2025 | Manual (web_search) |
| 4. Virtual Testing | Personas + Adversarial + Expert | Manual (VT protocol) |
| 5. Report | Consolidated report | full-audit.sh |

### Флаги

| Флаг | Что включает | Default |
|------|--------------|---------|
| (none) | Phase 1-2 only (быстрый) | — |
| `+web` | + Phase 3 (industry) | OFF |
| `+vt` | + Phase 4 (virtual testing) | OFF |
| `+full` | All phases | OFF |

### Output
```
skill-name-vX.Y.Z-FULL-AUDIT.md
├── Executive Summary
├── Structure Check (Phase 1)
├── Genetic Audit (Phase 2)
├── Industry Validation (Phase 3, if +web)
├── Virtual Testing (Phase 4, if +vt)
├── Consolidated Score
├── Hypotheses to Validate
└── Recommended Actions
```

---

## 6. full-audit.sh Спецификация

```bash
#!/bin/bash
# Full Audit Script v1.0.0
# Usage: bash scripts/full-audit.sh /path/to/skill [--web] [--vt] [--full]

SKILL_PATH="$1"
WEB_FLAG=false
VT_FLAG=false

# Parse flags
for arg in "$@"; do
  case $arg in
    --web) WEB_FLAG=true ;;
    --vt) VT_FLAG=true ;;
    --full) WEB_FLAG=true; VT_FLAG=true ;;
  esac
done

# Phase 1: Structure
echo "═══ PHASE 1: STRUCTURE ═══"
bash scripts/self-diagnostic.sh "$SKILL_PATH"

# Phase 2: Genetics
echo "═══ PHASE 2: GENETICS ═══"
bash scripts/genetic-audit.sh "$SKILL_PATH"

# Phase 3: Industry (manual prompt)
if [ "$WEB_FLAG" = true ]; then
  echo "═══ PHASE 3: INDUSTRY ═══"
  echo "⚠️ Manual: Run web_search for 2025 trends"
fi

# Phase 4: VT (manual prompt)
if [ "$VT_FLAG" = true ]; then
  echo "═══ PHASE 4: VIRTUAL TESTING ═══"
  echo "⚠️ Manual: Run VT protocol (personas, adversarial, expert panel)"
fi

# Phase 5: Consolidated
echo "═══ PHASE 5: REPORT ═══"
# ... generate consolidated report
```

---

## 7. context-management.md Спецификация

```markdown
# Context Management

Стратегия управления контекстом в long sessions.

## When to Compact
- Token counter shows 🟡 (<100k remaining)
- Session >30 messages
- Before major phase transition

## What to Preserve
- Current protocol state
- Blocking points status
- Critical decisions made
- Files created/modified
- Unresolved issues

## What to Drop
- Verbose intermediate outputs
- Duplicate information
- Resolved discussions
- Full file contents (keep paths)

## Checkpoint Strategy
1. End of each protocol → mini-summary
2. Token warning → full compaction
3. User request → explicit state dump
```

---

## 8. Риски

| Риск | Вероятность | Impact | Митигация |
|------|-------------|--------|-----------|
| SKILL.md превысит 300 строк | Low | High | Текущие 238, добавляем ~5 строк |
| Сломается existing flow | Low | High | Не трогаем P01-P08 логику |
| Version sync пропустим файл | Medium | Low | Checklist всех файлов |
| full-audit.sh слишком сложный | Low | Medium | Модульная структура, вызов existing скриптов |

---

## 9. Чат-верификация

Просканировал весь разговор. Обсуждённые пункты:

| # | Что обсуждали | В плане? |
|---|---------------|----------|
| 1 | Self-diagnostic 34/36 | ✅ Учтено |
| 2 | Genetic audit 7/8 genes | ✅ Учтено |
| 3 | protocol_first lost gene | ✅ Отмечено как intentional |
| 4 | Context Tracking naming issue | ✅ LOW priority |
| 5 | P07→P08 parsing issue | ✅ LOW priority |
| 6 | Version desync 8.0.4 vs 8.0.3 | ✅ MEDIUM, будет fix |
| 7 | VT score 82/100 | ✅ Учтено |
| 8 | Industry alignment 91% | ✅ Учтено |
| 9 | Context Overflow risk | ✅ context-management.md |
| 10 | 5-min Quickstart | ❌ Отклонено пользователем |
| 11 | Нет единого протокола чекапа | ✅ P09-full-audit.md |
| 12 | Нет скрипта full-audit | ✅ full-audit.sh |
| 13 | "Устал вручную объяснять" | ✅ Автоматизация через триггеры |

**Verified: 13 items. Missing: none.**

---

## 10. Чеклист подтверждения

- [ ] План понятен
- [ ] Scope изменений согласован (3 новых файла, version sync)
- [ ] P09 спецификация ок
- [ ] full-audit.sh спецификация ок
- [ ] context-management.md нужен
- [ ] Риски приемлемы
- [ ] Можно начинать

---

## Summary

| Метрика | Значение |
|---------|----------|
| Новых файлов | 3 |
| Изменённых файлов | ~15 (version sync) |
| Удалённых файлов | 0 |
| Риск regression | Low |
| Estimated effort | Medium |

**⛔ Ожидаю подтверждение: "да", "yes", "go", "делай"**

---

*Planning Document v1.0 | skill-architect v8.0.4 → v8.1.0*
