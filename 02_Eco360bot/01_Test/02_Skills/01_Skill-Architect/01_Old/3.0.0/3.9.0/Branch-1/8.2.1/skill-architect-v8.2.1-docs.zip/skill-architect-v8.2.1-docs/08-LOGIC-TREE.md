# LOGIC TREE: skill-architect v8.2.1

Business logic flow and decision trees.

---

## Master Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER REQUEST                             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  P00-ROUTER: Determine Current State                            │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Input Analysis:                                          │   │
│  │ • "create skill" → Tool Mode                             │   │
│  │ • "create project" → Project Mode                        │   │
│  │ • "чекап/full-audit" → P09                               │   │
│  │ • Other → Check current protocol state                   │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              ▼                               ▼
      ┌───────────┐                   ┌───────────┐
      │ TOOL MODE │                   │ PROJECT   │
      │           │                   │ MODE      │
      └─────┬─────┘                   └─────┬─────┘
            │                               │
            └───────────────┬───────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  P01-ACTIVATION                                                 │
│  • Read clean-protocol dependency                               │
│  • Display version banner                                       │
│  • Wait for purpose                                             │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  P02-CONFIG                                                     │
│  • Extract: purpose, triggers, mode                             │
│  • Auto-derive: complexity, tools, references                   │
│  • Read mode-specific templates                                 │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  P03-PLANNING ⛔ BLOCKING                                       │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Create Planning Document:                                │   │
│  │ 1. Контекст                                              │   │
│  │ 2. Проблемы/Задачи                                       │   │
│  │ 3. План изменений (Add/Change/Remove/Keep)               │   │
│  │ 4. Было → Стало                                          │   │
│  │ 5. Риски                                                 │   │
│  │ 6. Чат-верификация                                       │   │
│  │ 7. Чеклист подтверждения                                 │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ⛔ WAIT: "да/yes/go/делай" required                            │
│     "ок/понял" = NOT valid confirmation                         │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼ (only after explicit confirmation)
┌─────────────────────────────────────────────────────────────────┐
│  P04-BUILD                                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ NEVER DEGRADE Check (before ANY change):                 │   │
│  │ • Removes functionality? → STOP                          │   │
│  │ • Less specific? → STOP                                  │   │
│  │ • Deleted without moving? → VIOLATION                    │   │
│  │ • Replacing instead of adding? → CONFIRM                 │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Build Flow:                                                    │
│  NEW:    Create structure → Core files → Reference → Scripts    │
│  UPDATE: Snapshot → Implement → Check NEVER DEGRADE             │
│  REFACTOR: Unpack → Audit → Rebuild                             │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  P05-VALIDATE                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ L1: Structure (files, size, frontmatter)                 │   │
│  │ L2: Content (purpose, triggers, version)                 │   │
│  │ L3: Logic (state machine, blocking)                      │   │
│  │ L4: Naming (kebab-case, semver)                          │   │
│  │ L5: Integration (MANIFEST, footers)                      │   │
│  │ L7: Redundancy (no LLM-native bloat)                     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Gate: All ✅ → Continue | Any ❌ → Fix & Re-validate           │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  P06-DELIVERY ⛔ BLOCKING                                       │
│  • Package: zip -r name-vX.Y.Z.skill folder/                    │
│  • Verify: unzip -l                                             │
│  • Present: Diff Report + Download link                         │
│  ⛔ WAIT: User confirms receipt                                 │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  P07-CLOSURE ⛔ BLOCKING                                        │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 1. Scan: validate-skill.sh + ssot-check.sh               │   │
│  │ 2. Docs: 8 required files                                │   │
│  │    01-CHANGELOG, 02-DIFF, 03-PLAN, 04-DECISIONS          │   │
│  │    05-BACKLOG, 06-SCAN, 07-README, 08-LOGIC-TREE         │   │
│  │ 3. Package: -docs.zip                                    │   │
│  │ 4. Final delivery: skill + docs links                    │   │
│  │ 5. Offer P08 simulation                                  │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                            │
              ┌─────────────┴─────────────┐
              ▼                           ▼
      ┌───────────┐               ┌───────────┐
      │ "да/yes"  │               │ "skip/нет"│
      │ simulation│               │ готово    │
      └─────┬─────┘               └─────┬─────┘
            │                           │
            ▼                           ▼
┌─────────────────────┐         ┌─────────────┐
│  P08-SIMULATION     │         │    END      │
│  (Optional)         │         │             │
│  • Load skill       │         │ Session     │
│  • Simulate flow    │         │ Complete    │
│  • Check refs       │         │             │
│  • Generate report  │         └─────────────┘
└─────────┬───────────┘
          │
          ▼
    ┌───────────┐
    │    END    │
    └───────────┘
```

---

## P09 Full Audit Flow

```
┌─────────────────────────────────────────────────────────────────┐
│  TRIGGER: "чекап" / "full-audit" / "validate +full"             │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 1: Structure                                             │
│  bash scripts/validate-skill.sh /path                           │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 2: Genetics                                              │
│  bash scripts/genetic-audit.sh /path                            │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 2.5: Knowledge Redundancy                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ LLM-Native (remove):     Skill-Specific (keep):          │   │
│  │ • General concepts       • Custom workflows              │   │
│  │ • Standard patterns      • Blocking points               │   │
│  │ • Common formats         • Platform constraints          │   │
│  │ • Programming basics     • Ecosystem rules               │   │
│  └─────────────────────────────────────────────────────────┘   │
│  Score: 0-10% ✅ Lean | 10-30% 🟡 Review | 30%+ 🔴 Prune        │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼ (if +web or +full)
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 3: Industry                                              │
│  Web search for current best practices                          │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼ (if +vt or +full)
┌─────────────────────────────────────────────────────────────────┐
│  PHASE 4: Virtual Testing                                       │
│  5-7 personas → Adversarial → Expert panel → Score              │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│  VERDICT                                                        │
│  ≥90: PROCEED | 70-89: REVIEW | 50-69: REWORK | <50: BLOCK     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Decision Points

### Blocking Point: P03 → P04

```
User Input              Action
─────────────────────────────────────────
"да/yes/go/делай"   →   Proceed to P04
"proceed/начинай"   →   Proceed to P04
"ок/понял"          →   Ask: "Подтверждаешь план?"
Question            →   Answer, re-ask
Change request      →   Update plan, re-confirm
Silence             →   Wait or ask
```

### Mode Detection

```
Request Contains        Mode
─────────────────────────────────────────
"project"           →   Project Mode
"skill"             →   Tool Mode
"чекап/full-audit"  →   P09 (any mode)
Other               →   Tool Mode (default)
```

### Validation Gate

```
All Checks ✅       →   P06-delivery
Any Check ❌        →   Fix → Re-run P05
Critical ❌         →   Return to P04
```

---

## Context Anchor Format

```
⚙️ [skill-name] · [protocol] · [status]
🟢 ~Xk | ~Yk 🟡

Token Colors:
>100k remaining  →  🟢 ... 🟡
50-100k remaining → 🟡 ... 🔴  
<50k remaining   →  🔴 ... ⚫
```

---

*08-LOGIC-TREE.md v1.0.0 | skill-architect v8.2.1*
