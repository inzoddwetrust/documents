# Changelog

All notable changes to skill-architect.

---

## [6.2.0] - 2025-12-02

**Codename:** Self-Compliance

### Added
- `⛔ FIRST STEP` section — forces file_read of P00-router before anything
- `⛔ BEFORE EVERY RESPONSE` section — self-check checklist
- Absolute paths in Protocol Router (`/mnt/skills/user/...`)
- Naming Check in P06-delivery-skill.md

### Changed
- SKILL.md: `⚠️ MANDATORY` → `⛔ FIRST STEP — MANDATORY`
- Protocol Router: relative paths → absolute paths
- P06: added naming verification before packaging

### Fixed
- Claude ignoring protocols
- Wrong file naming (v6_0_0 instead of v6.0.0)

---

## [6.1.0] - 2025-12-01

**Codename:** Protocol-First

### Added
- Protocol-Driven architecture (P00-P08)
- Blocking points (⛔)
- `protocols/` folder
- All validation scripts

### Changed
- Monolithic workflow → split protocols
- SKILL.md restructured with Protocol Router

---

## [6.0.0] - 2025-11-XX

**Codename:** Foundation

### Added
- Initial protocol structure
- Reference files
- Script collection

---

*CHANGELOG.md v1.0.0 | skill-architect v6.2.0*
