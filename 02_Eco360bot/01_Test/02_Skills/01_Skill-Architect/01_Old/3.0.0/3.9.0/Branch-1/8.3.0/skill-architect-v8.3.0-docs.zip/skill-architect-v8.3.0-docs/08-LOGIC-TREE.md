# LOGIC-TREE: skill-architect v8.3.0

Business logic flow and decision points.

---

## Main Entry Points

```
User Message
    │
    ├─► Contains trigger word? ─────────────────────┐
    │   (create skill, refactor, update, etc.)      │
    │                                               ▼
    │                                          P01-activation
    │                                               │
    │                                               ▼
    │                                    "Skill Architect v8.3.0 ready. Purpose?"
    │
    └─► No trigger ─► Normal conversation
```

---

## Protocol Chain

```
P01-activation
    │
    ▼
P02-config ◄─────────────────────────────────────┐
    │                                             │
    │ "Purpose? Triggers?" (if not provided)      │
    │                                             │
    ▼                                             │
P03-planning                                      │
    │                                             │
    │ ⛔ BLOCKING: User must confirm plan         │
    │                                             │
    ├─► "да/yes" ─────────────────────────────────┤
    │                                             │
    ├─► "revise" ─► Loop back ────────────────────┘
    │
    ▼
P04-build
    │
    │ Execute plan, create files
    │
    ▼
P05-validation
    │
    │ Run validate-skill.sh
    │ Generate Diff Report
    │
    ├─► FAIL ─► Fix and retry
    │
    ├─► PASS
    │
    ▼
P06-delivery-skill
    │
    │ Package .skill, deliver
    │
    │ ⛔ BLOCKING: User must confirm receipt
    │
    ▼
P07-closure
    │
    │ Scan, docs generation, final delivery
    │
    ▼
P08-simulation (optional)
    │
    │ Virtual testing with evaluation cases
    │
    ▼
P09-retrospective (optional)
    │
    │ Session analysis and recommendations
    │
    ▼
END
```

---

## Mode Detection

```
P02-config
    │
    ├─► Skill Mode ──────────────────────────────┐
    │   (triggers: create skill, skill, скилл)   │
    │                                            │
    │   Output: Single .skill package            │
    │                                            │
    ├─► Project Mode ────────────────────────────┤
    │   (triggers: create project, proj-)        │
    │                                            │
    │   Output: Folder with multiple files       │
    │   Uses: project-config.md, project-tree.md │
    │                                            │
    └─► Refactor/Update Mode ────────────────────┤
        (triggers: refactor, update, чекап)      │
                                                 │
        Input: Existing skill                    │
        Output: Updated .skill + Diff Report     │
```

---

## Validation Levels

```
validate-skill.sh
    │
    ├─► L1: Structure
    │   └─► SKILL.md exists?
    │   └─► README.md exists?
    │   └─► MANIFEST.md if reference/?
    │
    ├─► L2: Content
    │   └─► Line count < 300?
    │   └─► Frontmatter valid?
    │
    ├─► L3: Logic
    │   └─► All referenced files exist?
    │
    ├─► L4: Naming
    │   └─► Conventions followed?
    │
    ├─► L5: Integration
    │   └─► Cross-references valid?
    │
    ├─► L6: Testing
    │   └─► Evaluations present?
    │
    ├─► L7: Redundancy
    │   └─► Knowledge not duplicated?
    │   └─► genetic-audit.sh check
    │
    └─► L8: Version Sync
        └─► All footers match main version?
```

---

## Critical Rules Enforcement

```
Rule Check
    │
    ├─► SKILL.md language ─► English only ─► FAIL if not
    │
    ├─► SKILL.md size ─► < 300 lines ─► FAIL if exceeded
    │
    ├─► README.md ─► Must exist ─► FAIL if missing
    │
    ├─► MANIFEST.md ─► Required if reference/ ─► FAIL if missing
    │
    ├─► Frontmatter ─► name + description ─► FAIL if missing
    │
    ├─► Planning Document ─► Before changes ─► BLOCKING
    │
    ├─► Diff Report ─► After changes ─► Required
    │
    └─► Removal ─► Ask before removing ─► BLOCKING
```

---

## Diff Report Generation

```
P05-validation
    │
    ▼
Compare: Before vs After
    │
    ├─► Metrics (lines, files, size)
    │
    ├─► Added (new files/sections)
    │
    ├─► Changed (modified files)
    │
    ├─► Removed (MUST have REASON)
    │   └─► No reason? ─► BLOCKING
    │
    ├─► Preserved (unchanged)
    │
    └─► Deviation from Plan
        └─► MUST document if any
```

---

## Virtual Testing (P08)

```
P08-simulation
    │
    ▼
Select Evaluation Case
    │
    ├─► E-001: Create skill from scratch
    ├─► E-002: Optimize existing skill
    ├─► E-003: Add new feature
    ├─► E-004: Fix structural issue
    ├─► E-005: Import from description
    ├─► E-006: Create project from scratch
    ├─► E-007: Import from pitch deck
    └─► E-008: Generate document with filters
    │
    ▼
Run Virtual Test
    │
    ├─► PASS ─► Log success
    │
    └─► FAIL ─► Document issue
              └─► Add to backlog
```

---

## State Transitions

```
┌──────────────┐
│   INACTIVE   │◄───────────────────────────┐
└──────┬───────┘                            │
       │ trigger detected                   │
       ▼                                    │
┌──────────────┐                            │
│   PLANNING   │ ◄─── revise                │
└──────┬───────┘                            │
       │ plan confirmed                     │
       ▼                                    │
┌──────────────┐                            │
│   BUILDING   │                            │
└──────┬───────┘                            │
       │ build complete                     │
       ▼                                    │
┌──────────────┐                            │
│  VALIDATING  │                            │
└──────┬───────┘                            │
       │ validation passed                  │
       ▼                                    │
┌──────────────┐                            │
│  DELIVERING  │                            │
└──────┬───────┘                            │
       │ delivery confirmed                 │
       ▼                                    │
┌──────────────┐                            │
│   CLOSING    │────── session end ─────────┘
└──────────────┘
```

---

*08-LOGIC-TREE.md v1.0.0 | skill-architect v8.3.0*
