# DIFF: skill-architect v8.3.0 → v8.4.0

**Codename:** "Golden Standard"  
**Date:** 2025-12-12

---

## Metrics

| Metric | Before | After | Δ |
|--------|--------|-------|---|
| SKILL.md lines | 146 | 166 | +20 |
| Total files | 44 | 45 | +1 |
| Reference files | 21 | 22 | +1 |

---

## Added

| File/Section | Lines | Purpose |
|--------------|-------|---------|
| **retrospective.md** (NEW) | ~140 | Evolution history |
| **SKILL.md** PRE-BUILD CHECKPOINT | 12 | Context drift protection |
| **SKILL.md** Common Mistakes | 10 | Prevent typical errors |
| **SKILL.md** Enhanced Context Anchor | 3 | Rule reminder |
| **P00-router.md** Enhanced Recovery | +30 | Recovery after drift |
| **All P0X** Self-Check sections | +10 each | Self-verification |

---

## Changed

| What | Change |
|------|--------|
| Context Anchor | Added rule reminder line |
| Blocking markers | `⛔` → `════ ⛔ BLOCKING ════` |
| All footers | v8.3.0 → v8.4.0 |

---

## Removed

| What | Reason |
|------|--------|
| Nothing | NEVER DEGRADE ✅ |

---

## Preserved

- All 12 Critical Rules
- All 5 Clean Skill Principles
- L1-L8 quality levels
- Protocol flow P00-P09
- All scripts
- diff-report.md format
- evaluations.md E-001 to E-008

---

## Validation

```
✅ SKILL.md: 166 lines (< 300)
✅ SKILL.md: English only
✅ All footers: v8.4.0
✅ Package: ZIP format
```

---

*DIFF-skill-architect-v8.4.0.md | skill-architect v8.4.0*
