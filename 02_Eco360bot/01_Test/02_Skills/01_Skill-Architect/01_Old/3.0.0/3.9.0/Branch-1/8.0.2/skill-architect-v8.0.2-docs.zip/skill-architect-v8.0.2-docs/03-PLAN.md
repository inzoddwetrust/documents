# skill-architect: План обновления v8.0.1 → v8.0.2
## 2025-12-08 | PATCH — консистентность и Purpose блок

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | User's language |
| Frontmatter | name + description ONLY |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

Обнаружены системные рассинхроны между файлами skill-architect:
- Меню активации не соответствует SKILL.md (SSOT)
- Context Anchor формат плавает между файлами
- Нет Purpose блока — ни у себя, ни в требованиях к создаваемым скиллам
- 7 файлов застряли на v8.0.0

---

## 2. Проблемы

| # | Проблема | Где | Критичность |
|---|----------|-----|-------------|
| 1 | Нет PURPOSE блока | SKILL.md, templates.md, P05 | 🔴 HIGH |
| 2 | Context Anchor — формат плавает | SKILL.md, templates.md | 🔴 HIGH |
| 3 | Код в чате вместо артефактов | SKILL.md | 🟡 MEDIUM |
| 4 | P01: `self-test` вместо `self-audit`, нет всех команд | P01-activation.md | 🔴 HIGH |
| 5 | 7 файлов на v8.0.0 | см. ниже | 🟡 MEDIUM |

### Файлы с устаревшей версией

- reference/virtual-testing.md
- reference/quality-checklist.md
- reference/packaging.md
- reference/genetic-audit.md
- reference/testing-framework.md
- reference/self-diagnostic.md
- reference/protocols/P04-build.md

---

## 3. План изменений

### Добавляем

| Что | Зачем | Где |
|-----|-------|-----|
| Purpose блок | Чёткое определение serves/goal/method/success | SKILL.md (после заголовка) |
| Purpose блок обязательный | Требование для всех скиллов | templates.md |
| Purpose Check | Валидация Purpose в скиллах | P05-validate.md |
| Правило "код >3 строк → артефакт" | Код не должен быть в чате | SKILL.md |

### Изменяем

| Что | Было | Станет | Зачем |
|-----|------|--------|-------|
| Context Anchor | Многострочный код-блок | `⚙️ skill-architect · [протокол] · [статус]` | Единый формат |
| P01 меню | `self-test` | Полный список из SKILL.md | SSOT консистентность |
| 7 файлов версия | v8.0.0 | v8.0.1 | Синхронизация |
| MANIFEST версия | v8.0.1 | v8.0.2 | Новый патч |

### Удаляем

| Что | Почему безопасно удалить |
|-----|--------------------------|
| Старый Context Tracking формат | Заменяется новым, более компактным |

### Не трогаем

- Все протоколы P00-P08 (кроме P01, P05)
- engines.md
- workflow.md
- project-*.md
- scripts/
- Логику валидации и тестирования

---

## 4. Было → Стало

### SKILL.md

| Секция | v8.0.1 | v8.0.2 |
|--------|--------|--------|
| Purpose | ❌ нет | ✅ serves/goal/method/success таблица |
| Context Tracking | Многострочный код-блок | Однострочный `⚙️ skill-architect · X · Y` |
| Before Every Response | 4 пункта | 5 пунктов (+код в артефакт) |

### P01-activation.md

| Секция | v8.0.1 | v8.0.2 |
|--------|--------|--------|
| Commands | `create skill, create project, update, refactor, self-test` | `create skill, create project, update, refactor, self-audit, genetic audit, validate +vt` |
| Context Anchor | Код-блок | Однострочный формат |

### templates.md

| Секция | v8.0.1 | v8.0.2 |
|--------|--------|--------|
| Purpose блок | ❌ нет | ✅ MANDATORY секция |
| Context Anchor | Код-блок формат | Однострочный формат |

### P05-validate.md

| Секция | v8.0.1 | v8.0.2 |
|--------|--------|--------|
| Purpose Check | ❌ нет | ✅ 4 поля валидации |

---

## 5. Риски

| Риск | Вероятность | Митигация |
|------|-------------|-----------|
| Сломаю существующую логику | Низкая | Только ADD, не REPLACE |
| Забуду обновить файл | Средняя | Чеклист из 14 файлов |
| Context Anchor не приживётся | Низкая | Простой формат, легко запомнить |

---

## 6. Файлы для изменения (14)

| # | Файл | Действие |
|---|------|----------|
| 1 | SKILL.md | +Purpose, новый Context Anchor, +правило код |
| 2 | reference/templates.md | +Purpose обязательный, новый Context Anchor |
| 3 | reference/protocols/P01-activation.md | Новое меню, новый Context Anchor |
| 4 | reference/protocols/P05-validate.md | +Purpose Check |
| 5 | reference/quality-checklist.md | +Purpose в Critical, версия |
| 6 | reference/virtual-testing.md | версия v8.0.1 |
| 7 | reference/packaging.md | версия v8.0.1 |
| 8 | reference/genetic-audit.md | версия v8.0.1 |
| 9 | reference/testing-framework.md | версия v8.0.1 |
| 10 | reference/self-diagnostic.md | версия v8.0.1 |
| 11 | reference/protocols/P04-build.md | версия v8.0.1 |
| 12 | MANIFEST.md | версия v8.0.2, changelog |
| 13 | README.md | версия v8.0.2 (если есть) |
| 14 | clean-protocol SKILL.md | новый Context Anchor (зависимость) |

---

## 7. Чеклист подтверждения

- [ ] План понятен
- [ ] Изменения согласованы
- [ ] Риски приемлемы
- [ ] Можно начинать

---

**⛔ BLOCKING: Ожидаю подтверждение для старта**

`да` / `go` / `делай` — начинаю билд
`+ изменения` — корректирую план

---

*Planning Document | skill-architect v8.0.1 → v8.0.2*
