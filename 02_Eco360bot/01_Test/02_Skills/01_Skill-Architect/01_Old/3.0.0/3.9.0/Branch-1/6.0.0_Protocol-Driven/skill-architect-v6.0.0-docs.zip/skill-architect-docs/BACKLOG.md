# Backlog

Future improvements and known issues for skill-architect.

---

## Active

| # | Task | Priority | Source |
|---|------|----------|--------|
| B-001 | Consolidate `zip -r` mentions (11→1) | Low | ssot-check |
| B-002 | Consolidate `bash scripts/` mentions (18) | Low | ssot-check |
| B-003 | Mixed language cleanup (Cyrillic in 16/17 files) | Medium | audit-skill |
| B-004 | Split large files >300 lines (engines, project-modules, workflow) | Low | audit-skill |
| B-005 | Update planning-document.md to reference P03 | Medium | v6.0.0 |
| B-006 | Update docs-packaging.md to reference P07 | Medium | v6.0.0 |

---

## Ideas

| # | Idea | Notes |
|---|------|-------|
| I-001 | Auto-generate MANIFEST.md from file scan | Reduce manual tracking |
| I-002 | `bash scripts/new-skill.sh name` template generator | Quick start for new skills |
| I-003 | Protocol validator script | Check protocol file structure |
| I-004 | Interactive self-test mode | Step-by-step with auto-fixes |
| I-005 | Protocol templates for new skills | P01-P0N template generator |

---

## Done

### v6.0.0

| # | Task | Implemented |
|---|------|-------------|
| — | Protocol-Driven Architecture | 8 protocols in reference/protocols/ |
| — | SKILL.md as router | 293→166 lines |
| — | BLOCKING enforcement | P03, P06, P07 marked |
| — | Full docs delivery protocol | P07-delivery-docs.md |

### v5.4.0

| # | Task | Implemented |
|---|------|-------------|
| — | SSOT check protocol | ssot-check.md, ssot-check.sh |
| — | Constraint deduplication | SKILL.md refactor |
| — | validate-skill.sh path bug | v1.5.0 fix |

### v5.2.0

| # | Task | Implemented |
|---|------|-------------|
| — | Post-update integrity check | self-diagnostic.md/sh |

---

*BACKLOG.md v1.0.0 | skill-architect v6.0.0*
