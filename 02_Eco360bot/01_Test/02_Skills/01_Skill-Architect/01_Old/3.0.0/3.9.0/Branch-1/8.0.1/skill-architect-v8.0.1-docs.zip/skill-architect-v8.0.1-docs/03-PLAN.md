# skill-architect: План v8.0.0 → v8.0.1

## Date | Context

**Дата:** 2025-12-07
**Тип:** Bugfix / Consistency update
**Триггер:** Self-audit выявил критические несоответствия

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | Russian |
| Frontmatter | name + description (version IN description) |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

Self-audit skill-architect по собственным протоколам выявил:
- 3 критических проблемы
- 4 серьёзных проблемы
- 3 средних проблемы

Главная проблема: **Token counter format** — неправильный формат `~[cost]` наследуется во все дочерние скиллы через templates.md.

---

## 2. Проблемы

### 🔴 CRITICAL (блокирующие)

| # | Проблема | Файлы | Детали |
|---|----------|-------|--------|
| C1 | `~[cost]` вместо `~[used]` | SKILL.md:62-63, templates.md:86-87,114-115, P01-activation.md:45 | 7 мест |
| C2 | Перевёрнутый порядок токенов | templates.md:52,159,190,221,252,283, workflow.md:117, README.md:26 | 8 мест |
| C3 | Битая ссылка `test-levels.md` | P05-validate.md:41,107, README.md:115 | Файл не существует |

### 🟠 HIGH (серьёзные)

| # | Проблема | Детали |
|---|----------|--------|
| H1 | README.md = v7.1.0 | Должен быть v8.0.1 |
| H2 | 18 футеров = v7.2.0 | Должны быть v8.0.1 |
| H3 | P01-activation пример = v7.2.0 | Строка 36 |
| H4 | `protocol_first` не документирован | Genetic audit не передаёт в дочерние |

### 🟡 MEDIUM (предупреждения)

| # | Проблема | Детали |
|---|----------|--------|
| M1 | Баг в ssot-check.sh | "integer expression expected" строки 55,58 |
| M2 | `zip -r` без SSOT Note | Не все 14 вхождений помечены |
| M3 | 6 файлов с commands без SSOT Note | Найдено ssot-check |

---

## 3. План изменений

### Добавляем

| Файл | Что |
|------|-----|
| reference/test-levels.md | **НЕТ** — удаляем ссылки, контент есть в testing-framework.md |

### Изменяем

| Файл | Строки | Было | Стало |
|------|--------|------|-------|
| **SKILL.md** | 3 | v8.0.0 | v8.0.1 |
| **SKILL.md** | 6 | v8.0.0 | v8.0.1 |
| **SKILL.md** | 62 | `~[cost]` | `~[used]` |
| **SKILL.md** | 63 | `~[cost]` | `~[used]` |
| **SKILL.md** | 183 | v8.0.0 | v8.0.1 |
| **templates.md** | 52 | `🟡 -[cost] \| ~[remaining] 🟢` | `🟢 ~[remaining] \| ~[used] 🟡` |
| **templates.md** | 86-87 | `~[cost]` | `~[used]` |
| **templates.md** | 114-115 | `~[cost]` | `~[used]` |
| **templates.md** | 159,190,221,252,283 | перевёрнутый порядок | `🟢 ~[remaining] \| ~[used] 🟡` |
| **templates.md** | 413 | v7.2.0 | v8.0.1 |
| **P01-activation.md** | 36 | v7.2.0 | v8.0.1 |
| **P01-activation.md** | 45 | `~[cost]` | `~[used]` |
| **P01-activation.md** | 75 | v7.2.0 | v8.0.1 |
| **workflow.md** | 117 | `🟡 -[cost] \| ~[remaining] 🟢` | `🟢 ~[remaining] \| ~[used] 🟡` |
| **workflow.md** | 329 | v7.2.0 | v8.0.1 |
| **README.md** | 1 | v7.1.0 | v8.0.1 |
| **README.md** | 19 | v7.1.0 | v8.0.1 |
| **README.md** | 26 | `🟡 -[cost] \| ~[remaining] 🟢` | `🟢 ~[remaining] \| ~[used] 🟡` |
| **README.md** | 115 | test-levels.md | testing-framework.md |
| **P05-validate.md** | 41,107 | test-levels.md | testing-framework.md |
| **P05-validate.md** | 204 | v7.2.0 | v8.0.1 |
| **ssot-check.sh** | 55,58 | баг с integer | фикс парсинга |
| **Все 18 футеров** | last line | v7.2.0 | v8.0.1 |

### Удаляем

Ничего не удаляем (NEVER DEGRADE).

### Не трогаем

- Размер 217KB — OK (модульная структура)
- Файлы >300 строк — OK (есть ## секции)
- Логика протоколов
- Структура директорий

---

## 4. Было → Стало

### Token Counter Format

**Было (хаос):**
```
templates.md:52   — 🟡 -[cost] | ~[remaining] 🟢
templates.md:86   — 🟢 ~[remaining] | ~[cost] 🟡
SKILL.md:62       — 🟢 ~[remaining] | ~[cost] 🟡
```

**Стало (единый формат):**
```
🟢 ~[remaining] | ~[used] 🟡   (if >100k remaining)
🟡 ~[remaining] | ~[used] 🔴   (if <100k remaining)
```

### Версии

**Было:**
- SKILL.md: v8.0.0
- README.md: v7.1.0
- 18 футеров: v7.2.0

**Стало:**
- Все: v8.0.1

---

## 5. Риски

| Риск | Вероятность | Импакт | Митигация |
|------|-------------|--------|-----------|
| Пропустим место с ~[cost] | Low | High | grep-проверка после |
| Сломаем что-то при массовой замене | Low | Medium | Точечные str_replace |
| Забудем футер | Medium | Low | Список всех файлов |

---

## 6. Чат-верификация

Обсуждённые в этом чате пункты:

| # | Пункт | Статус |
|---|-------|--------|
| 1 | Token counter формат `~[used]` не `~[cost]` | ✅ В плане |
| 2 | Порядок: remaining первый, used второй | ✅ В плане |
| 3 | Числовой формат без слов и долларов | ✅ В плане |
| 4 | Размер/большие файлы НЕ ТРОГАЕМ | ✅ Исключено |
| 5 | Битая ссылка test-levels.md | ✅ В плане |
| 6 | Version mismatch | ✅ В плане |
| 7 | Баг в ssot-check.sh | ✅ В плане |

**Verified: 7 items. Missing: none**

---

## 7. Чеклист подтверждения

- [ ] План понятен
- [ ] Изменения согласованы
- [ ] Риски приемлемы
- [ ] Можно начинать

---

**⛔ BLOCKING POINT**

Ожидаю подтверждение: "да", "yes", "go", "делай"

*03-PLAN v1.0.0 | skill-architect v8.0.1*
