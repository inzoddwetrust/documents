# Logic Tree

## skill-architect v8.0.2

---

## Main Flow

```
[USER REQUEST]
      │
      ▼
┌─────────────────────────────────────────┐
│ P00: Router                             │
│ → Determine current state               │
│ → Route to appropriate protocol         │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│ P01: Activation                         │
│ → Read clean-protocol                   │
│ → Detect mode (Tool/Project)            │
│ → Show menu                             │
│                                         │
│ Menu v8.0.2:                            │
│ create skill, create project, update,   │
│ refactor, self-audit, genetic audit,    │
│ validate +vt                            │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│ P02: Config                             │
│ → Gather requirements                   │
│ → Determine complexity                  │
│ → Set constraints                       │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│ P03: Planning ⛔ BLOCKING               │
│ → Create Planning Document              │
│ → List all changes                      │
│ → Wait for explicit confirmation        │
│                                         │
│ Valid: да/yes/go/делай                  │
│ Invalid: ок/понял (no action verb)      │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│ P04: Build                              │
│ → NEVER DEGRADE check                   │
│ → Implement changes per plan            │
│ → Log deviations                        │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│ P05: Validate                           │
│                                         │
│ Layer 1 (always):                       │
│ □ Purpose Check (4 fields)    ← NEW     │
│ □ validate-skill.sh                     │
│ □ validate-naming.sh                    │
│ □ ssot-check.sh                         │
│                                         │
│ Layer 0 (+vt): Virtual Testing          │
│ Layer 2 (+full): Deep Testing L4-L6     │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│ P06: Delivery ⛔ BLOCKING               │
│ → Package .skill                        │
│ → Generate MANIFEST                     │
│ → Deliver to user                       │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│ P07: Scan                               │
│ → Scan conversation                     │
│ → Categorize findings                   │
│ → Prepare BACKLOG items                 │
│ → Ask for docs confirmation             │
└─────────────────────────────────────────┘
      │
      ▼
┌─────────────────────────────────────────┐
│ P08: Docs + Closure ⛔ BLOCKING         │
│ → Create 8 doc files                    │
│ → Package docs.zip                      │
│ → Final delivery                        │
│                                         │
│ Files:                                  │
│ 01-CHANGELOG, 02-DIFF, 03-PLAN,         │
│ 04-DECISIONS, 05-BACKLOG, 06-SCAN,      │
│ 07-README, 08-LOGIC-TREE                │
└─────────────────────────────────────────┘
      │
      ▼
   [END]
```

---

## Context Anchor Format (v8.0.2)

```
⚙️ skill-architect · [protocol] · [status]
```

Examples:
- `⚙️ skill-architect · P03-planning · awaiting confirmation`
- `⚙️ skill-architect · P04-build · creating structure`

---

## Purpose Block Format (v8.0.2)

```markdown
## Purpose

| Field | Value |
|-------|-------|
| serves | [who] |
| goal | [measurable result] |
| method | [how] |
| success | [criteria] |
```

---

## Blocking Points

| Protocol | Requires |
|----------|----------|
| P03 → P04 | Explicit "да/yes/go/делай" |
| P06 | Skill delivered |
| P08 | All 8 docs created |

---

*08-LOGIC-TREE v1.0.0 | skill-architect v8.0.2*
