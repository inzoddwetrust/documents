# Diff: v0.0.0 → v9.0.0

**Skill:** skill-architect
**Date:** 2025-12-12

---

## Metrics

| Metric | Before | After | Δ |
|--------|--------|-------|---|
| SKILL.md lines | 0 | 80 | +80 |
| Total files | 0 | 22 | +22 |
| Total lines | 0 | 1,060 | +1,060 |

---

## Added

| Item | Description |
|------|-------------|
| SKILL.md | Main skill definition (80 lines) |
| README-skill-architect.md | User documentation |
| CHANGELOG-skill-architect.md | Version history |
| MANIFEST.md | File index |
| protocols/P00-router.md | State machine |
| protocols/P01-init.md | Activation protocol |
| protocols/P02-plan.md | Planning protocol (⛔ blocking) |
| protocols/P03-build.md | Build protocol |
| protocols/P04-deliver.md | Delivery protocol (⛔ blocking) |
| reference/quality-gates.md | G1-G7 definitions |
| reference/templates.md | SKILL.md template |
| reference/session-indicator.md | Status tracking |
| reference/diff-format.md | Change documentation format |
| reference/naming.md | Naming conventions |
| reference/evaluations.md | Test scenarios |
| scripts/validate.sh | Skill validation |
| scripts/audit.sh | Full audit |
| scripts/generate-docs.sh | Doc generation |
| scripts/package.sh | Packaging |

---

## Changed

| Item | Change |
|------|--------|
| — | N/A (initial release) |

---

## Removed

| Item | Reason |
|------|--------|
| — | NEVER DEGRADE: N/A (new skill) |

---

## NEVER DEGRADE: N/A ✅

Initial release — no prior version to compare.

---

*DIFF-skill-architect-v9.0.0.md | skill-architect v9.0.0*
