# skill-architect: План v8.2.2 → v8.3.0 "Restoration+"

**Дата:** 2025-12-12  
**Контекст:** Ретроспективный анализ 18 версий + изучение золотых архивов v3.9.0, v4.1.0, v5.1.0

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | User's language (RU) |
| Frontmatter | name + description (version in description) |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

### Источники анализа
- 18 версий docs.zip (v5.3.0 → v8.2.1)
- 3 полных .skill архива: **v3.9.0**, **v4.1.0**, **v5.1.0**
- v5.1.0-PLAN.md (документ предыдущего восстановления)

### Хронология деградации

| Версия | Что случилось |
|--------|---------------|
| **v3.9.0** | 🟢 Золотой стандарт: 223 строки, всё работает |
| **v4.0.0** | 🔴 "Unified Workflow" заменил REFACTOR/UPDATE |
| **v4.1.0** | 🟡 Добавлен 3-Step Delivery, но унификация осталась |
| **v5.1.0** | 🟢 "Restoration" — восстановлено из v3.9.0 |
| **v6.0.0** | 🟡 Protocol-Driven — хорошо, но потеряли активный опрос |
| **v8.2.0** | 🟡 Lean Core — размер уменьшен, но Diff Report формат потерян |

### Что БЫЛО в v3.9.0 (и работало):

```markdown
## Activation
Response: `Skill Architect ready. Purpose?`

## Config  
Ask: **Purpose? Triggers?**

## Diff Report — BLOCKING
### Added: [items]
### Removed: [items] — REASON
### Preserved: [items]
### Deviation from plan: [if any]
```

### Что СТАЛО в v8.2.2:

```markdown
# P01-activation.md
3. Respond with Standard Activation Response:
   Skill Architect v8.0.2
   [просто banner, без вопроса!]

# P02-config.md
1. **Extract from user input:**  
   [пассивное извлечение, не спрашивает!]

# P06-delivery-skill.md
□ Diff Report created
[упоминание без формата!]
```

---

## 2. Проблемы / Задачи

### 🔴 Критические (потеряно при эволюции)

| # | Проблема | Было (v3.9.0/v5.1.0) | Текущий статус (v8.2.2) |
|---|----------|----------------------|-------------------------|
| P-001 | **Activation prompt** | `Skill Architect ready. Purpose?` | Banner без вопроса |
| P-002 | **Config questions** | `Ask: Purpose? Triggers?` | `Extract from user` — пассивно |
| P-003 | **Diff Report format** | Полный формат + "Deviation from plan" | Только упоминание |
| P-004 | **Critical Rules table** | 7 правил одной таблицей | Разбросано по секциям |

### 🟡 Важные (не реализовано из backlog)

| # | Проблема | Источник | Возраст |
|---|----------|----------|---------|
| P-005 | Version sync check в validate-skill.sh | B-006 | с v5.3.0 |
| P-006 | Footer update automation | B-007 | с v5.3.0 |
| P-007 | Project Mode evaluations | B-017 | с v5.3.0! |

### 🟢 Мелкие

| # | Проблема |
|---|----------|
| P-008 | P01-activation содержит v8.0.2 вместо актуальной версии |
| P-009 | genetic-audit.sh exit code 1 при partial pass |

---

## 3. План изменений

### Добавляем

| Файл | Что добавляем | Зачем |
|------|---------------|-------|
| **reference/diff-report.md** (NEW) | Полный формат Diff Report | Восстановление потерянного |
| **P02-config.md** | Секция "Questions to Ask" | Восстановление активного опроса |
| **validate-skill.sh** | Version sync check (все футеры) | B-006 |
| **scripts/update-version.sh** (NEW) | Автоматизация обновления футеров | B-007 |
| **reference/evaluations.md** | E-006, E-007, E-008 для Project Mode | B-017 |
| **quality-checklist.md** | L8: Version Integrity | Новый уровень проверки |

### Изменяем

| Файл | Изменение | Было → Стало |
|------|-----------|--------------|
| **P01-activation.md** | Обновить версию в примере | v8.0.2 → v8.3.0 |
| **P01-activation.md** | Добавить "Purpose?" prompt | пассивный → активный |
| **P06-delivery-skill.md** | Ссылка на diff-report.md | implicit → explicit |
| **SKILL.md** | Critical Rules consolidation | 2 секции → 1 таблица |
| **genetic-audit.sh** | Fix exit code | 1 on partial → 0 on >80% |

### Удаляем

| Что | Причина |
|-----|---------|
| Ничего | NEVER DEGRADE |

### Не трогаем

| Что | Причина |
|-----|---------|
| Protocol flow P00-P09 | Работает |
| Scripts (кроме указанных) | Стабильны |
| L7 Redundancy Check | Недавно добавлено, работает |
| Lean Principle | Ядро |

---

## 4. Было → Стало

### P01-activation.md

**Было (v8.2.2):**
```markdown
3. Respond with Standard Activation Response:
   ```
   Skill Architect v8.0.2
   
   Protocol-driven skill and project creation with integrated testing.
   
   Commands: create skill, create project...
   ```
4. Wait for user input
```

**Стало (v8.3.0) — восстановлено из v3.9.0:**
```markdown
3. Respond with Activation + Question:
   ```
   Skill Architect v8.3.0 ready. Purpose?
   
   ⚙️ skill-architect · P01 · awaiting purpose
   🟢 ~Xk | ~Yk 🟡
   ```

**Key:** Active question, not passive waiting.
```

### P02-config.md

**Было (v8.2.2):**
```markdown
## Steps

1. **Extract from user input:**
   - Purpose (what skill does)
   - Triggers (activation keywords)
   - Mode (Tool/Project — auto-detect)
```

**Стало (v8.3.0) — восстановлено из v3.9.0:**
```markdown
## Steps

1. **Ask if not provided:** `Purpose? Triggers?`

2. **Auto-derive from answer:**
   - Type (create/update/refactor)
   - Complexity (simple/medium/complex)
   - Mode (Tool/Project)
   - Required tools

**Rule:** Ask before assuming. Clarify before planning.
```

### reference/diff-report.md (NEW)

**Было (v8.2.2):** Формата нет, только упоминание "Diff Report created" в P06

**Стало (v8.3.0) — восстановлено из v3.9.0:**
```markdown
# Diff Report Format

Required after implementation, before delivery.

## Template

```markdown
## Diff: v[OLD] → v[NEW]

| Metric | Before | After | Δ |
|--------|--------|-------|---|
| SKILL.md lines | | | |
| Total files | | | |
| Reference files | | | |

### Added
| Item | Lines | Purpose |
|------|-------|---------|

### Removed
| Item | Reason |
|------|--------|

### Preserved
- [list unchanged items]

### ⚠️ Deviation from Plan
- [none / list deviations with explanation]
```

## Rules

1. **BLOCKING** — wait for user confirmation
2. **Removed requires REASON** — never silent deletion
3. **Deviation section mandatory** — even if "none"
```

### SKILL.md Critical Rules

**Было (v8.2.2):** Две отдельные секции
```markdown
### Platform Constraints
| Constraint | Rule |
...

### Never Degrade
Before ANY change...
```

**Стало (v8.3.0) — консолидировано как в v3.9.0:**
```markdown
## ⛔ Critical Rules

| # | Rule | Enforcement |
|---|------|-------------|
| 1 | SKILL.md = English only | validate-skill.sh |
| 2 | SKILL.md < 300 lines | validate-skill.sh |
| 3 | README.md required | validate-skill.sh |
| 4 | MANIFEST.md if reference/ exists | validate-skill.sh |
| 5 | Planning Document before changes | P03 ⛔ |
| 6 | Diff Report after changes | P06 ⛔ |
| 7 | NEVER remove without reason | P04 checklist |
| 8 | Footer versions synced | validate-skill.sh L8 |

**NEVER DEGRADE:** Removes functionality? → STOP. Less specific? → STOP.
```

---

## 5. Риски

| Риск | Вероятность | Impact | Mitigation |
|------|-------------|--------|------------|
| SKILL.md > 300 lines после changes | Low | High | Consolidation уменьшит, не увеличит |
| Breaking existing workflows | Low | High | ADD alongside, test P01-P09 flow |
| New script bugs | Medium | Medium | Test on self before release |
| Evaluations incomplete | Medium | Low | Start with 3, expand later |

---

## 6. Чат-верификация

**Обсуждено в этой сессии:**

| # | Тема | Источник | Статус в плане |
|---|------|----------|----------------|
| 1 | Ретроспектива 18 версий docs | Анализ | ✅ Основа для плана |
| 2 | Потеря при v4→v5 унификации | v5.1.0-PLAN.md | ✅ Контекст |
| 3 | v3.9.0 "золотой стандарт" | skill архив | ✅ Источник восстановления |
| 4 | v4.1.0 начало проблемы | skill архив | ✅ Понимание причин |
| 5 | v5.1.0 "Restoration" | skill архив | ✅ Референс |
| 6 | Activation prompt потерян | Сравнение v3.9.0 vs v8.2.2 | ✅ P-001 |
| 7 | Config questions потеряны | Сравнение v3.9.0 vs v8.2.2 | ✅ P-002 |
| 8 | Diff Report format потерян | Сравнение v3.9.0 vs v8.2.2 | ✅ P-003 |
| 9 | Critical Rules разбросаны | Сравнение v3.9.0 vs v8.2.2 | ✅ P-004 |
| 10 | Version sync (B-006) | Backlog с v5.3.0 | ✅ P-005 |
| 11 | Footer automation (B-007) | Backlog с v5.3.0 | ✅ P-006 |
| 12 | Project evaluations (B-017) | Backlog с v5.3.0 | ✅ P-007 |

**Verified:** 12 items from golden archives + backlog. **Missing:** none.

---

## 7. Чеклист подтверждения

- [ ] План понятен
- [ ] Восстановления из v3.9.0 корректны
- [ ] Protocol-Driven архитектура сохраняется
- [ ] L7 Redundancy сохраняется
- [ ] Риски приемлемы
- [ ] Можно начинать

---

## Deliverables

| # | Deliverable | Format |
|---|-------------|--------|
| 1 | skill-architect-v8.3.0.skill | .skill archive |
| 2 | skill-architect-v8.3.0-docs.zip | docs archive |
| 3 | Diff Report v8.2.2 → v8.3.0 | в docs |

---

## Effort Estimate

| Task | Time |
|------|------|
| reference/diff-report.md (NEW) | 20 min |
| P01-activation.md update | 15 min |
| P02-config.md update | 15 min |
| SKILL.md Critical Rules consolidation | 20 min |
| validate-skill.sh L8 version sync | 30 min |
| scripts/update-version.sh (NEW) | 30 min |
| reference/evaluations.md Project Mode | 45 min |
| Testing & self-validation | 45 min |
| Packaging & docs | 30 min |
| **Total** | **~4 hours** |

---

## Key Principle

> **"Restoration+" = v3.9.0 конкретика + v8.x Protocol-Driven architecture**
>
> Берём лучшее из обоих миров:
> - Активный опрос и конкретные форматы из v3.9.0
> - Модульность и blocking points из v8.x
> - L7 Redundancy Check из v8.2.0

---

**⚙️ skill-architect · P03-planning · awaiting confirmation**

Ожидаю подтверждение: **"да"**, **"yes"**, **"go"**, **"делай"**

---

*skill-architect v8.2.2 → v8.3.0 "Restoration+" Planning Document*
*Based on: v3.9.0 golden archive + v5.1.0 restoration + v8.x protocol architecture*
