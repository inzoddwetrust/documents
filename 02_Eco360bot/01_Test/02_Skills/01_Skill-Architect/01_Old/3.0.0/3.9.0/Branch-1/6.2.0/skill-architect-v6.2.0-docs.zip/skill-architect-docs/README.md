# Skill Architect v5.3.0 "Version Sync"

> Создаёт скиллы Claude (Tool Mode) и базы знаний проектов (Project Mode).

---

## Быстрый старт

**Tool Mode:** `create skill: [purpose]`

**Project Mode:** `create project: [name]`

**Maintenance:** `self-test` / `diagnose`

---

## Ключевые правила

### ⛔ NEVER DEGRADE

1. Это УДАЛЯЕТ работающую функциональность? → STOP
2. Это ЗАМЕНЯЕТ конкретное на абстрактное? → STOP
3. Нет места? → Вынести в reference/, не удалять

### Critical Rules

| Правило | Требование |
|---------|------------|
| SKILL.md | English, < 300 строк |
| README.md | Обязателен |
| MANIFEST.md | Обязателен если reference/ или data/ |
| Planning Document | Обязателен перед изменениями |
| Diff Report | Обязателен после изменений |

---

## Валидация

```bash
bash scripts/validate-skill.sh /path/to/skill
bash scripts/validate-naming.sh /path/to/skill
bash scripts/audit-skill.sh /path/to/skill      # Tool Mode
bash scripts/audit-project.sh /path/to/project  # Project Mode
bash scripts/self-diagnostic.sh /path/to/skill  # Self-test
```

---

## История версий

### v5.3.0 "Version Sync"

**Синхронизация:** Все футеры обновлены до v5.3.0

**Добавлено:** docs-packaging.md, Phase 6: Documentation в workflow.md

**Исправлено:** Футеры в packaging.md и planning-document.md

### v5.2.0 "Full Cycle"

**Добавлено:** Skill Dependencies, Self-diagnostic protocol, self-diagnostic.sh

### v5.1.0 "Restoration"

**Восстановлено:** Activation, Config, REFACTOR/UPDATE протоколы

**Добавлено:** NEVER DEGRADE, Reference Reading trigger

---

*Skill Architect v5.3.0 "Version Sync"*

*README.md v1.0.0 | skill-architect v6.2.0*
