# Logic Tree

## skill-architect v8.0.1

---

## Core Flow

```
[USER REQUEST]
      │
      ▼
┌─────────────────┐
│ P00: Router     │ ← Determines next protocol
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P01: Activation │ ← Read dependencies, detect mode
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P02: Config     │ ← Gather requirements
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P03: Planning   │ ⛔ BLOCKING — wait for "да/yes/go"
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P04: Build      │ ← Create/update files
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P05: Validate   │ ← Run scripts, generate diff
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P06: Delivery   │ ⛔ BLOCKING — deliver .skill
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P07: Scan       │ ← Scan chat for items
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ P08: Docs       │ ⛔ BLOCKING — create 8 doc files
└────────┬────────┘
         │
         ▼
      [END]
```

---

## Decision Points

### Mode Detection (P01)

```
Request contains "project"?
  YES → Project Mode
  NO  → Tool Mode (default)
```

### Validation Layers (P05)

```
Flags present?
  +vt    → Layer 0: Virtual Testing
  (none) → Layer 1: Static Validation (always)
  +full  → Layer 2: Deep Testing
  (any)  → Layer 3: Reporting (always)
```

### Confirmation Handling

```
User says:
  "да/yes/go/делай" → Proceed to next protocol
  "ок/понял"        → NOT confirmation, ask again
  Question          → Answer, then re-ask
  Change request    → Update plan, re-confirm
```

---

## Key Principles

### NEVER DEGRADE

```
Before ANY change:
  □ Removes functionality? → STOP
  □ Less specific?         → STOP
  □ No space?              → Move to reference/, don't delete
  □ New replaces old?      → ADD alongside, don't merge
```

### Context Tracking

```
Every response ends with:
  ```
  skill-name: file_read → entry-point.md
  ```
  🟢 ~[remaining] | ~[used] 🟡
```

### SSOT (Single Source of Truth)

```
Commands      → reference/commands.md
Blocking rules → P00-router.md
Build steps   → P04-build.md
Validation    → P05-validate.md
Packaging     → P06-delivery-skill.md
```

---

## Inheritance Model

```
skill-architect (parent)
      │
      │ templates.md
      │ ────────────►  Child skills inherit:
      │                 - Token counter format
      │                 - Context anchor format
      │                 - Activation response template
      │                 - Quality checklist
      │
      ▼
[child-skill-1]
[child-skill-2]
[child-skill-N]
```

**Critical:** Changes to templates.md propagate to ALL child skills.

---

## Error Handling

| Error | Handler |
|-------|---------|
| Missing file | Recovery in P00-router |
| Validation fail | Block at P05, fix first |
| User unclear | Ask clarifying question |
| Context lost | Use context anchor to recover |

---

*08-LOGIC-TREE v1.0.0 | skill-architect v8.0.1*
