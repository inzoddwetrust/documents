# Backlog: skill-architect

Идеи, эксперименты, хотелки для будущих версий.

**Обновлено:** 2025-12-01  
**Версия скилла:** 5.0.0

---

## 🔴 High Priority (v5.1.0)

### B-001: Обновить clean-protocol для композиции
**Источник:** v5.0.0 planning  
**Суть:** Добавить в clean-protocol поддержку `@requires` чтобы скиллы могли его наследовать без дублирования Clean Skill Principles.  
**Блокирует:** Полноценное использование @requires в skill-architect

### B-015: Project Mode custom modules
**Источник:** v5.0.0 Project Mode  
**Суть:** Поддержка кастомных модулей помимо стандартных 10:
- brand/, system/, business/ как в NATURA COUTURE
- Автодетект структуры при импорте
- Гибкие схемы для нестандартных проектов

### B-017: Project Mode evaluations
**Источник:** v5.0.0 merge  
**Суть:** Добавить в evaluations.md сценарии для Project Mode:
- E-006: Create project from scratch
- E-007: Import from pitch deck
- E-008: Generate document with filters

---

## 🟡 Medium Priority (v5.1.0+)

### B-006: Claude A/B development pattern
**Источник:** ADDENDUM (Anthropic best practices)  
**Суть:** Документировать паттерн:
- Claude A: создаёт/улучшает скилл
- Claude B: тестирует на реальных задачах
- Iterate based on observations
**Статус:** Частично в development-guide.md

### B-007: JSON schema для конфигов
**Источник:** v5.0.0 planning (Anthropic "degrees of freedom")  
**Суть:** Добавить JSON schema как "medium freedom" вариант.  
**Пример:** `skill-config.schema.json` для валидации структуры

### B-008: Git integration для Diff Report
**Источник:** v5.0.0 planning  
**Суть:** Использовать `git diff` для автоматической генерации.  
**Блокирует:** Нужен git в рабочей среде

### B-016: Project Mode auto-detect stage
**Источник:** v5.0.0 Project Mode  
**Суть:** Автоматическое определение стадии проекта по контенту:
- Наличие метрик → MVP+
- Revenue данные → Growth+
- Детальные финансы → Scale

---

## 🟢 Low Priority (future)

### B-010: VERSION-ANALYSIS.md после 5 версий
**Источник:** v5.0.0 docs structure  
**Суть:** Ретроспективный анализ:
- Какие практики выжили
- Какие были убраны
- Паттерны по моделям (Opus vs Sonnet)

**Когда:** После v5.2.0

### B-011: Skill dependency graph
**Источник:** Обсуждение 2025-11-30  
**Суть:** Визуализация зависимостей (@requires tree)  
**Формат:** Mermaid diagram

### B-012: Auto-migration tool
**Источник:** v5.0.0 lessons  
**Суть:** Скрипт миграции старых скиллов:
- Добавление @requires
- Обновление frontmatter
- Генерация docs

### B-013: Переименование в gerund form
**Источник:** ADDENDUM (Anthropic naming convention)  
**Суть:** `skill-architect` → `architecting-skills`  
**Статус:** Cosmetic, breaking change — отложено

---

## ✅ Done (реализовано)

### v5.0.0

| # | Задача | Реализовано |
|---|--------|-------------|
| B-014 | Unified Naming Convention | reference/naming-convention.md + validate-naming.sh |
| B-005 | development-guide.md | docs/development-guide.md |
| — | Project Mode | reference/project-*.md (4 файла) |
| — | Project Architect merge | Полностью интегрирован |

### v4.1.0

| # | Задача | Реализовано |
|---|--------|-------------|
| B-002 | evaluations.md | reference/evaluations.md (5 сценариев) |
| B-003 | 3-Step Delivery Protocol | SKILL.md секция Delivery Protocol |
| B-004 | Final Chat Scan | Интегрировано в Delivery Protocol Step 3 |
| PATCH | PRE-BUILD CHECKPOINT | SKILL.md секция |
| P-001 | Document naming convention | Constraints Reminder в planning-document.md |

### v4.0.0

| # | Задача | Реализовано |
|---|--------|-------------|
| D-001 | LOGIC-TREE.md | docs (не runtime) |
| D-002 | decisions/v4.0.0-decisions.md | docs |

---

## ❌ Rejected (не будем делать)

### R-001: modules/state-machine.md
**Источник:** v5.0.0  
**Причина:** Over-engineering. Claude помнит контекст.  
**Альтернатива:** LOGIC-TREE.md в docs

### R-002: modules/question-protocol.md
**Источник:** v5.0.0  
**Причина:** Базовая способность Claude.

### R-003: AI-теги `<!-- @phase:X -->`
**Источник:** v5.0.0  
**Причина:** Claude их не использует реально.

### R-004: Разбиение engines.md на 5 файлов
**Источник:** v5.0.0  
**Причина:** 1 файл проще поддерживать.

### R-005: Отдельный Project Architect скилл
**Источник:** v5.0.0  
**Причина:** 90% overlap с Skill Architect → merged as Project Mode

---

## Процесс работы с backlog

```
1. DISCOVER  → Идея в чате/эксплуатации
2. ADD       → В соответствующую секцию с источником
3. PRIORITIZE → High/Medium/Low по value/effort
4. PLAN      → При планировании версии: review backlog
5. IMPLEMENT → Реализовать, перенести в Done
6. REJECT    → Если решили НЕ делать: в Rejected с причиной
```

---

*Backlog v1.3.0 | skill-architect v5.0.0 | Updated: 2025-12-01*
