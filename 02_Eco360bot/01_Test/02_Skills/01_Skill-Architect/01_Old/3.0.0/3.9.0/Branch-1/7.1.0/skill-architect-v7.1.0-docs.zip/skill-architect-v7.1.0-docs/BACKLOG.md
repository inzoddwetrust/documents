# Backlog

Future improvements and known issues for skill-architect.

---

## Active

| # | Task | Priority | Source |
|---|------|----------|--------|
| B-001 | Auto-detect protocol from context | Medium | v6.2.0 BACKLOG |
| B-002 | Protocol execution logging | Low | v6.2.0 BACKLOG |
| B-003 | Template generator script | Low | v6.2.0 BACKLOG |
| B-004 | MANIFEST.md generation — add descriptions | Medium | v6.2.0 BACKLOG |
| B-010 | Dynamic token counter colors: 🟢 >100k, 🟡 <100k with 🔴 | High | v7.1.0 chat |
| B-011 | Add "действуй согласно протоколов" reminder to skill messages | Medium | v7.1.0 chat |
| B-010 | Dynamic token counter colors based on remaining context | Medium | v7.1.0 chat |

### B-010 Details

Token counter format changes based on remaining context window:

| Remaining | Format |
|-----------|--------|
| 190k-100k | `🟢 165k \| ~ 3k 🟡` |
| <100k | `🟢 65k \| ~ 3k 🔴` |

Affects: clean-protocol, templates.md

---

## Known Issues

| # | Issue | Severity | Workaround |
|---|-------|----------|------------|
| I-001 | validate-skill.sh warns on "." folder | Low | Ignore, cosmetic |

---

## Done

### v7.1.0

| # | Task | Implemented |
|---|------|-------------|
| B-007 | Geo-bias rule in templates + quality-checklist | templates.md, quality-checklist.md |
| B-008 | Token counter sync with clean-protocol | 5 templates updated |
| B-009 | Standard Activation Response template | templates.md |

### v7.0.1

| # | Task | Implemented |
|---|------|-------------|
| B-005 | Footer version drift | All 21 files updated |
| B-006 | self-diagnostic.sh false negative | Pattern fixed |

### v7.0.0

| # | Task | Implemented |
|---|------|-------------|
| — | skill-tester integration | Absorbed into P05-validate |
| — | Virtual Testing engine | reference/virtual-testing.md |

### v6.2.0

| # | Task | Implemented |
|---|------|-------------|
| — | Claude skips FIRST STEP | Explicit ⛔ added |

---

*BACKLOG v1.2.0 | skill-architect v7.1.0*
