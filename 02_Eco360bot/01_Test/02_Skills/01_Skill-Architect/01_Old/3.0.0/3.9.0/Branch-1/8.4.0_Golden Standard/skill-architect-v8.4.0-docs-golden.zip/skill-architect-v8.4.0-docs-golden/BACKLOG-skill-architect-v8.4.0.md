# BACKLOG: skill-architect v8.4.0

Current backlog after "Golden Standard" release.

---

## ✅ Closed in v8.4.0

| ID | Item | Status |
|----|------|--------|
| B-020 | PRE-BUILD CHECKPOINT | ✅ Done |
| B-021 | Enhanced Context Anchor | ✅ Done |
| B-022 | Common Mistakes section | ✅ Done |
| B-023 | Self-Check in protocols | ✅ Done |
| B-024 | Visual blocking markers | ✅ Done |
| B-025 | retrospective.md | ✅ Done |
| B-026 | Enhanced Recovery in P00 | ✅ Done |
| B-027 | Inline examples in evaluations | ✅ Done (E-001) |

---

## 📋 Open Backlog

### 🔴 High Priority

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-028 | Inline examples E-002 to E-008 | v8.4.0 | Only E-001 done |
| B-029 | Auto-detect context drift | v8.4.0 | Detection mechanism |
| B-035 | Documentation system (docs/) | v8.4.0 | Versioned docs archive |

### 🟡 Medium Priority

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-017 | Project Mode evaluations | v5.3.0 | E-006, E-007, E-008 basic |
| B-030 | Multi-skill dependency graph | v8.2.1 | Child skills tracking |
| B-031 | Real-time token counter | v8.2.1 | Platform integration |

### 🟢 Low Priority

| ID | Item | Since | Notes |
|----|------|-------|-------|
| B-032 | Shared reference library | v8.2.1 | Common patterns |
| B-033 | Versioning strategy doc | v8.4.0 | MAJOR/MINOR/PATCH rules |
| B-034 | Automated regression testing | v8.4.0 | CI/CD for skills |

---

## 🐛 Known Issues

| ID | Issue | Workaround |
|----|-------|------------|
| I-004 | genetic-audit.sh exit 1 on partial | Manual check |
| I-005 | validate-skill.sh no YAML syntax check | Manual check |

---

## Stats

| Category | Count |
|----------|-------|
| High Priority | 3 |
| Medium Priority | 3 |
| Low Priority | 3 |
| Known Issues | 2 |
| **Total Open** | **11** |

---

*BACKLOG-skill-architect-v8.4.0.md | skill-architect v8.4.0*
