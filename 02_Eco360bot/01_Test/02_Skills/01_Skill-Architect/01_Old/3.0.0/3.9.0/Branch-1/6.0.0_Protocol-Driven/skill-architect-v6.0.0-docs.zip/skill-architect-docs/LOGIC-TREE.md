# Logic Tree

Decision flow for skill-architect v6.0.0.

---

## Main Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    PROTOCOL FLOW                             │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  P01 ──→ P02 ──→ P03 ──→ P04 ──→ P05 ──→ P06 ──→ P07 ──→ P08 │
│   │       │       │       │       │       │       │       │  │
│  Act   Config   Plan   Build   Valid  Skill   Docs   Scan   │
│                  ⛔                    ⛔      ⛔            │
│               BLOCKING              BLOCKING               │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## Protocol Dispatch

```
User Input
    │
    ▼
┌─────────────────────┐
│ P01: Activation     │
│ • Read clean-protocol│
│ • Detect mode       │
│ • "Ready. Purpose?" │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ P02: Config         │
│ • Extract purpose   │
│ • Define triggers   │
│ • Read mode refs    │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ P03: Planning ⛔    │
│ • Create plan doc   │
│ • Chat verification │
│ • WAIT confirmation │◀──┐
└─────────┬───────────┘   │
          │               │
    ┌─────┴─────┐         │
    │           │         │
  "да/go"    other ───────┘
    │
    ▼
┌─────────────────────┐
│ P04: Build          │
│ • NEVER DEGRADE     │
│ • Implement plan    │
│ • Create files      │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ P05: Validate       │
│ • Run validators    │
│ • Create Diff Report│
│ • Update MANIFEST   │
└─────────┬───────────┘
          │
          ▼
┌─────────────────────┐
│ P06: Delivery ⛔    │
│ • Package .skill    │
│ • Provide link      │
│ • WAIT confirmation │◀──┐
└─────────┬───────────┘   │
          │               │
    ┌─────┴─────┐         │
    │           │         │
  "да/docs"  "готово" ────┼──→ P08
    │                     │
    ▼                     │
┌─────────────────────┐   │
│ P07: Docs ⛔        │   │
│ • Create 7 files    │   │
│ • Package .zip      │   │
│ • Provide link      │   │
└─────────┬───────────┘   │
          │               │
          ▼               │
┌─────────────────────┐   │
│ P08: Scan           │◀──┘
│ • Scan chat         │
│ • Update BACKLOG    │
│ • Final summary     │
└─────────────────────┘
```

---

## Decision Points

### D1: Mode Detection (P01)

```
Request contains "project"?
├── YES → Project Mode
│         • Read project-mode.md
│         • Read project-modules.md
└── NO  → Tool Mode (default)
          • Read templates.md
          • Read engines.md
```

### D2: Action Type (P02)

```
Trigger word?
├── "create skill"   → New skill flow
├── "create project" → New project flow
├── "update"         → UPDATE flow (P04)
├── "refactor"       → REFACTOR flow (P04)
├── "self-test"      → Self-diagnostic
└── other            → Ask clarification
```

### D3: Confirmation (P03, P06, P07)

```
User response?
├── "да/yes/go/делай/proceed" → Continue to next protocol
├── "ок/понял/хорошо"         → INVALID, ask again
├── Question                   → Answer, re-ask
└── Change request             → Update, re-confirm
```

### D4: NEVER DEGRADE (P04)

```
Proposed change:
├── Removes functionality?         → STOP, ask override
├── Replaces specific→abstract?    → STOP, ask override
├── No space for new content?      → Move to reference/
└── Adds new feature?              → Add alongside existing
```

### D5: Docs Decision (P06)

```
After skill delivery:
├── "да/docs/доки" → P07 (full docs package)
└── "готово/всё"   → P08 (skip docs)
```

---

## Validation Chain (P05)

```
validate-skill.sh
       │
       ▼
  ┌─────────┐
  │ PASS?   │
  └────┬────┘
       │
  ┌────┴────┐
 YES       NO → Fix issues, retry
  │
  ▼
validate-naming.sh
       │
       ▼
  ┌─────────┐
  │ PASS?   │
  └────┬────┘
       │
  ┌────┴────┐
 YES       NO → Fix issues, retry
  │
  ▼
ssot-check.sh
       │
       ▼
  ┌─────────┐
  │ PASS?   │
  └────┬────┘
       │
  ┌────┴────┐
 YES     WARN → Acknowledge, continue
  │
  ▼
Create Diff Report
```

---

*LOGIC-TREE.md v1.0.0 | skill-architect v6.0.0*
