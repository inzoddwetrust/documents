# Backlog

## skill-architect v8.1.0

---

## Resolved in v8.1.0

| # | Item | Resolution |
|---|------|------------|
| 1 | Нет единого протокола чекапа | ✅ P09-full-audit |
| 2 | Нет скрипта full-audit | ✅ full-audit.sh |
| 3 | Context overflow risk | ✅ context-management.md |
| 4 | Version desync footers | ✅ All synced to v8.1.0 |

---

## Known Issues (Not Blocking)

| # | Issue | Impact | Notes |
|---|-------|--------|-------|
| 1 | "Context Tracking" vs "Context Anchor" naming | LOW | Script looks for wrong name |
| 2 | P07→P08 tabular Next not parsed | LOW | Affects diagnostic only |
| 3 | "15 numbered steps" warning | FALSE POSITIVE | Iteration Principles = meta-rules |

---

## Future Improvements

### Priority: LOW

| # | Item | Rationale |
|---|------|-----------|
| 1 | Expert Mode (--fast flag) | Skip confirmations for power users |
| 2 | Security considerations doc | Enterprise deployment guidance |
| 3 | Integration guide | How to use with other tools |
| 4 | MCP pattern mention | Industry alignment |
| 5 | Update self-diagnostic.sh | Recognize "Context Anchor" |

### Priority: MAYBE

| # | Item | Rationale |
|---|------|-----------|
| 1 | Auto version sync script | Prevent footer drift |
| 2 | P07→P08 Next format unification | Cleaner parsing |
| 3 | CI/CD hooks for eval | Continuous validation |

---

## Declined

| # | Item | Reason |
|---|------|--------|
| 1 | 5-min Quickstart | User: "на новичков пофиг" |
| 2 | Fully automated web search | Claude tool, not bash |
| 3 | Protocol_first as child requirement | Intentional: complex skills only |

---

## Metrics

| Version | Files | Lines | Protocols |
|---------|-------|-------|-----------|
| v8.0.0 | 39 | ~7800 | 9 (P00-P08) |
| v8.1.0 | 42 | ~8200 | 10 (P00-P09) |

---

*05-BACKLOG v1.0.0 | skill-architect v8.1.0*
