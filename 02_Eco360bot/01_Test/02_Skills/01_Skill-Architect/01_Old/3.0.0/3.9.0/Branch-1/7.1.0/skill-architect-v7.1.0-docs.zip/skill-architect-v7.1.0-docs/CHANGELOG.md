# Changelog

## v7.1.0 (2025-12-07)

**Type:** MINOR — "Standardization"

### Added
- Localization Rules section in templates.md (geo-bias prohibition)
- Standard Activation Response template in templates.md
- Geo-Bias anti-pattern in quality-checklist.md

### Changed
- Token counter format in 5 templates (sync with clean-protocol)
- All footer versions v7.0.1 → v7.1.0

### Purpose
Skills no longer assume language = country. Unified welcome format.

---

## v7.0.1 (2025-12-05)

**Type:** PATCH

### Fixed
- Footer version drift in 21 files (v6.1.0/v6.2.0 → v7.0.1)
- self-diagnostic.sh false negative on SKILL.md section check
- self-diagnostic.md SSOT sync with SKILL.md naming

### Unchanged
- All functionality
- All protocols
- All scripts logic

---

## v7.0.0 (2025-12-05)

**Type:** MINOR — "Unified Ecosystem"

### Added
- Virtual Testing engine (+vt flag)
- Deep Testing (L4-L6, +full flag)
- 6 new reference files: virtual-testing.md, test-levels.md, test-cases.md, personas.md, adversarial.md, expert-panel.md

### Changed
- P05-validate.md: Validation Layers architecture
- engines.md: Added Virtual Testing Engine
- templates.md: VT hook for skills
- quality-checklist.md: VT Gate section

### Absorbed
- skill-tester functionality merged into skill-architect

---

## v6.2.0 (2025-12-04)

**Type:** PATCH — "Self-Compliance"

### Fixed
- Explicit FIRST STEP in SKILL.md
- Absolute paths in protocols
- Naming convention enforcement

---

*CHANGELOG v1.1.0 | skill-architect v7.1.0*
