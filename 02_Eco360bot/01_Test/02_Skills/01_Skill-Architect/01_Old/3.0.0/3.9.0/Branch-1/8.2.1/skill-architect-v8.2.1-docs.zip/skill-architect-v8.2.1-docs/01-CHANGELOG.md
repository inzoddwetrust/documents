# CHANGELOG

## skill-architect

All notable changes to this skill are documented here.

---

## [v8.2.1] — 2025-12-12

### Fixed
- **Footer version sync:** 9 files had v8.0.3 instead of v8.2.1
  - commands.md
  - P00-router.md → P04-build.md
  - P06-delivery-skill.md → P08-simulation.md
- **Self-audit compliance:** Skill now passes its own validation

### Added
- **Protocol-First section** in templates.md — documents inheritance gene
- **Req 9** in genetic-audit.sh — checks for protocol_first in child skills

### Changed
- MANIFEST.md regenerated with correct line counts
- README.md updated with v8.2.1 changelog entry

---

## [v8.2.0] — 2025-12-12

### Added
- **Phase 2.5: Knowledge Redundancy Check** — detects LLM-native content bloat
- **L7 Redundancy** in quality-checklist.md — quick test for pruning
- **Frontmatter key validation** — only allowed keys pass

### Changed
- **-58% size reduction** (6,845 → 2,868 lines)
- Aggressive pruning of all files
- Concepts instead of full examples

### Removed
- Verbose prose replaced with tables
- Full templates for patterns Claude knows natively

---

## [v8.1.0] — 2025-12-10

### Added
- P09-full-audit protocol
- context-management.md reference

---

## [v8.0.3] — 2025-12-08

### Fixed
- Base stable version
- Protocol flow P01→P08

---

## Version History

| Version | Date | Codename | Key Change |
|---------|------|----------|------------|
| v8.2.1 | 2025-12-12 | Self-Heal | Footer sync + genetics |
| v8.2.0 | 2025-12-12 | Lean Core | -58% size, redundancy check |
| v8.1.0 | 2025-12-10 | — | Full audit protocol |
| v8.0.3 | 2025-12-08 | — | Base version |

---

*01-CHANGELOG.md v1.0.0 | skill-architect v8.2.1*
