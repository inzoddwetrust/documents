# Changelog

All notable changes to skill-architect.

---

## [v6.0.0] "Protocol-Driven" — 2025-12-02

### Added
- **Protocol-Driven Architecture** — all actions through explicit protocols
- `reference/protocols/` folder with 8 protocols:
  - P01-activation.md — session start
  - P02-config.md — requirements gathering
  - P03-planning.md — planning (BLOCKING)
  - P04-build.md — implementation
  - P05-validate.md — validation & diff
  - P06-delivery-skill.md — skill delivery (BLOCKING)
  - P07-delivery-docs.md — docs delivery (BLOCKING)
  - P08-scan.md — final chat scan
- Protocol Flow diagram in SKILL.md
- Protocol Router table in SKILL.md
- Clean Skill Principle #6: Protocol-Driven

### Changed
- SKILL.md restructured as router (293→166 lines, -43%)
- Inline protocols moved to dedicated files
- self-diagnostic.md updated for new structure

### Removed
- Inline protocol content from SKILL.md (moved to P01-P08)

---

## [v5.4.0] "SSOT" — 2025-12-02

### Added
- `reference/ssot-check.md` — SSOT validation protocol
- `scripts/ssot-check.sh` — semantic duplicate detection

### Changed
- SKILL.md SSOT refactor — constraints deduplicated
- validate-skill.sh v1.5 — MANIFEST path fix

### Fixed
- validate-skill.sh:87 path detection bug

---

## [v5.3.0] — 2025-12-02

### Added
- `reference/docs-packaging.md`

### Changed
- workflow.md v1.2.0

---

## [v5.2.0] "Full Cycle" — 2025-12-02

### Added
- `reference/self-diagnostic.md`
- `scripts/self-diagnostic.sh`
- Skill Dependencies section

---

## [v5.1.0] — 2025-12-02

### Added
- NEVER DEGRADE protection

### Fixed
- Restored full protocols

---

## [v5.0.0] "Project Mode" — 2025-12-01

### Added
- Project Mode for knowledge bases
- project-mode.md, project-modules.md, project-import.md, project-filters.md
- audit-project.sh

---

*CHANGELOG.md v1.0.0 | skill-architect v6.0.0*
