# DECISIONS: skill-architect v8.4.0

Architectural Decision Records for "Golden Standard" release.

---

## AD-001: PRE-BUILD CHECKPOINT in SKILL.md

**Context:** Claude loses context after web search, forgetting critical rules.

**Decision:** Add `⛔ PRE-BUILD CHECKPOINT` section directly in SKILL.md with checklist.

**Alternatives:**
- Only in P04-build.md → not visible enough
- Automatic check → no platform mechanism

**Consequences:** +12 lines, but critical for quality.

---

## AD-002: Enhanced Context Anchor with rule reminder

**Context:** Standard Context Anchor doesn't remind about rules.

**Decision:** Add second line with key constraints:
```
⚙️ skill-architect v8.4.0 · P04 · building
📋 SKILL.md=EN | README=[LANG] | <300 lines
🟢 ~80k | ~20k 🟡
```

**Consequences:** Every response reminds rules, minimal overhead.

---

## AD-003: Self-Check sections in protocols

**Context:** No systematic self-verification between protocols.

**Decision:** Add `## Self-Check Before Next Protocol` at the end of each P0X.

**Consequences:** +10-15 lines per protocol, improves transition quality.

---

## AD-004: Visual Blocking Markers

**Context:** Simple `## ⛔ BLOCKING` easy to miss.

**Decision:** Visually highlight:
```markdown
════════════════════════════════════════
⛔ BLOCKING — EXPLICIT CONFIRMATION REQUIRED
════════════════════════════════════════
```

**Consequences:** Zero overhead, significantly more visible.

---

## AD-005: retrospective.md in reference/

**Context:** V1 had valuable evolution history missing in V2.

**Decision:** Create `reference/retrospective.md` with timeline, incidents, lessons.

**Consequences:** +140 lines, but context helps understand "why".

---

## AD-006: Common Mistakes in SKILL.md

**Context:** Typical mistakes repeat (README in English, proceed on "ок понял").

**Decision:** Add `## ⚠️ Common Mistakes` table with ❌/✅ pairs.

**Consequences:** +10 lines, prevents frequent errors.

---

## AD-007: Base = V2, not V1

**Context:** Two v8.3.0 versions — V1 compact, V2 complete.

**Decision:** Use V2 as base because:
- 12 rules vs 8
- All 5 Clean Skill Principles
- L8 Version Integrity

**From V1:** Only RETROSPECTIVE.md (adapted)

---

## Decision Principles

1. **Visibility over brevity** — better visible than short
2. **Explicit over implicit** — explicit beats implicit
3. **Prevention over correction** — prevent beats fix
4. **NEVER DEGRADE** — only add, never remove

---

*DECISIONS-skill-architect-v8.4.0.md | skill-architect v8.4.0*
