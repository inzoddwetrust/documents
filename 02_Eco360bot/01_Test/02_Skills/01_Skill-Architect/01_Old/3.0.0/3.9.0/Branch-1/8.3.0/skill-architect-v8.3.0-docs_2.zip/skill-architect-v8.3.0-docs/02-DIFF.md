# Diff: v8.2.2 → v8.3.0

**Skill:** skill-architect  
**Date:** 2025-12-12

---

## Metrics

| Metric | Before | After | Δ |
|--------|--------|-------|---|
| SKILL.md lines | 133 | 146 | +13 |
| Total files | 41 | 44 | +3 |
| Reference files | 19 | 21 | +2 |
| Scripts | 9 | 10 | +1 |
| Protocols | 10 | 10 | 0 |
| Total lines | ~4617 | ~5200 | +583 |

---

## Added

| File/Section | Lines | Purpose |
|--------------|-------|---------|
| reference/diff-report.md | 87 | Restored Diff Report format |
| reference/evaluations.md | 178 | Restored E-001 to E-008 tests |
| scripts/update-version.sh | 95 | Footer sync automation |
| SKILL.md ## Critical Rules | +13 | Consolidated 12 rules table |
| SKILL.md ## Quick Activation | +5 | Active Purpose? reference |
| P02-config ## Questions to Ask | +12 | Active questions section |
| P04-build principle #3 | +1 | "Chat = 2-4 sentences" |
| quality-checklist L8 | +22 | Version Integrity layer |
| validate-skill.sh L8 | +38 | Version sync check |

---

## Changed

| File | Change | Reason |
|------|--------|--------|
| SKILL.md | Consolidated Critical Rules | Was 2 sections → 1 table |
| SKILL.md | Added Quick Activation | For active Purpose? prompt |
| P01-activation.md | Added "Purpose?" question | Was passive waiting |
| P02-config.md | Added Questions to Ask | Active vs passive |
| P04-build.md | Restored 5th principle | Was missing |
| P06-delivery-skill.md | Added diff-report.md ref | Explicit format link |
| quality-checklist.md | Added L8 | Version Integrity |
| validate-skill.sh | Added L8 check | Footer sync validation |
| All *.md footers | v8.2.x → v8.3.0 | Version sync |

---

## Removed

| What | Lines | Reason |
|------|-------|--------|
| (none) | — | NEVER DEGRADE |

⚠️ NEVER DEGRADE check: **passed**

---

## Preserved

- Protocol flow P00-P09 (unchanged)
- L7 Knowledge Redundancy checks
- Lean Principle
- All existing scripts functionality
- Project Mode files
- Virtual Testing protocol
- Packaging rules

---

## Deviation from Plan

- none

---

## Restored from v3.9.0-v4.1.0

| Item | Source Version | What |
|------|----------------|------|
| Diff Report format | v3.9.0 | Inline format with metrics |
| "Purpose?" prompt | v3.9.0 | Active question on activation |
| Clean Skill Principle #3 | v3.9.0-v5.1.0 | "Chat = 2-4 sentences" |
| evaluations.md | v4.1.0-v5.1.0 | E-001 to E-005 + E-006 to E-008 |
| Critical Rules table | v3.9.0 | 7 rules → 12 rules consolidated |

---

*Diff Report | skill-architect v8.2.2 → v8.3.0*
