# Backlog

---

## Done (v8.0.4)

- [x] ⛔ Protocol First, Always section
- [x] Iteration Principles section
- [x] Gradient Feedback principle
- [x] Single Component Rule
- [x] Context Regularization (formalized)
- [x] Forbidden patterns for protocol skipping

---

## Future Considerations

### High Priority

| Item | Description | Complexity |
|------|-------------|------------|
| Protocol footer sync | Auto-update footers to current version | M |
| Self-check script | Verify Claude followed Protocol First | S |

### Medium Priority

| Item | Description | Complexity |
|------|-------------|------------|
| Iteration log template | Standard format for tracking changes | S |
| Rollback procedure | Formal steps when Gradient Feedback fails | M |
| Protocol dependency graph | Visualize P00-P08 relationships | M |

### Low Priority / Ideas

| Item | Description | Complexity |
|------|-------------|------------|
| Auto-checkpoint | Automatic snapshots during build | L |
| Protocol metrics | Track adherence statistics | L |
| Error pattern library | Common mistakes and fixes | M |

---

## Won't Do

| Item | Reason |
|------|--------|
| Merge protocols | Violates modularity |
| Remove blocking points | Core safety mechanism |
| Auto-skip "simple" changes | Defeats Protocol First |

---

## Notes

- Keep SKILL.md < 300 lines
- New rules must be evidence-based
- Avoid duplication with reference/ files

---

*05-BACKLOG.md v1.0.0 | skill-architect v8.0.4*
