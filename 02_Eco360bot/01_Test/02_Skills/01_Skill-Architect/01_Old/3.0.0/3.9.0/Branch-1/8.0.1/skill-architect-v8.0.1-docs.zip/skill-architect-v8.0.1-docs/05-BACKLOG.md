# BACKLOG

## skill-architect v8.0.1

---

## Active

| ID | Item | Priority | Added | Status |
|----|------|----------|-------|--------|
| B-001 | Add SSOT Note to remaining `zip -r` commands (14 locations) | Low | v8.0.1 | Open |
| B-002 | Add SSOT Note to 6 files with `bash scripts/` commands | Low | v8.0.1 | Open |
| B-003 | Document `protocol_first` gene for inheritance | Medium | v8.0.1 | Open |

---

## Ideas

| ID | Item | Priority | Added | Notes |
|----|------|----------|-------|-------|
| I-001 | Auto-version sync script | Low | v8.0.1 | Detect version mismatches automatically |
| I-002 | Token counter validator | Low | v8.0.1 | Check format across all files |

---

## Completed (this session)

| ID | Item | Completed |
|----|------|-----------|
| C-001 | Token counter `~[cost]` → `~[used]` | v8.0.1 |
| C-002 | Token counter order consistency | v8.0.1 |
| C-003 | Broken link `test-levels.md` | v8.0.1 |
| C-004 | README.md version sync | v8.0.1 |
| C-005 | All footers → v8.0.1 | v8.0.1 |
| C-006 | P01-activation example version | v8.0.1 |
| C-007 | ssot-check.sh integer bug | v8.0.1 |

---

## Won't Fix

| ID | Item | Reason |
|----|------|--------|
| W-001 | Size 217KB (>100KB) | Decided: OK with modular structure |
| W-002 | 6 files >300 lines | Decided: OK if has ## sections |

---

*05-BACKLOG v1.0.0 | skill-architect v8.0.1*
