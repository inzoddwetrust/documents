# Logic Tree

Decision flow for skill-architect.

---

## Main Flow

```
[START]
    ↓
┌─────────────────────────────────┐
│ P01: ACTIVATION                 │
│ • Read clean-protocol           │
│ • Detect mode (Tool/Project)    │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│ P02: CONFIG                     │
│ • Gather purpose                │
│ • Set parameters                │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│ P03: PLANNING                   │
│ • Create plan document          │
│ ⛔ BLOCKING: wait for confirm   │
└─────────────────────────────────┘
    ↓ "да/yes/go"
┌─────────────────────────────────┐
│ P04: BUILD                      │
│ • Create/update files           │
│ • Check NEVER DEGRADE           │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│ P05: VALIDATE                   │
│ • [+vt] Virtual Testing         │
│ • Static validation (always)    │
│ • [+full] Deep testing L4-L6    │
│ • Diff Report + MANIFEST        │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│ P06: DELIVERY — SKILL           │
│ • Package .skill                │
│ ⛔ BLOCKING: wait for confirm   │
└─────────────────────────────────┘
    ↓ "docs нужны?"
┌─────────────────────────────────┐
│ P07: DELIVERY — DOCS            │
│ • 7 files minimum               │
│ • Package .zip                  │
│ ⛔ BLOCKING: all files required │
└─────────────────────────────────┘
    ↓
┌─────────────────────────────────┐
│ P08: SCAN                       │
│ • Opportunities check           │
│ • Next steps suggestion         │
└─────────────────────────────────┘
    ↓
[END]
```

---

## Decision Points

### D1: Mode Detection (P01)

```
IF "project" in request
    → Project Mode (knowledge base)
ELSE
    → Tool Mode (Claude instrument)
```

### D2: Plan Confirmation (P03)

```
IF user says "да/yes/go/делай"
    → Proceed to P04
ELIF user asks question
    → Stay in P03, clarify
ELSE
    → Wait
```

### D3: Validation Flags (P05)

```
IF "+vt" flag
    → Run Virtual Testing (Layer 0)
IF "+full" flag
    → Run Deep Testing L4-L6 (Layer 2)
ALWAYS
    → Run Static Validation (Layer 1)
    → Generate Reports (Layer 3)
```

### D4: VT Gate (P05)

```
IF VT Score ≥ 70 AND no 🔴 CRITICAL
    → Proceed
ELIF VT Score < 70
    → Review before proceed
ELIF any 🔴 CRITICAL
    → ⛔ STOP, fix first
```

### D5: Docs Request (P06→P07)

```
IF user confirms docs ("да/docs/доки")
    → Create full docs package (7 files)
ELIF user skips ("готово/skip")
    → Go directly to P08
```

---

## NEVER DEGRADE Checks

At every modification step:

```
□ Removes working functionality? → STOP
□ Replaces specific with abstract? → STOP
□ No space for new? → Move to reference/, don't delete
□ New feature? → ADD alongside, don't merge
```

---

## Recovery

```
IF state unclear
    1. Ask: "Where were we?"
    2. Check /home/claude/ for artifacts
    3. Check /mnt/user-data/outputs/ for deliverables
    4. Resume from last confirmed state
```

---

*LOGIC-TREE v1.0.0 | skill-architect v7.0.1*
