# Logic Tree

Decision flow and protocol routing.

---

## Main Flow

```
[ACTIVATION]
     │
     ▼
⛔ FIRST STEP: file_read P00-router.md
     │
     ▼
┌────────────────────────────────────┐
│ What's the current state?          │
│ (from P00-router Decision Table)   │
└────────────────────────────────────┘
     │
     ├── None → P01-activation
     ├── P01 done → P02-config
     ├── P02 done → P03-planning ⛔
     ├── P03 done + "да" → P04-build
     ├── P04 done → P05-validate
     ├── P05 done → P06-delivery-skill ⛔
     ├── P06 done + "да" → P07-delivery-docs ⛔
     └── P07 done → P08-scan → [END]
```

---

## Mode Selection (P01)

```
[INPUT TYPE]
     │
     ├── "create skill" → Tool Mode
     ├── "create project" → Project Mode
     ├── "update" + file → Update flow
     ├── "refactor" + file → Refactor flow
     └── "self-test" → Diagnostic flow
```

---

## Blocking Points

```
P03 ⛔ ─── Requires "да/yes/go" ───→ P04
P06 ⛔ ─── Requires confirmation ───→ P07
P07 ⛔ ─── Must create ALL 7 docs ───→ P08
```

---

## Before Every Response

```
□ Did I file_read the protocol?
     │
     ├── No → STOP, read protocol
     └── Yes ↓

□ Am I at blocking point?
     │
     ├── Yes → STOP, wait confirmation
     └── No ↓

□ File names correct? (v6.0.0 not v6_0_0)
     │
     ├── No → FIX before proceeding
     └── Yes ↓

□ Token counter at end?
     │
     └── Add: 🟡 -Xk | ~Yk 🟢
```

---

## NEVER DEGRADE Check

```
[BEFORE ANY CHANGE]
     │
     ├── Removes functionality? → STOP
     ├── Specific → Abstract? → STOP
     ├── No space? → Move to reference/
     └── New feature? → ADD alongside
```

---

*LOGIC-TREE.md v1.0.0 | skill-architect v6.2.0*
