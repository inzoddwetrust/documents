# LOGIC-TREE: skill-architect v9.0.0

Business logic flow documentation.

---

## Main Flow

```
[START]
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│  P01-init                                               │
│  ─────────                                              │
│  Trigger: create skill, update, refactor, checkup      │
│  Action: Gather requirements, confirm intent            │
│  Output: Ready for planning                             │
└─────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│  P02-plan ⛔ BLOCKING                                   │
│  ─────────                                              │
│  Action: Create Planning Document                       │
│  Wait: Explicit "yes", "go", or "proceed"               │
│  Invalid: "ok", "got it", "understood"                  │
└─────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│  P03-build                                              │
│  ─────────                                              │
│  Action: Create files per plan                          │
│  Validate: Run scripts/validate.sh                      │
│  Gates: G1-G5 must pass                                 │
└─────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│  P04-deliver ⛔ BLOCKING                                │
│  ────────────                                           │
│  Action: Package .skill, generate docs                  │
│  Wait: User decides "audit" or "skip"                   │
│  Optional: Full audit report                            │
└─────────────────────────────────────────────────────────┘
    │
    ▼
[END]
```

---

## Blocking Points

| Protocol | Gate | Valid Input | Invalid Input |
|----------|------|-------------|---------------|
| P02-plan | Confirmation | "yes", "go", "proceed" | "ok", "got it", "understood" |
| P04-deliver | User decision | "yes", "audit", "skip" | — |

---

## State Transitions

| From | Condition | To | File |
|------|-----------|-----|------|
| START | Skill request | P01-init | protocols/P01-init.md |
| P01 | Config complete | P02-plan | protocols/P02-plan.md |
| P02 | Valid confirmation | P03-build | protocols/P03-build.md |
| P02 | Question | P02 (stay) | — |
| P02 | Invalid confirmation | P02 (re-ask) | — |
| P03 | Validation PASS | P04-deliver | protocols/P04-deliver.md |
| P03 | Validation FAIL | P03 (fix) | — |
| P04 | "yes" / "audit" | Audit → END | scripts/audit.sh |
| P04 | "skip" | END | — |

---

## Quality Gates

| Gate | Check | Blocking | Validator |
|------|-------|----------|-----------|
| G1 | SKILL.md exists | ⛔ | scripts/validate.sh |
| G2 | SKILL.md < 300 lines | ⛔ | scripts/validate.sh |
| G3 | SKILL.md = English | ⛔ | scripts/validate.sh |
| G4 | Frontmatter valid | ⛔ | scripts/validate.sh |
| G5 | README exists | ⛔ | scripts/validate.sh |
| G6 | Explicit confirmation | ⛔ | P02-plan.md |
| G7 | NEVER DEGRADE | ⛔ | scripts/validate.sh --degrade |

---

## File Dependencies

```
SKILL.md
    ├── references → protocols/P00-router.md
    └── validated by → scripts/validate.sh

protocols/P00-router.md
    └── routes to → P01, P02, P03, P04

protocols/P02-plan.md
    └── uses template from → reference/templates.md

protocols/P03-build.md
    └── runs → scripts/validate.sh

protocols/P04-deliver.md
    ├── runs → scripts/package.sh
    ├── runs → scripts/generate-docs.sh
    └── optionally runs → scripts/audit.sh
```

---

## Recovery After Context Loss

```
1. view → SKILL.md (get version, commands)
2. view → protocols/P00-router.md (get state)
3. Check last user message
4. Resume from appropriate protocol
```

---

*LOGIC-TREE-skill-architect-v9.0.0.md | skill-architect v9.0.0*
