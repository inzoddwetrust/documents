# Skill Architect v7.0.1 "Unified Ecosystem"

> Единая экосистема: создание + тестирование + валидация скилов Claude.

---

## Быстрый старт

**Создание:** `create skill: [purpose]`

**Тестирование:** `validate +vt` / `validate +full`

**Проекты:** `create project: [name]`

**Диагностика:** `self-test`

---

## Что нового в v7.0.1

### Интегрированное тестирование

Skill-tester теперь встроен в skill-architect:

| Флаг | Что делает |
|------|------------|
| (default) | Быстрая статическая валидация |
| `+vt` | Virtual Testing (персоны, devil's advocate, expert panel) |
| `+full` | Глубокое тестирование (L4-L6) |
| `+vt +full` | Полный аудит |

### Virtual Testing

Синтетическая валидация перед релизом:

```
┌─ Context Detector ─┐
│   ↓               │
│ Persona Generator │ → 5-7 синтетических пользователей
│   ↓               │
│ Adversarial Layer │ → Devil's Advocate атаки
│   ↓               │
│ Expert Panel      │ → 5 перспектив + дебаты
│   ↓               │
│ Scoring Engine    │ → Score ≥ 70 = proceed
└───────────────────┘
```

**Важно:** VT генерирует ГИПОТЕЗЫ для валидации, не факты.

---

## Ключевые правила

### ⛔ NEVER DEGRADE

1. Это УДАЛЯЕТ работающую функциональность? → STOP
2. Это ЗАМЕНЯЕТ конкретное на абстрактное? → STOP
3. Нет места? → Вынести в reference/, не удалять

### Critical Rules

| Правило | Требование |
|---------|------------|
| SKILL.md | English, < 300 строк |
| README.md | Обязателен |
| MANIFEST.md | Обязателен если reference/ |
| Planning Document | Обязателен перед изменениями |
| Diff Report | Обязателен после изменений |

---

## Валидация

```bash
# Быстрая (L1)
bash scripts/validate-skill.sh /path/to/skill

# С Virtual Testing (+vt)
# → Запускается автоматически через P05

# Полная (L1-L6)
bash scripts/audit-skill.sh /path/to/skill
```

---

## Архитектура

```
skill-architect/
├── SKILL.md              # Router + core rules
├── reference/
│   ├── protocols/        # P00-P08 workflow
│   ├── virtual-testing.md    # VT protocol
│   ├── test-levels.md        # L1-L6 specs
│   ├── personas.md           # Synthetic users
│   ├── adversarial.md        # Devil's advocate
│   ├── expert-panel.md       # Multi-agent eval
│   └── ...
└── scripts/              # Validation scripts
```

---

## История версий

### v7.0.1 "Unified Ecosystem"

**Интеграция:**
- skill-tester поглощён в skill-architect
- Virtual Testing добавлен в P05-validate
- 6 новых reference файлов

**Добавлено:**
- `+vt` флаг для Virtual Testing
- `+full` флаг для глубокого тестирования
- Persona, Adversarial, Expert Panel engines

**Сохранено:**
- Всё ядро (50 итераций!) без изменений
- Router pattern
- Протоколы P00-P08
- Все скрипты

### v6.2.0 "Self-Compliance"

- Explicit first step
- Absolute paths
- Naming checks

### v6.0.0 "Protocol-Driven"

- Protocol-first architecture
- Blocking points
- Chat verification

---

*Skill Architect v7.0.1 "Unified Ecosystem"*
