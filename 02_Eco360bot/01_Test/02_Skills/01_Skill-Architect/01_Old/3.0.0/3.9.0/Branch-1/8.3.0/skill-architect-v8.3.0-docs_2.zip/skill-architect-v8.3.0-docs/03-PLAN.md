# skill-architect: План v8.2.2 → v8.3.0 "Restoration+" (EXTENDED)

**Дата:** 2025-12-12  
**На основе:** Анализа v3.9.0, v4.1.0, v5.1.0, v8.2.2

---

## EXECUTIVE SUMMARY

Анализ 4 версий выявил **14 проблем** (vs 8 в оригинальном плане):
- 🔴 Критических: 5 (было 3)
- 🟡 Важных: 6 (было 3)  
- 🟢 Мелких: 3 (было 2)

**Главный вывод:** v3.9.0 и v4.1.0 содержат много конкретики, которая была потеряна при эволюции к v8.x из-за "унификации" и переноса в протоколы.

---

## Constraints (unchanged)

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | User's language (RU) |
| Frontmatter | name + description (version in description) |
| Confirmation | explicit "да/yes/go" |

---

## 1. ПОЛНЫЙ СПИСОК ПРОБЛЕМ

### 🔴 Критические (потеряно, влияет на работу)

| # | Проблема | Было (версия) | Сейчас (v8.2.2) | Impact |
|---|----------|---------------|-----------------|--------|
| P-001 | **Diff Report format исчез** | v3.9.0-v5.1.0: inline format | P06 упоминает без формата | Непредсказуемые отчёты |
| P-002 | **"Purpose?" вопрос исчез** | v3.9.0: `Skill Architect ready. Purpose?` | P01 пассивный | Нет активного опроса |
| P-003 | **Critical Rules разбиты** | v3.9.0: 7 правил в таблице | 2 разрозненные секции | Сложнее проверить |
| P-009 | **Clean Skill Principle #3 потерян** | v3.9.0-v5.1.0: `Chat = 2-4 sentences` | Только 4 из 5 в P04-build | Verbose ответы |
| P-010 | **evaluations.md ПОЛНОСТЬЮ УДАЛЁН** | v4.1.0-v5.1.0: E-001 to E-005 | Файл не существует | Нет тест-кейсов |

### 🟡 Важные (не реализовано, запрошено)

| # | Проблема | Источник | Статус |
|---|----------|----------|--------|
| P-004 | Version sync check в validate-skill.sh | B-006 backlog | Не сделано |
| P-005 | Footer update automation | B-007 backlog | Не сделано |
| P-006 | Project Mode evaluations (E-006, E-007, E-008) | B-017 backlog | Не сделано с v5.3.0! |
| P-011 | **Quality Gates из workflow.md потеряны** | v4.1.0 workflow.md | Были чеклисты после каждой фазы |
| P-012 | **PRE-BUILD CHECKPOINT не в SKILL.md** | v4.1.0-v5.1.0 SKILL.md | Только в P04-build |
| P-013 | **3-Step Delivery Protocol размыт** | v4.1.0-v5.1.0 SKILL.md | Нет явной 3-шаговой структуры |

### 🟢 Мелкие

| # | Проблема | Детали |
|---|----------|--------|
| P-007 | P01-activation содержит v8.0.2 в примере | Footer: v8.2.1 |
| P-008 | genetic-audit.sh exit code 1 при partial pass | Должен быть 0 при >80% |
| P-014 | **Footer versions несогласованы** | P01: v8.2.1, P02: v8.2.1, P04: v8.2.1, P06: v8.2.2 |

---

## 2. КОНКРЕТНЫЕ ПРИМЕРЫ ПОТЕРЬ

### 2.1 Diff Report — БЫЛО (v3.9.0-v5.1.0)

```markdown
## Diff Report — BLOCKING

After implementation:

## Diff: vOLD → vNEW

| Metric | Before | After |
|--------|--------|-------|
| Lines  | X      | Y     |

### Added: [items]
### Removed: [items] — REASON
### Preserved: [items]
### Deviation from plan: [if any]

Wait for confirmation before delivery.
```

### 2.2 Diff Report — СТАЛО (v8.2.2)

```markdown
# P06-delivery-skill.md
...
3. **Present Diff Report summary** (brief)
...
```

**Проблема:** Формат не указан, результаты непредсказуемы.

---

### 2.3 Activation — БЫЛО (v3.9.0)

```markdown
## Activation

Response: `Skill Architect ready. Purpose?`

Then: Config → Plan → Build → Validate → Deliver.
```

### 2.4 Activation — СТАЛО (v8.2.2 P01)

```markdown
3. Respond with Standard Activation Response:
   Skill Architect v8.0.2
   
   Protocol-driven skill and project creation with integrated testing.
   
   Commands: create skill, create project, update, refactor...
   
4. Wait for user input
```

**Проблема:** Нет вопроса "Purpose?", пассивное ожидание.

---

### 2.5 Clean Skill Principles — БЫЛО (v3.9.0-v5.1.0)

```markdown
## Clean Skill Principles

Skills you create MUST follow:

1. **Density** — every line carries meaning
2. **No fluff** — no "Sure!", disclaimers, obvious explanations
3. **Chat = 2-4 sentences** — unless user asks more    ← ПОТЕРЯНО!
4. **Show, don't explain** — examples > descriptions
5. **N/2 rule** — asked N words, deliver N/2
```

### 2.6 Clean Skill Principles — СТАЛО (v8.2.2 P04-build)

```markdown
## Build Principles

From Clean Skill Principles:

1. **Density** — every line carries meaning
2. **No fluff** — no "Sure!", disclaimers
3. **Show, don't explain** — examples > descriptions
4. **N/2 rule** — asked N words, deliver N/2
```

**Проблема:** Пункт 3 "Chat = 2-4 sentences" полностью удалён.

---

### 2.7 evaluations.md — БЫЛО (v4.1.0-v5.1.0)

```markdown
# Evaluations: skill-architect

## E-001: Create Skill from Scratch
**Input:** create skill: генератор тестов для API
**Expected Behavior:** 8 steps...
**Success Criteria:** 6 checkboxes...

## E-002: Update Existing Skill
...

## E-003: Full Refactor
...

## E-004: Context Recovery (POST-SEARCH)
...

## E-005: Confirmation Protocol
...
```

### 2.8 evaluations.md — СТАЛО (v8.2.2)

```
❌ ФАЙЛ НЕ СУЩЕСТВУЕТ
```

**Проблема:** Нет тест-кейсов для валидации работы скила.

---

### 2.9 Critical Rules — БЫЛО (v3.9.0)

```markdown
## Critical Rules

| Rule | Requirement |
|------|-------------|
| SKILL.md | English, < 300 lines |
| README.md | Required |
| MANIFEST.md | Required if reference/ exists |
| Planning Document | Required before changes |
| Chat Verification | Required before confirm |
| Diff Report | Required after changes |
| Ask before removing | Always |
```

### 2.10 Critical Rules — СТАЛО (v8.2.2)

```markdown
## ⛔ CRITICAL RULES

### Platform Constraints

| Constraint | Rule |
|------------|------|
| Frontmatter keys | ONLY: name, description, license... |
| SKILL.md size | < 300 lines |
| SKILL.md language | English |

### Never Degrade

Before ANY change: Removes functionality? → STOP...
```

**Проблема:** Разбито на 2 секции, потеряны правила: Chat Verification, Ask before removing.

---

## 3. ПЛАН ИЗМЕНЕНИЙ (ДОПОЛНЕННЫЙ)

### 3.1 СОЗДАЁМ (NEW FILES)

| Файл | Что | Источник |
|------|-----|----------|
| **reference/diff-report.md** | Полный формат Diff Report + примеры | v3.9.0-v5.1.0 inline |
| **reference/evaluations.md** | E-001 to E-008 (восстановление + Project Mode) | v4.1.0 + B-017 |
| **scripts/update-version.sh** | Автоматизация обновления футеров | B-007 |

### 3.2 ИЗМЕНЯЕМ (EXISTING FILES)

| Файл | Изменение | До → После |
|------|-----------|------------|
| **SKILL.md** | Critical Rules consolidation | 2 секции → 1 таблица (7+ правил) |
| **SKILL.md** | Добавить Quick Reference | Нет → Activation prompt visible |
| **P01-activation.md** | Добавить "Purpose?" вопрос | Пассивный → Активный |
| **P01-activation.md** | Обновить версию | v8.0.2 → v8.3.0 |
| **P02-config.md** | Добавить "Questions to Ask" секцию | Extract → Ask |
| **P04-build.md** | Восстановить принцип #3 | 4 принципа → 5 принципов |
| **P06-delivery-skill.md** | Добавить ссылку на diff-report.md | implicit → explicit |
| **validate-skill.sh** | Добавить L8: Version Integrity | Нет → check all footers |
| **quality-checklist.md** | Добавить L8: Version Integrity | L1-L7 → L1-L8 |
| **genetic-audit.sh** | Fix exit code | 1 on partial → 0 on >80% |
| **workflow.md** | Восстановить Quality Gates | Нет → After each phase |
| **ALL protocol files** | Sync footer versions | mixed → v8.3.0 |

### 3.3 НЕ ТРОГАЕМ

| Что | Причина |
|-----|---------|
| Protocol flow P00-P09 | Работает |
| L7 Redundancy Check | Недавно добавлено, работает |
| Lean Principle | Ядро |
| Project Mode files | Работают (только добавим evaluations) |

---

## 4. ДЕТАЛЬНЫЕ СПЕЦИФИКАЦИИ

### 4.1 reference/diff-report.md (NEW)

```markdown
# Diff Report Format

Standard format for version comparison reports.

---

## Template

### Header

## Diff: v[OLD] → v[NEW]

**Skill:** [skill-name]  
**Date:** [YYYY-MM-DD]

### Metrics

| Metric | Before | After | Δ |
|--------|--------|-------|---|
| SKILL.md lines | X | Y | ±N |
| Total files | X | Y | ±N |
| Reference files | X | Y | ±N |
| Scripts | X | Y | ±N |

### Added

| File/Section | Lines | Purpose |
|--------------|-------|---------|
| [path] | N | [why added] |

### Changed

| File | Change | Reason |
|------|--------|--------|
| [path] | [what changed] | [why] |

### Removed

| What | Lines | Reason |
|------|-------|--------|
| [path/section] | N | [why removed] |

⚠️ NEVER DEGRADE check: [passed/failed]

### Preserved

- [list of unchanged critical items]

### ⚠️ Deviation from Plan

- [none / list of deviations with reasons]

---

## Rules

1. Always include metrics comparison
2. Every removal MUST have a reason
3. Check NEVER DEGRADE before finalizing
4. Wait for user confirmation after presenting

---

*diff-report.md v1.0.0 | skill-architect v8.3.0*
```

### 4.2 reference/evaluations.md (RESTORED + EXTENDED)

```markdown
# Evaluations: skill-architect

Test scenarios for validation.

---

## Tool Mode Evaluations

### E-001: Create Skill from Scratch

**Input:**
create skill: генератор тестов для API

**Expected Behavior:**
1. Activation with "Purpose?" question (or recognize from input)
2. Ask clarifying questions if needed
3. Create Planning Document
4. Wait for explicit confirmation ("да/yes/go")
5. PRE-BUILD CHECKPOINT verified
6. Build skill structure
7. Validation passes
8. Diff Report created (reference/diff-report.md format)
9. 3-Step Delivery executed

**Success Criteria:**
- [ ] SKILL.md in English
- [ ] SKILL.md < 300 lines
- [ ] README.md in Russian
- [ ] Frontmatter: name + description + version
- [ ] MANIFEST.md generated (if reference/ exists)
- [ ] All confirmations explicit

---

### E-002: Update Existing Skill

**Input:**
[attached .skill file] + "добавь секцию error handling"

**Expected Behavior:**
1. Create snapshot of original
2. Analyze current state (light review)
3. Create Planning Document with KEEP/ADD sections
4. Wait for confirmation
5. PRE-BUILD CHECKPOINT verified
6. Implement changes
7. Validation passes
8. Diff Report with metrics
9. 3-Step Delivery executed

**Success Criteria:**
- [ ] Original preserved in snapshot
- [ ] Only requested changes made
- [ ] Version bump (MINOR for new section)
- [ ] Diff Report shows before/after
- [ ] MANIFEST updated

---

### E-003: Full Refactor

**Input:**
[attached .skill file] + "refactor"

**Expected Behavior:**
1. Create snapshot of original
2. Run bash scripts/audit-skill.sh
3. Deep analysis of issues
4. Comprehensive Planning Document
5. Wait for confirmation
6. PRE-BUILD CHECKPOINT verified
7. Rebuild skill
8. Validation passes
9. Diff Report with full metrics
10. 3-Step Delivery executed

**Success Criteria:**
- [ ] Audit report reviewed
- [ ] All anti-patterns fixed
- [ ] Clean Skill Principles applied (all 5!)
- [ ] Significant improvement in metrics
- [ ] Complete documentation

---

### E-004: Context Recovery (POST-SEARCH)

**Input:**
create skill: [topic requiring web search]

**Expected Behavior:**
1. Web search performed
2. PRE-BUILD CHECKPOINT triggered
3. Core rules re-verified:
   - SKILL.md = English
   - README.md = User's language
   - < 300 lines
   - Frontmatter valid
4. Build continues correctly

**Success Criteria:**
- [ ] No language mixing after search
- [ ] All constraints respected
- [ ] No context drift visible

---

### E-005: Confirmation Protocol

**Input:**
[Planning Document presented]
User responds: "ок понял"

**Expected Behavior:**
1. Recognize invalid confirmation
2. Ask again for explicit confirmation
3. Wait for "да/yes/go/делай"
4. Only then proceed

**Success Criteria:**
- [ ] "ок", "понял", "ясно" rejected
- [ ] Clear request for explicit confirmation
- [ ] Proceeds only on valid confirmation

---

## Project Mode Evaluations

### E-006: Create Project

**Input:**
create project: Coffee Shop Business

**Expected Behavior:**
1. Activation with mode detection
2. Read project-mode.md
3. Create Planning Document
4. Wait for confirmation
5. Build project structure with data/
6. Generate modules per project-modules.md
7. Validation passes
8. Delivery with docs

**Success Criteria:**
- [ ] SKILL.md in English
- [ ] data/ folder created
- [ ] YAML modules valid
- [ ] MANIFEST.md includes data files
- [ ] README.md in user's language

---

### E-007: Import Project

**Input:**
import project + [attached documents]

**Expected Behavior:**
1. Read project-import.md
2. Analyze attached documents
3. Create import plan
4. Wait for confirmation
5. Structure data into modules
6. Apply project-filters.md
7. Validation passes
8. Delivery

**Success Criteria:**
- [ ] All source documents processed
- [ ] Data correctly structured
- [ ] Filters applied
- [ ] No data loss

---

### E-008: Generate Document from Project

**Input:**
generate investor pitch

**Expected Behavior:**
1. Load project data
2. Identify required modules
3. Generate document
4. Format per user's language
5. Deliver

**Success Criteria:**
- [ ] Uses correct data modules
- [ ] Output in user's language
- [ ] Professional formatting
- [ ] No placeholder data

---

## Evaluation Results Template

## Evaluation Run: [DATE]

| Scenario | Result | Notes |
|----------|--------|-------|
| E-001 | ✅/❌ | ... |
| E-002 | ✅/❌ | ... |
| E-003 | ✅/❌ | ... |
| E-004 | ✅/❌ | ... |
| E-005 | ✅/❌ | ... |
| E-006 | ✅/❌ | ... |
| E-007 | ✅/❌ | ... |
| E-008 | ✅/❌ | ... |

**Overall:** X/8 passed
**Issues found:** [list]
**Action items:** [list]

---

*evaluations.md v2.0.0 | skill-architect v8.3.0*
```

### 4.3 P01-activation.md CHANGES

**Add after Step 3:**

```markdown
3. Respond with Activation + Question:
   ```
   Skill Architect v8.3.0
   Protocol-driven skill/project creation.
   
   Purpose? Triggers?
   
   ⚙️ skill-architect · P01 · awaiting purpose
   🟢 ~[remaining] | ~[used] 🟡
   ```

4. If purpose already stated in trigger message → proceed to P02
   Otherwise → Wait for user input
```

### 4.4 P02-config.md CHANGES

**Add new section before Steps:**

```markdown
## Questions to Ask (if not provided)

| Question | Why | Example |
|----------|-----|---------|
| "What problem does this solve?" | Purpose | "API test generation" |
| "What words trigger it?" | Triggers | "test api, generate tests" |
| "Tool or knowledge base?" | Mode | Tool = instruments, Project = data |
| "Simple, medium, or complex?" | Complexity | Simple = <100 lines |

**Rule:** Ask before assuming. Clarify before planning.
```

### 4.5 P04-build.md CHANGES

**Restore missing principle:**

```markdown
## Build Principles

From Clean Skill Principles:

1. **Density** — every line carries meaning
2. **No fluff** — no "Sure!", disclaimers
3. **Chat = 2-4 sentences** — unless user asks more    ← RESTORED
4. **Show, don't explain** — examples > descriptions
5. **N/2 rule** — asked N words, deliver N/2
```

### 4.6 SKILL.md CHANGES

**Consolidate Critical Rules:**

```markdown
## ⛔ Critical Rules

| # | Rule | Enforcement |
|---|------|-------------|
| 1 | SKILL.md = English only | validate-skill.sh |
| 2 | SKILL.md < 300 lines | validate-skill.sh |
| 3 | Frontmatter: name + description + version | validate-skill.sh |
| 4 | README.md required | validate-skill.sh |
| 5 | MANIFEST.md if reference/ exists | validate-skill.sh |
| 6 | Planning Document before changes | P03 ⛔ |
| 7 | Chat Verification in plan | P03 |
| 8 | Diff Report after changes | P06 ⛔ |
| 9 | NEVER remove working functionality | P04 checklist |
| 10 | NEVER replace specific with abstract | P04 checklist |
| 11 | Explicit confirmation required | P03 ⛔, P06 ⛔ |
| 12 | Footer versions must match | validate-skill.sh L8 |
```

**Add Quick Activation Reference:**

```markdown
## Quick Activation

Response: `Skill Architect v8.3.0. Purpose? Triggers?`

Then: P02-config → P03-planning → P04-build → P05-validate → P06-delivery
```

### 4.7 validate-skill.sh L8 ADDITION

```bash
# L8: Version Integrity
echo ""
echo "=== L8: Version Sync Check ==="
VERSION=$(grep -oP 'v\d+\.\d+\.\d+' "$SKILL_DIR/SKILL.md" | head -1)
echo "Main version: $VERSION"

FOOTERS=$(grep -rh "skill-architect v" "$SKILL_DIR" --include="*.md" 2>/dev/null | grep -oP 'v\d+\.\d+\.\d+' | sort | uniq)
FOOTER_COUNT=$(echo "$FOOTERS" | wc -l)

if [ "$FOOTER_COUNT" -eq 1 ] && [ "$FOOTERS" = "$VERSION" ]; then
    echo -e "${GREEN}✅ All footers match: $VERSION${NC}"
else
    echo -e "${YELLOW}⚠️ Footer versions found:${NC}"
    echo "$FOOTERS"
    echo ""
    echo "Files with mismatched versions:"
    grep -r "skill-architect v" "$SKILL_DIR" --include="*.md" | grep -v "$VERSION" || echo "(none)"
    ((WARNINGS++))
fi
```

---

## 5. РИСКИ (ДОПОЛНЕННЫЕ)

| Риск | Вероятность | Impact | Mitigation |
|------|-------------|--------|------------|
| SKILL.md > 300 lines | Low | High | Consolidation + Quick Reference компактны |
| Breaking workflows | Low | High | ADD alongside, test E-001 to E-008 |
| New script bugs | Medium | Medium | Test on self before release |
| Evaluations incomplete | Medium | Low | Start with 8, expand later |
| Footer sync tedious | High | Low | update-version.sh automates |
| Quality Gates verbose | Medium | Medium | Keep as reference file, not inline |

---

## 6. EFFORT ESTIMATE (UPDATED)

| Task | Time | Priority |
|------|------|----------|
| diff-report.md (NEW) | 30 min | 🔴 Critical |
| evaluations.md (RESTORED) | 45 min | 🔴 Critical |
| P01, P02 updates | 30 min | 🔴 Critical |
| P04-build principle #3 | 5 min | 🔴 Critical |
| SKILL.md consolidation | 30 min | 🔴 Critical |
| validate-skill.sh L8 | 30 min | 🟡 Important |
| update-version.sh (NEW) | 30 min | 🟡 Important |
| workflow.md Quality Gates | 20 min | 🟡 Important |
| genetic-audit.sh fix | 10 min | 🟢 Minor |
| Footer sync all files | 20 min | 🟢 Minor |
| Testing & validation | 60 min | 🔴 Critical |
| **Total** | **~5.5 hours** | |

---

## 7. VERIFICATION CHECKLIST

### Before Confirmation

- [ ] All 14 problems addressed in plan
- [ ] Concrete "БЫЛО → СТАЛО" examples provided
- [ ] No functionality removed (NEVER DEGRADE)
- [ ] Effort estimate realistic
- [ ] Risks identified and mitigated

### After Build

- [ ] Run E-001 to E-008 evaluations
- [ ] validate-skill.sh passes
- [ ] All footers v8.3.0
- [ ] Diff Report created per new format
- [ ] SKILL.md < 300 lines

---

## Deliverables

| # | Deliverable | Format |
|---|-------------|--------|
| 1 | skill-architect-v8.3.0.skill | .skill archive |
| 2 | skill-architect-v8.3.0-docs.zip | docs archive |
| 3 | Diff Report | per diff-report.md format |

---

**⚙️ skill-architect · P03-planning · awaiting confirmation**

Ожидаю подтверждение: **"да"**, **"yes"**, **"go"**, **"делай"**

---

*skill-architect v8.2.2 → v8.3.0 Extended Planning Document*
*Based on analysis of v3.9.0, v4.1.0, v5.1.0, v8.2.2*
