# Architectural Decisions

## skill-architect v8.0.2

---

## D-001: Purpose Block Format

**Context:** Скиллы создавались без чёткого определения цели.

**Decision:** Обязательный Purpose блок с 4 полями:
- serves — кому служит
- goal — измеримый результат
- method — способ достижения
- success — критерий успеха

**Rationale:** Табличный формат компактнее prose, легче валидировать.

**Status:** ✅ Implemented

---

## D-002: Context Anchor Simplification

**Context:** Формат Context Anchor плавал — код-блок, разные строки.

**Decision:** Единый однострочный формат:
```
⚙️ skill-name · state · status
```

**Rationale:**
- Компактнее
- Не требует код-блока
- Визуально выделяется emoji
- Легко парсить глазами

**Status:** ✅ Implemented

---

## D-003: Code-to-Artifact Rule

**Context:** Код появлялся в чате вместо артефактов.

**Decision:** Код/YAML/JSON >3 строк → ТОЛЬКО в артефакт.

**Rationale:** Улучшает читаемость, артефакты легче копировать.

**Status:** ✅ Implemented

---

## D-004: Version Sync Strategy

**Context:** 7 файлов застряли на v8.0.0.

**Decision:** При PATCH обновлять ВСЕ изменённые файлы + файлы с устаревшей версией.

**Rationale:** Консистентность важнее минимизации изменений.

**Status:** ✅ Implemented

---

*04-DECISIONS v1.0.0 | skill-architect v8.0.2*
