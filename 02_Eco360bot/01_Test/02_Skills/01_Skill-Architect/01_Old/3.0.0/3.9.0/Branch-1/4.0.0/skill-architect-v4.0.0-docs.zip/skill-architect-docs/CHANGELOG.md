# Changelog: skill-architect

Все значительные изменения скилла документируются здесь.

Формат основан на [Keep a Changelog](https://keepachangelog.com/),
версионирование следует [SemVer](https://semver.org/).

---

## [4.0.0] - 2025-11-30

**Модель:** Claude Opus 4.5  
**Тип:** MAJOR (breaking changes)  
**Кодовое имя:** "Unified + Docs"

### Breaking Changes
- **Mandatory token counter** — обязательный счётчик в каждом ответе
- **No activation ceremony** — сразу в работу без "Skill Architect ready"
- **Unified workflow** — нет отдельных REFACTOR/UPDATE протоколов
- **Docs отдельно** — версионные документы не в .skill файле

### Добавлено
- `Quick Start` — мгновенный онбординг с примерами команд
- `Single Responsibility` — правило "один скилл = одна задача"
- `Output Separation` — разделение runtime (.skill) и docs
- `Evaluation Mindset` — Anthropic best practice с model testing
- `Docs Workflow` — формализованный цикл версионирования
- `Planning Document Example` — inline пример KEEP/REMOVE/ADD
- `Self-Test` — проверка token counter при активации

### Изменено
- SKILL.md: 223 → 232 строк (новые секции минус удалённое)
- README.md: v3.8.0 → v4.0.0 (синхронизация)
- Description: добавлен "Use when:" паттерн Anthropic
- Versioning: table → prose (7 → 4 строки)
- Token counter: optional → **mandatory**
- REFACTOR + UPDATE: 2 протокола → 1 Unified Workflow

### Удалено
- Activation ceremony ("Skill Architect ready. Purpose?")
- Отдельный REFACTOR Protocol (~20 строк)
- Отдельный UPDATE Protocol (~15 строк)
- Critical Rules table (избыточно)
- Context Tracking в конце (перенесён наверх)

### Контекст
Создано на основе:
- Self-Audit v3.9.0 (score 84/100)
- ACTION-PLAN.md с приоритетами
- ADDENDUM (Anthropic best practices)
- Уроки из v4.0.0-Opus, v4.0.0-Sonnet, v5.0.0
- Обсуждение docs workflow 2025-11-30

---

## [3.9.0] - 2025-11-29

**Модель:** Claude  
**Тип:** MINOR  
**Кодовое имя:** "Clean + MANIFEST"

### Добавлено
- Clean Skill Principles секция
- Chat Verification в Planning Document
- MANIFEST.md как обязательный для reference/
- generate-manifest.sh скрипт
- Context Tracking секция

### Изменено
- SKILL.md: 344 → 223 строк (-35%)
- Config: 9 вопросов → 2 (smart derivation)
- validate-skill.sh: v1.2 → v1.3
- packaging.md: добавлен MANIFEST section
- templates.md: добавлен MANIFEST template

---

## [3.8.0] - 2025-11 (ранее)

**Кодовое имя:** "Planning Document First"

### Добавлено
- Planning Document как обязательный шаг
- KEEP/REMOVE/ADD структура плана
- Правила валидного подтверждения

### Изменено
- Workflow: сначала план, потом работа

---

## [3.x.x] - ранее

История до v3.8.0 не задокументирована в новом формате.

---

## Ретроспектива

### Паттерны по версиям:

| Версия | Фокус | Результат |
|--------|-------|-----------|
| 3.8.0 | Planning first | ✅ Уменьшило ошибки |
| 3.9.0 | Компактность | ✅ -35% строк |
| 4.0.0 | Унификация + Docs | ✅ +10 quality score |

### Уроки:

1. **v4-Opus vs v4-Sonnet:** Opus компактнее, Sonnet раздувает
2. **v5.0.0:** Over-engineering (state-machine, modules) — отклонено
3. **Docs отдельно:** Версионные файлы не должны раздувать runtime

---

*Changelog v1.0.0 | skill-architect*
