# Logic Tree

## skill-architect v8.0.3

---

## Protocol Flow

```
[USER REQUEST]
      │
      ▼
┌─────────────┐
│ P00-router  │ ← Determines next protocol
└─────────────┘
      │
      ▼
┌─────────────┐
│ P01-activ.  │ ← Skill activated, mode detected
└─────────────┘
      │
      ▼
┌─────────────┐
│ P02-config  │ ← Purpose, triggers, constraints
└─────────────┘
      │
      ▼
┌─────────────┐
│ P03-planning│ ⛔ BLOCKING
└─────────────┘
      │ (explicit confirmation)
      ▼
┌─────────────┐
│ P04-build   │ ← Implementation
└─────────────┘
      │
      ▼
┌─────────────┐
│ P05-validate│ ← Testing, Diff Report
└─────────────┘
      │
      ▼
┌─────────────┐
│ P06-delivery│ ⛔ BLOCKING
└─────────────┘
      │ (skill packaged)
      ▼
┌─────────────┐
│ P07-closure │ ⛔ BLOCKING
│ (scan+docs) │
└─────────────┘
      │
      ▼
┌─────────────┐
│ P08-simul.  │ ← OPTIONAL
│ (dry-run)   │
└─────────────┘
      │
      ▼
    [END]
```

---

## Decision Points

### P03 → P04
```
User says "да/yes/go/делай"?
├── YES → P04-build
└── NO  → Stay P03, wait
```

### P06 → P07
```
Skill delivered?
├── YES → P07-closure
└── NO  → Stay P06
```

### P07 → P08
```
User wants simulation?
├── "да/yes" → P08-simulation
└── "skip/нет" → END
```

---

## Mode Selection

```
Request contains "project"?
├── YES → Project Mode
│         └── Creates: Knowledge bases
└── NO  → Tool Mode (default)
          └── Creates: Claude instruments
```

---

## Validation Layers

```
P05-validate
├── L0: Virtual Testing [+vt flag]
│   └── Personas, Adversarial, Expert Panel
├── L1: Static Validation [always]
│   └── validate-skill.sh, validate-naming.sh, ssot-check.sh
├── L2: Deep Testing [+full flag]
│   └── L4-L6 from testing-framework.md
└── L3: Reporting [always]
    └── Diff Report, MANIFEST.md
```

---

## Key Files

```
skill-architect/
├── SKILL.md          ← Router, constraints, resources
├── README.md         ← User documentation
├── MANIFEST.md       ← File inventory
├── reference/
│   ├── protocols/    ← P00-P08
│   ├── commands.md   ← SSOT for shell
│   ├── templates.md  ← SKILL.md templates
│   └── ...
└── scripts/          ← Validation automation
```

---

*08-LOGIC-TREE v1.0.0 | skill-architect v8.0.3*
