# Decisions: skill-architect v8.3.0

Architectural decisions for v8.3.0 "Restoration+".

---

## D-001: Restore vs Recreate

**Context:** Analysis showed v3.9.0-v4.1.0 had features lost in v5→v8 evolution.

**Decision:** RESTORE original patterns, not recreate.

**Rationale:**
- Original patterns were tested and worked
- Users confirmed v4.1.0 "worked wonderfully"
- Recreating risks introducing new bugs

**Outcome:** Copied exact formats from v3.9.0-v4.1.0 into new files.

---

## D-002: Diff Report as Separate File

**Context:** Diff Report format was inline in old SKILL.md, now SKILL.md is lean.

**Decision:** Create separate reference/diff-report.md.

**Rationale:**
- Keeps SKILL.md under 300 lines
- Allows detailed format with examples
- P06 references it explicitly

**Outcome:** 87-line reference file with template and example.

---

## D-003: 12 Consolidated Rules

**Context:** v8.2.2 had rules split across 2 sections.

**Decision:** Consolidate into single table with 12 rules.

**Rationale:**
- Easier to check compliance
- Single source of truth
- Matches v3.9.0 approach

**Outcome:** One `## ⛔ Critical Rules` table in SKILL.md.

---

## D-004: Active vs Passive Activation

**Context:** v8.x activation was passive ("wait for user input").

**Decision:** Restore active "Purpose? Triggers?" question.

**Rationale:**
- Guides user immediately
- Reduces back-and-forth
- Matches original v3.9.0 behavior

**Outcome:** P01-activation now prompts actively.

---

## D-005: evaluations.md Restoration + Extension

**Context:** evaluations.md was completely deleted in v6+.

**Decision:** Restore E-001 to E-005, add E-006 to E-008 for Project Mode.

**Rationale:**
- Test scenarios essential for validation
- Project Mode never had evaluations (backlog item B-017)
- Comprehensive coverage for both modes

**Outcome:** 8 evaluation scenarios covering Tool and Project modes.

---

## D-006: Version Integrity as L8

**Context:** Footer versions were inconsistent (P-014 bug).

**Decision:** Add L8 layer in quality-checklist + validate-skill.sh.

**Rationale:**
- Automated detection of version drift
- Prevents user confusion
- update-version.sh provides fix

**Outcome:** L8 check + update-version.sh script.

---

## D-007: Clean Skill Principle #3 Restoration

**Context:** "Chat = 2-4 sentences" was dropped from P04-build.

**Decision:** Restore as explicit principle.

**Rationale:**
- Prevents verbose responses
- Core to Clean Skill philosophy
- Was in all versions until v6+

**Outcome:** 5 principles in P04-build (was 4).

---

## D-008: NEVER DEGRADE Verification

**Context:** This update adds content, could risk SKILL.md bloat.

**Decision:** Verify NEVER DEGRADE at each step.

**Rationale:**
- Consolidation offset additions
- No functionality removed
- Net improvement in clarity

**Outcome:** SKILL.md 133→146 lines (+13), still under 300.

---

*04-DECISIONS.md v1.0.0 | skill-architect v8.3.0*
