# Changelog

## skill-architect

---

### v8.1.0 "Full Audit" (2025-12-12)

**Added:**
- P09-full-audit.md — единый протокол полного аудита
- full-audit.sh — скрипт комплексного аудита с флагами
- context-management.md — стратегия управления контекстом
- Trigger "чекап" → P09 (сразу полный аудит)
- Flags --web, --vt, --full для full-audit.sh

**Changed:**
- P00-router — added P09 route from any state
- Quick Start section — updated audit commands
- All footers synced to v8.1.0

**Source:** Self-audit выявил отсутствие единого протокола чекапа

---

### v8.0.4 "Protocol First" (2025-12-12)

**Added:**
- ⛔ Protocol First, Always — anti-skip rules
- Iteration Principles section
- Gradient Feedback rule (one step → verify → next)
- Single Component Rule (don't change >1 per iteration)
- Context Regularization (one protocol/file at a time)

**Source:** Research on neural network / autistic cognition parallels

---

### v8.0.3 (2025-12-08)

**Changed:**
- P07-scan + P08-docs-closure → P07-closure (merged)

**Added:**
- P08-simulation — optional virtual testing

**Fixed:**
- Broken refs in P06 (P07-delivery-docs, P08-scan)
- Version sync — all 29 files now v8.0.3

---

### v8.0.2 "Purpose & Consistency" (2025-12-08)

**Added:**
- Purpose block (serves/goal/method/success) to SKILL.md
- Mandatory Purpose block requirement in templates.md
- Purpose Check in P05-validate.md Layer 1
- Code-to-artifact rule (>3 lines → artifact only)

**Changed:**
- Context Anchor → one-line format `⚙️ skill · state · status`

**Fixed:**
- Version sync — 7 files were stuck on v8.0.0

---

### v8.0.1 (2025-12-07)

**Fixed:**
- Token counter format `~[cost]` → `~[used]`
- Token counter order consistency across all files
- Broken link `test-levels.md` → `testing-framework.md`
- Version sync — all footers now v8.0.1
- Bug in ssot-check.sh integer parsing

---

### v8.0.0 "Testing Evolution" (2025-12-07)

**Initial release with:**
- Protocol-driven architecture (P00-P08)
- Genetic Audit
- Virtual Testing
- Self-diagnostic

---

*01-CHANGELOG v1.0.0 | skill-architect v8.1.0*
