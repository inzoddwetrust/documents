# Decisions: v7.2.0

Architectural decisions for this version.

---

## D-001: P07↔P08 Swap

**Context:** Docs created before scan = scan results not in docs

**Options:**
- A: Keep as is, add scan to docs manually
- B: Swap P07↔P08, scan feeds into docs
- C: Merge into single protocol

**Decision:** B — Swap protocols

**Rationale:** Logical flow: build → deliver → scan → document findings → close

**Consequences:** Protocol renaming, router update

---

## D-002: Flat Docs Structure

**Context:** decisions/ subfolder for one file = overengineered

**Options:**
- A: Keep subfolders for organization
- B: Flat structure, numbered files
- C: Single mega-doc

**Decision:** B — Flat with numbering

**Rationale:** 
- Number = reading order = importance
- No navigation overhead
- Easy validation

**Consequences:** 8 required files, validate-docs.sh

---

## D-003: Context Anchor Format

**Context:** Inline backticks don't allow one-click copy

**Options:**
- A: Inline backticks (current)
- B: Code block (triple backticks)
- C: Plain text

**Decision:** B — Code block

**Rationale:** Code blocks copy with one click in most interfaces

**Consequences:** Update templates.md, SKILL.md, P01-activation.md

---

## D-004: 08-LOGIC-TREE Required

**Context:** User values business logic view highly

**Options:**
- A: Optional (include in README)
- B: Required separate file
- C: Auto-generate from protocols

**Decision:** B — Required separate file

**Rationale:** Business perspective ≠ technical docs. Deserves dedicated file.

**Consequences:** Always create 08-LOGIC-TREE.md, even for simple skills

---

*04-DECISIONS v1.0.0 | skill-architect v7.2.0*
