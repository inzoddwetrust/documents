# Backlog

## skill-architect

---

## Active

| # | Task | Priority | Added | Notes |
|---|------|----------|-------|-------|
| B-001 | Update commands.md footer | Low | 2025-12-08 | Still shows v8.0.1 in some places |
| B-002 | clean-protocol sync | Med | 2025-12-08 | Token counter format minor diff |

---

## Completed (v8.0.3)

- [x] B-003: P07+P08 merge + Simulation Mode
- [x] P06 broken refs fix
- [x] Version sync all files → v8.0.3

---

## Ideas

| # | Idea | Added | Notes |
|---|------|-------|-------|
| I-001 | Auto-sync versions script | 2025-12-08 | Mass footer update |
| I-002 | SSOT validation for Context Anchor | 2025-12-08 | Format consistency check |
| I-003 | P08-simulation auto-trigger for major versions | 2025-12-08 | Auto-run on X.0.0 |

---

*05-BACKLOG v1.0.0 | skill-architect v8.0.3*
