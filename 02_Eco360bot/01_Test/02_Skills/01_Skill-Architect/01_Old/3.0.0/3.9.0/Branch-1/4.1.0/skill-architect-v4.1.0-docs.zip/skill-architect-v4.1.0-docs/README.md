# Skill Architect v4.1.0 — Документация

Полная документация к версии 4.1.0 "Delivery Protocol".

---

## Содержимое архива

| Файл | Назначение |
|------|------------|
| v4.1.0-PLAN.md | План обновления v4.0.0 → v4.1.0 |
| v4.1.0-DIFF.md | Сравнение версий, метрики |
| CHANGELOG.md | История всех версий |
| BACKLOG.md | Идеи на будущее |
| LOGIC-TREE.md | Пайплайн логики скилла |
| decisions/v4.1.0-decisions.md | Решения и их обоснования |
| README.md | Этот файл |

---

## Что нового в v4.1.0

### 3-Step Delivery Protocol

```
Step 1: SKILL → package → link → wait "да"
Step 2: DOCS  → package → link → wait "да"
Step 3: SCAN  → chat scan → BACKLOG update
```

Позволяет итерировать docs без пересборки skill.

### PRE-BUILD CHECKPOINT

Защита от context drift после web_search и длинных сессий:

```
□ SKILL.md = English only
□ README.md = User's language
□ SKILL.md < 300 lines
□ Frontmatter: name + description + version
□ Plan confirmed with explicit "да/yes/go"
```

### evaluations.md

5 тестовых сценариев для валидации скилла:
- E-001: Create Skill from Scratch
- E-002: Update Existing Skill
- E-003: Full Refactor
- E-004: Context Recovery (POST-SEARCH)
- E-005: Confirmation Protocol

### Constraints Reminder

Таблица правил в planning-document.md для copy-paste в каждый план.

---

## Миграция с v4.0.0

Обратно совместима. Новые секции добавлены, ничего не удалено из API.

**Действия:**
1. Заменить .skill файл
2. Прочитать новые секции в SKILL.md
3. Опционально: прогнать evaluations

---

## Известные особенности

### Кириллица в SKILL.md

Валидатор показывает warning на кириллицу. Это ожидаемо для:
- Триггеров на русском в description
- Примеров confirmation phrases ("да", "ок", "понял")

Не является ошибкой.

---

## Следующие шаги (из BACKLOG)

**v4.2.0 кандидаты:**
- B-001: clean-protocol для композиции
- B-005: development-guide.md
- B-009: init-docs.sh скрипт

---

*README docs v1.0.0 | skill-architect v4.1.0 | 2025-11-30*
