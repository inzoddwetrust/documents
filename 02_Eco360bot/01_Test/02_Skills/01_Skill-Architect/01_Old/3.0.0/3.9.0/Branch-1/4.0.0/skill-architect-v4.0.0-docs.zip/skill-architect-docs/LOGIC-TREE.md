# LOGIC-TREE: skill-architect v4.0.0

Пайплайн логики в формате numbered tree + mermaid визуализация.

---

## Numbered Tree (source of truth)

```
1. ACTIVATION
   1.1. Триггер: "create skill", "refactor", "создай скилл", "обнови скилл"
   1.2. Загрузка: SKILL.md
   1.3. Init: token counter active
   1.4. → 2.

2. INIT (Quick Config)
   2.1. Проверка: purpose определён?
      2.1.1. НЕТ → Спросить: "Purpose? Triggers?"
      2.1.2. ДА → 2.2
   2.2. Определение type: CREATE | UPDATE | REFACTOR
   2.3. Определение complexity: simple | standard | complex
   2.4. → 3.

3. RESEARCH
   3.1. IF type=UPDATE|REFACTOR:
      3.1.1. Snapshot: cp -r source /home/claude/skill-ORIGINAL
      3.1.2. IF REFACTOR: bash scripts/audit-skill.sh
      3.1.3. Анализ текущего состояния
   3.2. IF type=CREATE:
      3.2.1. Исследование домена (web_search если нужно)
      3.2.2. Выбор шаблона из reference/templates.md
   3.3. → 4.

4. DESIGN
   4.1. Загрузка: reference/templates.md
   4.2. Выбор шаблона по ключевым словам purpose
   4.3. IF complex:
      4.3.1. Выбор движков из reference/engines.md
      4.3.2. Analysis → INoT
      4.3.3. Multi-stakeholder → Multi-Perspective
      4.3.4. User input → Security
      4.3.5. Critical output → Validation
   4.4. → 5.

5. PLAN (BLOCKING)
   5.1. Загрузка: reference/planning-document.md
   5.2. Создание Planning Document:
      5.2.1. Контекст (источники, цели)
      5.2.2. Секция KEEP (что сохраняем)
      5.2.3. Секция REMOVE (что удаляем + причины)
      5.2.4. Секция ADD (что добавляем)
   5.3. Chat Verification:
      5.3.1. Сканирование всего разговора
      5.3.2. Список обсуждённых пунктов
      5.3.3. Проверка против плана
      5.3.4. Отчёт: "Verified: N items. Missing: [list]"
   5.4. Ожидание подтверждения
   5.5. → 6.

6. CONFIRM (BLOCKING)
   6.1. Представление плана пользователю
   6.2. Проверка ответа:
      6.2.1. Валидный ("да", "yes", "делай", "go", "proceed") → 7.
      6.2.2. Невалидный ("ок", "понял") → Переспросить
      6.2.3. Запрос изменений → 5.2
   6.3. → 7.

7. BUILD
   7.1. Создание структуры: mkdir /home/claude/skill-name/
   7.2. Создание SKILL.md:
      7.2.1. Frontmatter (name, description с версией)
      7.2.2. Секции по шаблону
      7.2.3. Проверка: < 300 строк, English only
   7.3. Создание README.md (язык пользователя)
   7.4. Создание reference/ (если нужны)
   7.5. Создание scripts/ (если нужны)
   7.6. → 8.

8. VALIDATE
   8.1. Запуск: bash scripts/validate-skill.sh
   8.2. Проверка результатов:
      8.2.1. PASS → 8.3
      8.2.2. FAIL → Исправить → 8.1
   8.3. Генерация: bash scripts/generate-manifest.sh
   8.4. → 9.

9. DIFF REPORT (BLOCKING)
   9.1. Создание Diff Report:
      9.1.1. Метрики до/после
      9.1.2. Добавленное
      9.1.3. Удалённое + причины
      9.1.4. Сохранённое
   9.2. Ожидание подтверждения
   9.3. → 10.

10. DELIVER SKILL
    10.1. Упаковка: zip -r skill-name-vX.Y.Z.skill skill-name/
    10.2. Проверка: unzip -l (структура)
    10.3. Копирование в /mnt/user-data/outputs/
    10.4. Ссылка пользователю
    10.5. Ожидание: "да" → 11.

11. DELIVER DOCS
    11.1. Создание docs/:
       11.1.1. vX.Y.Z-PLAN.md
       11.1.2. vX.Y.Z-DIFF.md
       11.1.3. CHANGELOG.md (append)
       11.1.4. BACKLOG.md (update)
       11.1.5. README.md (full docs RU)
       11.1.6. LOGIC-TREE.md (if changed)
       11.1.7. decisions/vX.Y.Z-decisions.md
    11.2. Упаковка: zip -r skill-name-vX.Y.Z-docs.zip docs/
    11.3. Ссылка пользователю
    11.4. Ожидание: "да" → 12.

12. FINAL SCAN (NEW in v4.0.0)
    12.1. Полный скан чата
    12.2. Сверка: обсуждали vs сделали
    12.3. IF упущено:
       12.3.1. Добавить в BACKLOG
       12.3.2. Перепаковать docs.zip
    12.4. Отчёт пользователю
    12.5. → END

13. PER-RESPONSE (на каждом ответе)
    13.1. Token counter в конце: 🟡 -[cost] | ~[remaining] 🟢
```

---

## Mermaid (визуализация)

```mermaid
flowchart TD
    A[1. ACTIVATION] --> B[2. INIT]
    B --> |unclear| B1[Ask: Purpose?]
    B1 --> B
    B --> |clear| C[3. RESEARCH]
    
    C --> |UPDATE/REFACTOR| C1[Snapshot + Audit]
    C --> |CREATE| C2[Domain Research]
    C1 --> D[4. DESIGN]
    C2 --> D
    
    D --> E[5. PLAN]
    E --> F{6. CONFIRM}
    
    F --> |invalid| F1[Ask Again]
    F1 --> F
    F --> |changes| E
    F --> |"да/yes/go"| G[7. BUILD]
    
    G --> H{8. VALIDATE}
    H --> |fail| H1[Fix Issues]
    H1 --> H
    H --> |pass| I[9. DIFF REPORT]
    
    I --> J{10. DELIVER SKILL}
    J --> |"да"| K[11. DELIVER DOCS]
    K --> |"да"| L[12. FINAL SCAN]
    L --> |missing items| L1[Update BACKLOG]
    L1 --> L2[Repack docs.zip]
    L2 --> M((END))
    L --> |complete| M
```

---

## 3-Step Delivery (v4.0.0)

```
┌─────────────────────────────────────────────────┐
│  STEP 1: SKILL                                  │
│  → Package .skill → Link → Wait "да"            │
├─────────────────────────────────────────────────┤
│  STEP 2: DOCS                                   │
│  → Package docs.zip → Link → Wait "да"          │
├─────────────────────────────────────────────────┤
│  STEP 3: FINAL SCAN                             │
│  → Scan chat → Compare → BACKLOG → Repack       │
└─────────────────────────────────────────────────┘
```

---

## Diff: v3.9.0 → v4.0.0

### Добавлено
- 10-11-12: 3-Step Delivery (SKILL → DOCS → SCAN)
- 5.3: Chat Verification формализован
- 12: FINAL SCAN как обязательный шаг

### Изменено
- 9: Diff Report теперь отдельный шаг (был часть VALIDATE)
- 11: DELIVER разбит на SKILL и DOCS

### Удалено
- Activation ceremony ("Skill Architect ready")
- Отдельные REFACTOR/UPDATE протоколы → Unified в step 2-3

---

*LOGIC-TREE v1.0.0 | skill-architect v4.0.0 | 2025-11-30*
