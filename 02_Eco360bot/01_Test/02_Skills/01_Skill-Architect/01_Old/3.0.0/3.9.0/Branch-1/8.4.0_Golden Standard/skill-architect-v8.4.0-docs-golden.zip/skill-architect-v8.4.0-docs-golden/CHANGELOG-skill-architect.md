# CHANGELOG: skill-architect

All notable changes to Skill Architect.

Format: [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)

---

## [8.4.0] - 2025-12-12 "Golden Standard"

### Added
- **SKILL.md**: ⛔ PRE-BUILD CHECKPOINT section (context drift protection)
- **SKILL.md**: ⚠️ Common Mistakes table
- **SKILL.md**: Enhanced Context Anchor with rule reminder line
- **retrospective.md**: Evolution history from 18+ versions
- **All protocols**: Self-Check section before next protocol
- **P00-router.md**: Enhanced Recovery Protocol for context loss

### Changed
- **Context Anchor**: Now includes rule reminder `📋 SKILL.md=EN | README=[LANG] | <300 lines`
- **Blocking markers**: Visual enhancement `════ ⛔ BLOCKING ════`
- **templates.md**: Updated Context Anchor template with rule reminder
- **evaluations.md**: Added inline example output for E-001

### Fixed
- All footers synced to v8.4.0

### Technical
- Base: v8.3.0 (12 rules, L1-L8, all 5 principles)
- 45 files total (+1 retrospective.md)
- ~5500 lines total

---

## [8.3.0] - 2025-12-12 "Restoration+"

### Added
- **diff-report.md**: Restored Diff Report format
- **evaluations.md**: E-001 to E-008 test scenarios
- **update-version.sh**: Footer sync automation script
- **quality-checklist.md**: L8 Version Integrity layer
- **P02-config.md**: "Questions to Ask" section

### Fixed
- **P01-activation.md**: Active "Purpose?" prompt
- **P04-build.md**: Restored Clean Skill Principle #3
- **SKILL.md**: Consolidated 12 Critical Rules

### Technical
- 44 files total
- ~5200 lines total

---

## [8.2.2] - 2025-12-12 "Package Guard"

### Added
- **packaging.md**: ⛔ BEFORE PACKAGING — MANDATORY section
- **validate-skill.sh**: ZIP format validation

### Fixed
- Prevented "Invalid zip file" errors from tar+gzip usage

---

## [8.2.1] - 2025-12-11

### Added
- Frontmatter key validation
- SSOT check script

---

## [8.2.0] - 2025-12-10 "Lean Core"

### Added
- L7 Knowledge Redundancy checks
- Aggressive pruning protocols
- Frontmatter validation

### Changed
- -58% size reduction (6,845 → 2,868 lines)

---

*CHANGELOG-skill-architect.md | skill-architect v8.4.0*
