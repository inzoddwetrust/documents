# Backlog

Future improvements and known issues for skill-architect.

---

## Active

| # | Task | Priority | Source |
|---|------|----------|--------|
| B-001 | Auto-detect protocol from context | Medium | v6.2.0 BACKLOG |
| B-002 | Protocol execution logging | Low | v6.2.0 BACKLOG |
| B-003 | Template generator script | Low | v6.2.0 BACKLOG |
| B-004 | MANIFEST.md generation — add descriptions | Medium | v6.2.0 BACKLOG |

---

## Known Issues

| # | Issue | Severity | Workaround |
|---|-------|----------|------------|
| I-001 | validate-skill.sh warns on "." folder | Low | Ignore, cosmetic |

---

## Done

### v7.0.1

| # | Task | Implemented |
|---|------|-------------|
| B-005 | Footer version drift | All 21 files updated |
| B-006 | self-diagnostic.sh false negative | Pattern fixed |

### v7.0.0

| # | Task | Implemented |
|---|------|-------------|
| — | skill-tester integration | Absorbed into P05-validate |
| — | Virtual Testing engine | reference/virtual-testing.md |

### v6.2.0

| # | Task | Implemented |
|---|------|-------------|
| — | Claude skips FIRST STEP | Explicit ⛔ added |

---

*BACKLOG v1.0.0 | skill-architect v7.0.1*
