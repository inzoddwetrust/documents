# Logic Tree

## skill-architect v8.1.0

---

## P09-full-audit Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INPUT                                │
│     "чекап" / "full-audit" / "self-audit" / "diagnose"      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    P00-ROUTER                                │
│              Detects audit trigger                           │
│              Routes to P09 (from ANY state)                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    P09-FULL-AUDIT                            │
│                    Parse flags                               │
└─────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┼───────────────┐
              ▼               ▼               ▼
         (no flag)         --web           --vt
         --full includes both
              │               │               │
              ▼               ▼               ▼
┌─────────────────────────────────────────────────────────────┐
│  PHASE 1: STRUCTURE                                          │
│  └─ self-diagnostic.sh                                       │
│     ├─ File existence                                        │
│     ├─ Size limits                                           │
│     ├─ Protocol integrity                                    │
│     └─ SSOT compliance                                       │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  PHASE 2: GENETICS                                           │
│  └─ genetic-audit.sh                                         │
│     ├─ Extract parent genes                                  │
│     ├─ Extract child requirements                            │
│     ├─ Build inheritance matrix                              │
│     └─ Identify lost genes / mutations                       │
└─────────────────────────────────────────────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │   --web flag?      │
                    └─────────┬─────────┘
                         YES  │  NO
                              │   └──────────────┐
                              ▼                  │
┌─────────────────────────────────────────────────────────────┐
│  PHASE 3: INDUSTRY VALIDATION (manual)                       │
│  └─ web_search for:                                          │
│     ├─ LLM prompt engineering best practices 2025            │
│     ├─ AI agent design patterns state machine                │
│     ├─ Claude system prompt best practices                   │
│     └─ Reusable AI skill module design                       │
│                                                              │
│  Compare skill against industry standards                    │
│  Calculate alignment score                                   │
└─────────────────────────────────────────────────────────────┘
                              │◄─────────────────┘
                    ┌─────────┴─────────┐
                    │    --vt flag?      │
                    └─────────┬─────────┘
                         YES  │  NO
                              │   └──────────────┐
                              ▼                  │
┌─────────────────────────────────────────────────────────────┐
│  PHASE 4: VIRTUAL TESTING (manual)                           │
│  └─ VT protocol:                                             │
│     ├─ 1. Generate 5-7 personas                              │
│     │   ├─ Novice                                            │
│     │   ├─ Expert                                            │
│     │   ├─ Skeptic                                           │
│     │   ├─ Integrator                                        │
│     │   └─ Breaker                                           │
│     │                                                        │
│     ├─ 2. Adversarial attacks (5+)                           │
│     │   ├─ Protocol skip                                     │
│     │   ├─ Context overflow                                  │
│     │   ├─ Conflicting instructions                          │
│     │   ├─ Edge case files                                   │
│     │   └─ Version mismatch                                  │
│     │                                                        │
│     └─ 3. Expert panel                                       │
│         ├─ User (25%)                                        │
│         ├─ Maintainer (20%)                                  │
│         ├─ Skeptic (25%)                                     │
│         ├─ Integrator (15%)                                  │
│         └─ Novice (15%)                                      │
└─────────────────────────────────────────────────────────────┘
                              │◄─────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  PHASE 5: REPORT GENERATION                                  │
│  └─ Consolidate all phases                                   │
│     ├─ Calculate scores                                      │
│     │   ├─ Quick mode: 60% structure + 40% genetics          │
│     │   └─ Full mode: weighted all phases                    │
│     │                                                        │
│     ├─ Determine verdict                                     │
│     │   ├─ 90-100: PROCEED                                   │
│     │   ├─ 70-89: REVIEW                                     │
│     │   ├─ 50-69: REWORK                                     │
│     │   └─ <50: BLOCK                                        │
│     │                                                        │
│     ├─ List hypotheses to validate                           │
│     └─ Recommend actions by priority                         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    OUTPUT                                    │
│  └─ skill-name-vX.Y.Z-FULL-AUDIT.md                         │
│     └─ Saved to /mnt/user-data/outputs/                     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    RETURN                                    │
│  └─ To previous state OR END                                │
└─────────────────────────────────────────────────────────────┘
```

---

## Scoring Logic

### Quick Mode (no flags)

```
Structure Score = (passed / total) × 100
Genetics Score = (inherited / total_genes) × 100

Quick Score = Structure × 0.6 + Genetics × 0.4
```

### Full Mode (--full)

```
Full Score = Structure × 0.20
           + Genetics × 0.20
           + Industry × 0.25
           + VT × 0.35
```

---

## Trigger Recognition

```
Input matching (case-insensitive):
├─ "чекап"
├─ "self-audit"
├─ "full-audit"
├─ "full audit"
├─ "diagnose"
├─ "проверь себя"
├─ "validate +full"
└─ "полный аудит"

Flag parsing:
├─ "+web" or "--web" → WEB_FLAG=true
├─ "+vt" or "--vt" → VT_FLAG=true
└─ "+full" or "--full" → WEB_FLAG=true, VT_FLAG=true
```

---

## Integration Points

```
P09 ←──────┬──────→ self-diagnostic.sh
           │
           ├──────→ genetic-audit.sh
           │
           ├──────→ web_search (Claude tool)
           │
           ├──────→ virtual-testing.md (protocol)
           │
           └──────→ context-management.md (if overflow)
```

---

*08-LOGIC-TREE v1.0.0 | skill-architect v8.1.0*
