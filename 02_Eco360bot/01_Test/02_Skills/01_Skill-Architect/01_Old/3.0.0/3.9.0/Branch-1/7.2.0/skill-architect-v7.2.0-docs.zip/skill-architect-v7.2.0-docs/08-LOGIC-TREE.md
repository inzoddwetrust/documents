# Logic Tree

Business logic flow for skill-architect.

---

## Main Flow

```
[START]
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│ P01: Activation                                         │
│ • Read clean-protocol dependency                        │
│ • Detect mode (Tool/Project)                           │
│ • Show Standard Activation Response                     │
└─────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│ P02: Config                                             │
│ • Gather purpose, triggers, constraints                 │
│ • Determine skill complexity                            │
└─────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│ P03: Planning ⛔                                        │
│ • Create planning document                              │
│ • Chat verification                                     │
│ • WAIT for explicit confirmation                        │
└─────────────────────────────────────────────────────────┘
    │ "да/yes/go/делай"
    ▼
┌─────────────────────────────────────────────────────────┐
│ P04: Build                                              │
│ • Create/update skill files                             │
│ • Follow NEVER DEGRADE rule                             │
└─────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│ P05: Validate                                           │
│ • Run validate-skill.sh                                 │
│ • Run validate-naming.sh                                │
│ • Optional: Virtual Testing (+vt)                       │
└─────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│ P06: Delivery — Skill ⛔                                │
│ • Package .skill                                        │
│ • Copy to /mnt/user-data/outputs/                      │
│ • Provide download link                                 │
└─────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────┐
│ P07: Scan                                               │
│ • Scan entire conversation                              │
│ • Categorize findings                                   │
│ • Report to user                                        │
│ • Ask: "Доки нужны?"                                   │
└─────────────────────────────────────────────────────────┘
    │
    ├── "skip/готово" ──────────────────────────► [END]
    │
    │ "да/yes/docs"
    ▼
┌─────────────────────────────────────────────────────────┐
│ P08: Docs + Closure ⛔                                  │
│ • Create 8 doc files (flat, numbered)                  │
│ • Run validate-docs.sh                                  │
│ • Package docs.zip                                      │
│ • Final delivery                                        │
└─────────────────────────────────────────────────────────┘
    │
    ▼
[END]
```

---

## Decision Points

### D1: Mode Detection (P01)
- "project" in request → Project Mode
- else → Tool Mode

### D2: Plan Confirmation (P03)
- "да/yes/go/делай" → P04
- Question → Stay P03, answer
- Change request → Update plan, re-confirm

### D3: Validation Result (P05)
- All pass → P06
- Fail → Fix, re-validate

### D4: Docs Needed (P07)
- "да/yes/docs" → P08
- "skip/готово" → END

---

## Blocking Points (⛔)

| Point | What | Why |
|-------|------|-----|
| P03 → P04 | Explicit "да/yes/go" | Prevent premature build |
| P06 → P07 | Skill delivered | Ensure user has artifact |
| P07 → P08 | Docs confirmed | Optional step |
| P08 | All 8 files | Complete documentation |

---

## Recovery

If state unclear:
1. Ask user: "Where were we?"
2. Check /home/claude/ for artifacts
3. Check /mnt/user-data/outputs/ for deliverables
4. Use Context Anchor to re-read skill

---

*08-LOGIC-TREE v1.0.0 | skill-architect v7.2.0*
