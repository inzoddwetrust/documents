# LOGIC-TREE: skill-architect v5.3.0

Пайплайн логики в формате numbered tree + mermaid визуализация.

---

## Numbered Tree (source of truth)

```
0. PRE-ACTIVATION (NEW in v5.1.0, extended v5.2.0)
   0.1. Загрузка Skill Dependencies:
      0.1.1. clean-protocol/SKILL.md (ALWAYS)
   0.2. Reference Reading по триггеру:
      0.2.1. "project" → reference/project-mode.md
      0.2.2. "create skill" → reference/templates.md
      0.2.3. "refactor" / "update" → reference/planning-document.md
      0.2.4. Packaging → reference/packaging.md
      0.2.5. "self-test" / "diagnose" → reference/self-diagnostic.md    ← NEW v5.2.0
      0.2.6. Output >10 lines prose → Check clean-protocol rules
   0.3. → 1.

1. ACTIVATION
   1.1. Триггер: "create skill", "create project", "import project", "refactor", "self-test"
   1.2. Загрузка: SKILL.md
   1.3. Init: token counter active
   1.4. → 2.

2. INIT (Quick Config)
   2.1. Проверка: purpose определён?
      2.1.1. НЕТ → Спросить: "Purpose? Triggers?"
      2.1.2. ДА → 2.2
   2.2. Определение MODE:
      2.2.1. "project" keyword → Project Mode
      2.2.2. Otherwise → Tool Mode
   2.3. Определение type: CREATE | UPDATE | REFACTOR | IMPORT | SELF-TEST   ← +SELF-TEST v5.2.0
   2.4. Определение complexity: simple | standard | complex
   2.5. → 3.

3. RESEARCH
   3.1. IF type=UPDATE|REFACTOR:
      3.1.1. Snapshot: cp -r source /home/claude/skill-ORIGINAL
      3.1.2. IF REFACTOR: bash scripts/audit-skill.sh
      3.1.3. Анализ текущего состояния
   3.2. IF type=CREATE:
      3.2.1. Исследование домена (web_search если нужно)
      3.2.2. IF Tool Mode: reference/templates.md
      3.2.3. IF Project Mode: reference/project-mode.md
   3.3. IF type=IMPORT:
      3.3.1. Загрузка: reference/project-import.md
      3.3.2. Анализ документа (Phase 1)
      3.3.3. Определение stage
   3.4. IF type=SELF-TEST:                              ← NEW v5.2.0
      3.4.1. Загрузка: reference/self-diagnostic.md
      3.4.2. Запуск: bash scripts/self-diagnostic.sh
      3.4.3. → END (no further steps)
   3.5. → 4.

4. DESIGN
   4.1. IF Tool Mode:
      4.1.1. Загрузка: reference/templates.md
      4.1.2. Выбор шаблона по ключевым словам purpose
      4.1.3. IF complex: выбор движков из reference/engines.md
   4.2. IF Project Mode:
      4.2.1. Определение stage (idea/mvp/growth/scale)
      4.2.2. Загрузка: reference/project-modules.md
      4.2.3. Определение required modules для stage
   4.3. → 5.

5. PLAN (BLOCKING)
   5.1. Загрузка: reference/planning-document.md
   5.2. Создание Planning Document:
      5.2.1. Контекст (источники, цели)
      5.2.2. Constraints таблица (copy from template)
      5.2.3. Секция KEEP (что сохраняем)
      5.2.4. Секция REMOVE (что удаляем + причины)
      5.2.5. Секция ADD (что добавляем)
   5.3. Chat Verification:
      5.3.1. Сканирование всего разговора
      5.3.2. Список обсуждённых пунктов
      5.3.3. Проверка против плана
      5.3.4. Отчёт: "Verified: N items. Missing: [list]"
   5.4. Ожидание подтверждения
   5.5. → 6.

6. CONFIRM (BLOCKING)
   6.1. Представление плана пользователю
   6.2. Проверка ответа:
      6.2.1. Валидный ("да", "yes", "делай", "go", "proceed") → 7.
      6.2.2. Невалидный ("ок", "понял") → Переспросить
      6.2.3. Запрос изменений → 5.2
   6.3. → 7.

7. PRE-BUILD CHECKPOINT
   7.1. Верификация:
      7.1.1. □ SKILL.md = English only
      7.1.2. □ README.md = User's language
      7.1.3. □ SKILL.md < 300 lines
      7.1.4. □ Frontmatter: name + description (version in description)
      7.1.5. □ Plan confirmed with explicit confirmation
      7.1.6. □ NEVER DEGRADE verified                    ← NEW v5.1.0
   7.2. IF любой пункт под вопросом → re-read SKILL.md
   7.3. → 8.

8. BUILD
   8.1. Создание структуры: mkdir /home/claude/skill-name/
   8.2. IF Tool Mode:
      8.2.1. Создание SKILL.md (English, <300 lines)
      8.2.2. Создание README.md (user language)
      8.2.3. Создание reference/ (если нужны)
      8.2.4. Создание scripts/ (если нужны)
   8.3. IF Project Mode:
      8.3.1. Создание SKILL.md (English, <300 lines)
      8.3.2. Создание README.md (user language)
      8.3.3. Создание data/ структуры
      8.3.4. Создание YAML модулей по stage
      8.3.5. IF IMPORT: заполнение из source document
   8.4. → 9.

9. VALIDATE
   9.1. Запуск: bash scripts/validate-skill.sh
   9.2. Запуск: bash scripts/validate-naming.sh
   9.3. Проверка результатов:
      9.3.1. PASS → 9.4
      9.3.2. FAIL → Исправить → 9.1
   9.4. Генерация: bash scripts/generate-manifest.sh
   9.5. → 10.

10. DIFF REPORT (BLOCKING)
    10.1. Создание Diff Report:
       10.1.1. Метрики до/после
       10.1.2. Добавленное
       10.1.3. Удалённое + причины
       10.1.4. Сохранённое
    10.2. Ожидание подтверждения
    10.3. → 11.

11. DELIVER SKILL (Step 1)
    11.1. Упаковка: zip -r skill-name-vX.Y.Z.skill skill-name/
    11.2. Проверка: unzip -l (структура)
    11.3. Копирование в /mnt/user-data/outputs/
    11.4. Ссылка пользователю
    11.5. Ожидание: explicit confirmation → 12.

12. DELIVER DOCS (Step 2)                               ← Phase 6 in workflow v5.3.0
    12.1. Создание docs/:
       12.1.1. vX.Y.Z-PLAN.md
       12.1.2. vX.Y.Z-DIFF.md
       12.1.3. CHANGELOG.md (append)
       12.1.4. BACKLOG.md (update)
       12.1.5. README.md (full docs RU)
       12.1.6. LOGIC-TREE.md (if changed)
       12.1.7. decisions/vX.Y.Z-decisions.md
       12.1.8. development-guide.md (if relevant)
    12.2. Упаковка: zip -r skill-name-vX.Y.Z-docs.zip docs/
    12.3. Ссылка пользователю
    12.4. Ожидание: explicit confirmation → 13.

13. FINAL SCAN (Step 3)
    13.1. Полный скан чата
    13.2. Сверка: обсуждали vs сделали
    13.3. IF упущено:
       13.3.1. Добавить в BACKLOG
       13.3.2. Перепаковать docs.zip
    13.4. Отчёт пользователю
    13.5. → END

14. PER-RESPONSE (на каждом ответе)
    14.1. Token counter в конце: 🟡 -[cost] | ~[remaining] 🟢
```

---

## Mermaid (визуализация)

```mermaid
flowchart TD
    Z[0. PRE-ACTIVATION] --> A
    A[1. ACTIVATION] --> B[2. INIT]
    B --> |unclear| B1[Ask: Purpose?]
    B1 --> B
    B --> |clear| B2{Mode?}
    
    B2 --> |Tool| C1[3. RESEARCH Tool]
    B2 --> |Project| C2[3. RESEARCH Project]
    B2 --> |Self-Test| ST[3.4 SELF-TEST]
    ST --> END2((END))
    
    C1 --> D1[4. DESIGN Tool]
    C2 --> D2[4. DESIGN Project]
    
    D1 --> E[5. PLAN]
    D2 --> E
    
    E --> F{6. CONFIRM}
    F --> |invalid| F1[Ask Again]
    F1 --> F
    F --> |changes| E
    F --> |confirmed| G[7. PRE-BUILD CHECK]
    
    G --> |verify failed| G1[Re-read]
    G1 --> G
    G --> |verified| H{8. BUILD}
    
    H --> |Tool| H1[reference/]
    H --> |Project| H2[data/]
    
    H1 --> I[9. VALIDATE]
    H2 --> I
    
    I --> |fail| I1[Fix]
    I1 --> I
    I --> |pass| J[10. DIFF REPORT]
    
    J --> K{11. SKILL}
    K --> |confirm| L{12. DOCS}
    L --> |confirm| M[13. SCAN]
    M --> |missing| M1[BACKLOG]
    M1 --> M2[Repack]
    M2 --> N((END))
    M --> |complete| N
```

---

## Mode Detection

```
User Input Analysis:
├── Contains "project" → Project Mode
│   ├── "create project: X" → CREATE
│   ├── "import project" → IMPORT
│   └── "update module" → UPDATE (inside project)
├── "self-test" / "diagnose" → SELF-TEST        ← NEW v5.2.0
└── Otherwise → Tool Mode
    ├── "create skill: X" → CREATE
    ├── "update: X" → UPDATE
    └── "refactor" → REFACTOR
```

---

## 3-Step Delivery

```
┌─────────────────────────────────────────────────────┐
│  STEP 1: SKILL                                      │
│  → Package .skill → Link → Wait explicit confirm    │
├─────────────────────────────────────────────────────┤
│  STEP 2: DOCS                                       │
│  → Package docs.zip → Link → Wait explicit confirm  │
├─────────────────────────────────────────────────────┤
│  STEP 3: FINAL SCAN                                 │
│  → Scan chat → Compare → BACKLOG → Repack if needed │
└─────────────────────────────────────────────────────┘
```

---

## Diff History

### v5.0.0 → v5.1.0

**Added:**
- Step 0: PRE-ACTIVATION (Skill Dependencies, Reference Reading)
- 7.1.6: NEVER DEGRADE verified

**Changed:**
- 1.1: +triggers for reference reading

### v5.1.0 → v5.2.0

**Added:**
- 0.2.5: self-test/diagnose trigger
- 2.3: SELF-TEST type
- 3.4: SELF-TEST flow (→ END)
- Mode Detection: self-test branch

### v5.2.0 → v5.3.0

**Added:**
- reference/docs-packaging.md (Phase 6 instructions)
- workflow.md Phase 6: DOCS

**Fixed:**
- Version sync in 13 files
- Footers in packaging.md, planning-document.md

---

*LOGIC-TREE v1.3.0 | skill-architect v5.3.0 | 2025-12-02*
