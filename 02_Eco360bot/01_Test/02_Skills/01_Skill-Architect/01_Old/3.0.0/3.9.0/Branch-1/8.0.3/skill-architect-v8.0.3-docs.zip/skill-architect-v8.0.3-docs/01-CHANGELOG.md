# Changelog

## skill-architect

---

### v8.0.3 (2025-12-08)
- Changed: P07-scan + P08-docs-closure → P07-closure (merged)
- Added: P08-simulation — optional virtual testing
- Fixed: Broken refs in P06 (P07-delivery-docs, P08-scan)
- Fixed: Version sync — all 29 files now v8.0.3
- Updated: P00-router flow for new protocol structure

### v8.0.2 (2025-12-08)
- Added: Purpose block (serves/goal/method/success) to SKILL.md
- Added: Mandatory Purpose block requirement in templates.md
- Added: Purpose Check in P05-validate.md Layer 1
- Added: Purpose in quality-checklist.md Critical section
- Changed: Context Anchor → one-line format `⚙️ skill · state · status`
- Changed: P01-activation menu synced with SKILL.md commands
- Added: Code-to-artifact rule (>3 lines → artifact only)
- Fixed: Version sync — 7 files were stuck on v8.0.0

### v8.0.1 (2025-12-07)
- Fixed: Token counter format `~[cost]` → `~[used]` (15 locations)
- Fixed: Token counter order consistency across all files
- Fixed: Broken link `test-levels.md` → `testing-framework.md`
- Fixed: Version sync — all footers now v8.0.1
- Fixed: Bug in ssot-check.sh integer parsing
- Updated: README.md version history

### v8.0.0 (2025-12-07)
- Initial release with Protocol-First architecture
- 9 protocols (P00-P08)
- Tool Mode + Project Mode
- Testing framework (L1-L6)
- Virtual Testing protocol

---

*01-CHANGELOG v1.0.0 | skill-architect v8.0.3*
