# Architectural Decisions

## skill-architect v8.0.1

---

## ADR-001: Token Counter Format Standardization

**Status:** Accepted

**Context:**
Self-audit revealed 3 different token counter formats across files:
1. `🟡 -[cost] | ~[remaining] 🟢` (templates, workflow, README)
2. `🟢 ~[remaining] | ~[cost] 🟡` (SKILL.md, Context Anchor)
3. `🟢 ~195k | ~1k 🟡` (examples with actual numbers)

Only format #3 was correct. This inconsistency propagates to all child skills through templates.md.

**Decision:**
Standardize on: `🟢 ~[remaining] | ~[used] 🟡`

- `~[remaining]` — tokens remaining (first)
- `~[used]` — tokens used (second, not "cost")
- No words, no dollars
- Green/yellow for healthy (>100k remaining)
- Yellow/red for caution (<100k remaining)

**Consequences:**
- All 15 occurrences updated
- Child skills will inherit correct format
- Breaking change for existing skills using old format (they should be regenerated)

---

## ADR-002: test-levels.md Elimination

**Status:** Accepted

**Context:**
P05-validate.md and README.md referenced `test-levels.md` which doesn't exist. Content was merged into `testing-framework.md` in v8.0.0.

**Decision:**
Update all references to point to `testing-framework.md` instead of creating the missing file.

**Consequences:**
- 3 broken links fixed
- No new files created (follows consolidation principle)

---

## ADR-003: Version Sync Strategy

**Status:** Accepted

**Context:**
Found version mismatch:
- SKILL.md: v8.0.0
- README.md: v7.1.0
- 18 footers: v7.2.0

**Decision:**
All files use footer format: `*filename vX.Y.Z | skill-architect vX.Y.Z*`

On version bump:
1. Update SKILL.md frontmatter + header + footer
2. Update README.md header + changelog
3. Mass-update all footers with sed
4. Update MANIFEST.md

**Consequences:**
- Single source of version truth in SKILL.md description
- Footers are derivative (can be mass-updated)
- MANIFEST.md tracks version in header

---

## ADR-004: Size/Structure Limits Not Enforced

**Status:** Accepted

**Context:**
Audit flagged:
- Size 217KB (>100KB guideline)
- 6 files >300 lines

Previous session decision: these are OK if modular structure exists.

**Decision:**
Explicitly NOT fixing these. Rules in quality-checklist.md state:
- >300 lines OK if has `##` modular structure
- Size limit is guideline, not hard rule

**Consequences:**
- No unnecessary refactoring
- Respects NEVER DEGRADE principle
- Files remain intact

---

## ADR-005: ssot-check.sh Bug Fix Approach

**Status:** Accepted

**Context:**
Script threw "integer expression expected" errors due to grep output handling.

**Decision:**
Fix with defensive parsing:
```bash
COUNT=$(grep -c "$pattern" "$SKILL_FILE" 2>/dev/null | head -1)
COUNT=${COUNT:-0}
COUNT=$((COUNT + 0))  # Force numeric
```

**Consequences:**
- Script now handles edge cases
- No false positives in validation

---

*04-DECISIONS v1.0.0 | skill-architect v8.0.1*
