# DECISIONS: skill-architect v8.2.1

Architectural Decision Records (ADR) for this version.

---

## ADR-001: Version Bump Strategy

**Date:** 2025-12-12
**Status:** Accepted

### Context
9 files had outdated footer v8.0.3 while SKILL.md declared v8.2.0. Two options:
1. Update files to v8.2.0
2. Bump to v8.2.1 as fix release

### Decision
Bump to **v8.2.1** (patch release).

### Rationale
- v8.2.0 was "released" with broken footers
- Patch version signals "fix only, no new features"
- Clear audit trail in changelog

### Consequences
- All files now v8.2.1
- Clean version history
- Extra version number in changelog

---

## ADR-002: Protocol-First as Inheritable Gene

**Date:** 2025-12-12
**Status:** Accepted

### Context
genetic-audit.sh detected `protocol_first` gene in parent (has protocols/) but child skills weren't required to document it.

### Decision
Add explicit **Protocol-First (MANDATORY)** section to templates.md.

### Rationale
- Critical workflow rule must be inherited
- "Read protocol before act" prevents drift
- Without documentation, gene is "lost" in children

### Consequences
- Child skills must include FIRST STEP section
- genetic-audit.sh now checks for it
- +20 lines in templates.md

---

## ADR-003: genetic-audit.sh Enhancement

**Date:** 2025-12-12
**Status:** Accepted

### Context
Script checked 8 parent genes but only 5 child requirements. Gap in protocol_first detection.

### Decision
Add **Req 9** to check for Protocol-First documentation.

### Rationale
- Script should validate what it requires
- "Eat your own dog food" principle
- Self-audit must pass

### Consequences
- +7 lines in genetic-audit.sh
- Child requirements: 5 → 6
- Inheritance ratio improved

---

## ADR-004: Keep SSOT Warnings

**Date:** 2025-12-12
**Status:** Accepted

### Context
ssot-check.sh reported 2 warnings:
- `bash scripts/` mentioned 26 times (11 without SSOT note)
- Repeated section headers (## Output, ## Trigger, etc.)

### Decision
**Accept warnings**, do not fix.

### Rationale
- `bash scripts/` repetition is intentional (different contexts)
- Section headers are structural (protocols must have Output, Trigger)
- Fixing would harm readability

### Consequences
- Warnings remain in scan reports
- Documented as acceptable

---

## ADR-005: No Merge of testing-framework.md

**Date:** 2025-12-12
**Status:** Deferred

### Context
testing-framework.md overlaps with quality-checklist.md on L1-L6 definitions.

### Decision
**Defer** to future version.

### Rationale
- testing-framework.md focuses on automation
- quality-checklist.md focuses on manual review
- Merge requires careful restructuring

### Consequences
- Minor redundancy remains (~8%)
- Added to backlog for v8.3.0

---

## Decision Summary

| ADR | Decision | Impact |
|-----|----------|--------|
| 001 | Bump to v8.2.1 | Version clarity |
| 002 | Protocol-First mandatory | Inheritance |
| 003 | Add Req 9 | Self-consistency |
| 004 | Keep SSOT warnings | Readability |
| 005 | Defer merge | Future work |

---

*04-DECISIONS.md v1.0.0 | skill-architect v8.2.1*
