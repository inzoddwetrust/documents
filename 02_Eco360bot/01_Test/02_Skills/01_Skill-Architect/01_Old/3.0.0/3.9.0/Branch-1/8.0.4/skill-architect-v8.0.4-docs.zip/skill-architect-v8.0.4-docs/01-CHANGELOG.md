# Changelog

## skill-architect

---

### v8.0.4 (2025-12-12)

**Added:**
- ⛔ Protocol First, Always — anti-skip rules
- Iteration Principles section
- Gradient Feedback rule (one step → verify → next)
- Single Component Rule (don't change >1 per iteration)
- Context Regularization (one protocol/file at a time)

**Source:** Research on neural network / autistic cognition parallels

---

### v8.0.3 (2025-12-08)

**Changed:**
- P07-scan + P08-docs-closure → P07-closure (merged)

**Added:**
- P08-simulation — optional virtual testing

**Fixed:**
- Broken refs in P06
- Version sync — all 29 files now v8.0.3

---

### v8.0.2 (2025-12-08)

**Added:**
- Purpose block (serves/goal/method/success)
- Mandatory Purpose block requirement
- Purpose Check in P05-validate.md Layer 1
- Code-to-artifact rule (>3 lines → artifact only)

**Changed:**
- Context Anchor → one-line format

---

### v8.0.1 (2025-12-07)

**Fixed:**
- Token counter format consistency
- Broken link test-levels.md → testing-framework.md
- Version sync across all files

---

### v8.0.0 (2025-12-07)

- Initial release

---

*01-CHANGELOG.md v1.0.0 | skill-architect v8.0.4*
