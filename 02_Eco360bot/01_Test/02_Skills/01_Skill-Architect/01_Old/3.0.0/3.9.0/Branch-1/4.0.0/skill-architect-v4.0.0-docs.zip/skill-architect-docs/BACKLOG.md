# Backlog: skill-architect

Идеи, эксперименты, хотелки для будущих версий.

**Обновлено:** 2025-11-30 (после Final Scan)  
**Версия скилла:** 4.0.0

---

## 🔴 High Priority (v4.1.0)

### B-001: Обновить clean-protocol для композиции
**Источник:** v5.0.0 planning  
**Суть:** Добавить в clean-protocol поддержку `@requires` чтобы скиллы могли его наследовать без дублирования Clean Skill Principles.  
**Блокирует:** Полноценное использование @requires в skill-architect

### B-002: Добавить evaluations.md
**Источник:** ADDENDUM (Anthropic best practices)  
**Суть:** Создать `reference/evaluations.md` с 3+ тестовыми сценариями:
- Create skill from scratch
- Update existing skill
- Refactor complex skill

**Ценность:** Anthropic официально рекомендует evaluation-first development

### B-003: 3-Step Delivery Protocol в SKILL.md
**Источник:** Чат 2025-11-30 (Final Scan)  
**Суть:** Добавить в SKILL.md секцию:
```
## Delivery Protocol

Step 1: SKILL → package → link → wait "да"
Step 2: DOCS → package → link → wait "да"  
Step 3: FINAL SCAN → chat scan → BACKLOG update → repack docs
```
**Ценность:** Позволяет итерировать docs без пересборки skill

### B-004: Final Chat Scan в SKILL.md
**Источник:** Чат 2025-11-30  
**Суть:** Формализовать как обязательный шаг после delivery:
1. Скан всего чата
2. Сверка: обсуждали vs сделали
3. Упущенное → BACKLOG
4. Перепаковка docs.zip

**Ценность:** Ловит упущенное, замыкает цикл разработки

---

## 🟡 Medium Priority (v4.2.0)

### B-005: development-guide.md
**Источник:** v5.0.0 план, Final Scan  
**Суть:** Создать `docs/development-guide.md`:
- Как развивать skill-architect
- Evaluation-driven development
- Когда делать MAJOR/MINOR/PATCH
- Как работать с BACKLOG

### B-006: Claude A/B development pattern
**Источник:** ADDENDUM (Anthropic best practices)  
**Суть:** Документировать паттерн:
- Claude A: создаёт/улучшает скилл
- Claude B: тестирует на реальных задачах
- Iterate based on observations

### B-007: JSON schema для конфигов
**Источник:** v5.0.0 planning (Anthropic "degrees of freedom")  
**Суть:** Добавить JSON schema как "medium freedom" вариант.  
**Пример:** `skill-config.schema.json` для валидации структуры

### B-008: Git integration для Diff Report
**Источник:** v5.0.0 planning  
**Суть:** Использовать `git diff` для автоматической генерации.  
**Блокирует:** Нужен git в рабочей среде

### B-009: init-docs.sh скрипт
**Источник:** v5.0.0 план, Final Scan  
**Суть:** Скрипт создания docs структуры:
```bash
mkdir -p skill-name-docs/decisions
touch skill-name-docs/{CHANGELOG,BACKLOG,README,LOGIC-TREE}.md
```

---

## 🟢 Low Priority (future)

### B-010: VERSION-ANALYSIS.md после 5 версий
**Источник:** v5.0.0 docs structure  
**Суть:** Ретроспективный анализ:
- Какие практики выжили
- Какие были убраны
- Паттерны по моделям (Opus vs Sonnet)

**Когда:** После v4.2.0

### B-011: Skill dependency graph
**Источник:** Обсуждение 2025-11-30  
**Суть:** Визуализация зависимостей (@requires tree)  
**Формат:** Mermaid diagram

### B-012: Auto-migration tool
**Источник:** v5.0.0 lessons  
**Суть:** Скрипт миграции старых скиллов:
- Добавление @requires
- Обновление frontmatter
- Генерация docs

### B-013: Переименование в gerund form
**Источник:** ADDENDUM (Anthropic naming convention)  
**Суть:** `skill-architect` → `architecting-skills`  
**Статус:** Cosmetic, breaking change

---

## ✅ Done (реализовано в v4.0.0)

### D-001: LOGIC-TREE.md
**Источник:** v5.0.0, Final Scan  
**Было в Rejected:** "Overkill для 200-строчного скилла"  
**Решение:** Добавлен в docs (не runtime) — правильное место  
**Реализовано:** 2025-11-30, docs v4.0.0

### D-002: decisions/v4.0.0-decisions.md
**Источник:** v5.0.0 структура  
**Реализовано:** 2025-11-30, docs v4.0.0

---

## ❌ Rejected (не будем делать)

### R-001: modules/state-machine.md
**Источник:** v5.0.0  
**Причина:** Over-engineering. Claude помнит контекст.  
**Альтернатива:** LOGIC-TREE.md в docs

### R-002: modules/question-protocol.md
**Источник:** v5.0.0  
**Причина:** Базовая способность Claude.

### R-003: AI-теги `<!-- @phase:X -->`
**Источник:** v5.0.0  
**Причина:** Claude их не использует реально.

### R-004: Разбиение engines.md на 5 файлов
**Источник:** v5.0.0  
**Причина:** 1 файл проще поддерживать.

---

## 📝 Patches (накопленные мелочи)

### P-001: Document naming convention
**Источник:** skill-architect-PATCH-v5.0.1.md  
**Суть:** Добавить в docs:
```
Versioned: {skill}-v{X.Y.Z}-PLAN.md, {skill}-v{X.Y.Z}-DIFF.md
Current: CHANGELOG.md, BACKLOG.md, README.md
```

---

## Процесс работы с backlog

```
1. DISCOVER  → Идея в чате/эксплуатации
2. ADD       → В соответствующую секцию с источником
3. PRIORITIZE → High/Medium/Low по value/effort
4. PLAN      → При планировании версии: review backlog
5. IMPLEMENT → Реализовать, перенести в Done
6. REJECT    → Если решили НЕ делать: в Rejected с причиной
```

---

*Backlog v1.1.0 | skill-architect v4.0.0 | Updated: 2025-11-30 (Final Scan)*
