# Skill Architect v4.0.0

Профессиональная система создания, обновления и валидации скиллов для Claude.

---

## Обзор

Skill Architect — это мета-скилл для создания других скиллов. Обеспечивает:

- **Качество** — валидация, аудит, чеклисты
- **Целостность** — MANIFEST tracking, версионирование
- **Процесс** — Planning Document, Chat Verification, Diff Report
- **Документация** — формализованный цикл версионирования

---

## Что нового в v4.0.0

### Breaking Changes
- **Mandatory Token Counter** — обязательный счётчик в каждом ответе
- **No Ceremony** — сразу в работу без "Skill Architect ready"
- **Unified Workflow** — один процесс для CREATE/UPDATE/REFACTOR
- **Docs Separate** — версионные документы отдельно от .skill

### Новые фичи
- **Quick Start** — мгновенный онбординг
- **Single Responsibility** — один скилл = одна задача
- **Output Separation** — runtime vs docs
- **Evaluation Mindset** — Anthropic best practice
- **Docs Workflow** — цикл версионирования

---

## Быстрый старт

### Создать новый скилл
```
create skill: [назначение и триггеры]
```

### Обновить существующий
```
[прикрепить .skill файл] + "update: [что изменить]"
```

### Рефакторинг
```
[прикрепить .skill файл] + "refactor"
```

---

## Триггеры

| Язык | Триггеры |
|------|----------|
| English | create skill, build skill, architect skill, refactor skill |
| Русский | создай скилл, обнови скилл |

---

## Процесс работы

### Unified Workflow

| Шаг | CREATE | UPDATE | REFACTOR |
|-----|--------|--------|----------|
| 1. Snapshot | — | Copy | Copy + audit |
| 2. Analyze | — | Light | Deep |
| 3. Plan | Doc | Doc | Doc |
| 4. Confirm | Wait | Wait | Wait |
| 5. Build | Create | Edit | Rebuild |
| 6. Validate | Scripts | Scripts | Scripts |
| 7. Report | Diff | Diff | Diff |
| 8. Package | Zip | Zip | Zip |

### Planning Document

Перед любыми изменениями создаётся план:

```markdown
### KEEP
- Feature X (работает)

### REMOVE
- Feature Y (не используется) — причина

### ADD
- Feature Z (новое)
```

**Chat Verification:** Сканирование всего чата, проверка что ничего не упущено.

### Diff Report

После реализации — отчёт о изменениях:
- Метрики до/после
- Что добавлено/удалено/сохранено
- Отклонения от плана

---

## Структура выхода

### Runtime (.skill файл)

```
skill-name/
├── SKILL.md      # Инструкции (< 300 строк, English)
├── README.md     # Документация (язык пользователя)
├── MANIFEST.md   # Целостность (если есть reference/)
├── reference/    # Справочные материалы
└── scripts/      # Автоматизация
```

### Docs (отдельный .zip)

```
skill-name-vX.Y.Z-docs/
├── vX.Y.Z-PLAN.md    # План этого обновления
├── vX.Y.Z-DIFF.md    # Сравнение с предыдущей версией
├── CHANGELOG.md      # История всех версий
├── BACKLOG.md        # Идеи на будущее
└── README.md         # Полная документация
```

---

## Цикл разработки

```
┌─────────────────────────────────────────┐
│                                         │
│  Эксплуатация → Patches (баги, идеи)   │
│       ↓                                 │
│  PLAN (docs + patches + backlog)        │
│       ↓                                 │
│  BUILD (.skill) → VALIDATE              │
│       ↓                                 │
│  DOCS (DIFF, CHANGELOG, BACKLOG)        │
│       ↓                                 │
│  Repeat                                 │
│                                         │
└─────────────────────────────────────────┘
```

---

## Core Rules

### Single Responsibility
Один скилл = одна задача. Если можно разделить на два независимых скилла — разделяй.

### Evaluation Mindset
Перед созданием спроси:
1. Что не работает без этого скилла?
2. Могу ли создать 3 тестовых сценария?
3. Оправдывает ли каждая секция свою стоимость в токенах?

### Token Counter
Каждый ответ MUST заканчиваться:
```
🟡 -[cost] | ~[remaining] 🟢
```

---

## Правила подтверждения

### Валидные фразы
- `да`, `yes`, `делай`, `go`, `proceed`, `начинай`, `подтверждаю`
- Acknowledgment + глагол: `ок делай`, `хорошо начинай`

### Невалидные (переспросить)
- `ок`, `хорошо`, `понял`, `ясно` — нет глагола действия

---

## Файлы скилла

| Файл | Назначение |
|------|------------|
| `SKILL.md` | Главные инструкции |
| `README.md` | Документация для пользователя |
| `MANIFEST.md` | Tracking целостности |
| `reference/planning-document.md` | Шаблон плана |
| `reference/templates.md` | Шаблоны скиллов |
| `reference/engines.md` | Движки качества (INoT, Validation) |
| `reference/packaging.md` | Правила упаковки |
| `reference/quality-checklist.md` | Чеклист качества |
| `reference/workflow.md` | Детали процесса |
| `scripts/validate-skill.sh` | Валидация |
| `scripts/audit-skill.sh` | Глубокий аудит |
| `scripts/generate-manifest.sh` | Генерация MANIFEST |

---

## Версионирование (SemVer)

| Тип | Когда |
|-----|-------|
| **MAJOR** | Breaking changes, полная переработка |
| **MINOR** | Новые фичи, секции |
| **PATCH** | Баг фиксы, опечатки |

---

## История версий

| Версия | Дата | Кодовое имя |
|--------|------|-------------|
| 4.0.0 | 2025-11-30 | Unified + Docs |
| 3.9.0 | 2025-11-29 | Clean + MANIFEST |
| 3.8.0 | 2025-11 | Planning Document First |

Подробности: см. `CHANGELOG.md`

---

## Контакты и поддержка

Skill создан для личного использования. Для обновлений используй сам skill-architect:

```
[прикрепить skill-architect-vX.Y.Z.skill] + "обнови: [что изменить]"
```

---

*Skill Architect v4.0.0 | 2025-11-30*
