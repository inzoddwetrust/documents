# DIFF Report: v8.0.0 → v8.0.1

## Summary

| Metric | Value |
|--------|-------|
| Files changed | 22 |
| Lines changed | ~50 |
| Type | Bugfix |

---

## Changes by Category

### 🔴 Critical (Fixed)

| File | Line(s) | Before | After |
|------|---------|--------|-------|
| SKILL.md | 3 | v8.0.0 | v8.0.1 |
| SKILL.md | 6 | v8.0.0 | v8.0.1 |
| SKILL.md | 62-63 | `~[cost]` | `~[used]` |
| SKILL.md | 183 | v8.0.0 | v8.0.1 |
| templates.md | 52 | `🟡 -[cost] \| ~[remaining] 🟢` | `🟢 ~[remaining] \| ~[used] 🟡` |
| templates.md | 86-87 | `~[cost]` | `~[used]` |
| templates.md | 114-115 | `~[cost]` | `~[used]` |
| templates.md | 159,190,221,252,283 | wrong order | `🟢 ~[remaining] \| ~[used] 🟡` |
| P05-validate.md | 41 | `test-levels.md` | `testing-framework.md` |
| P05-validate.md | 107 | `test-levels.md` | `testing-framework.md` |

### 🟠 High (Fixed)

| File | Change |
|------|--------|
| README.md | v7.1.0 → v8.0.1, added v8.0.1 changelog section |
| README.md | line 115: `test-levels.md` → `testing-framework.md` |
| P01-activation.md | line 36: example version v7.2.0 → v8.0.1 |
| P01-activation.md | line 45: `~[cost]` → `~[used]` |
| workflow.md | line 117: token counter format fixed |
| 21 files | footer: `skill-architect v7.2.0` → `skill-architect v8.0.1` |

### 🟡 Medium (Fixed)

| File | Line(s) | Change |
|------|---------|--------|
| ssot-check.sh | 51-55 | Fixed integer parsing bug |

---

## Files Changed

```
SKILL.md
README.md
MANIFEST.md
reference/templates.md
reference/workflow.md
reference/protocols/P00-router.md
reference/protocols/P01-activation.md
reference/protocols/P02-config.md
reference/protocols/P03-planning.md
reference/protocols/P04-build.md
reference/protocols/P05-validate.md
reference/protocols/P06-delivery-skill.md
reference/protocols/P07-scan.md
reference/protocols/P08-docs-closure.md
reference/commands.md
reference/docs-packaging.md
reference/engines.md
reference/genetic-audit.md
reference/naming-convention.md
reference/packaging.md
reference/planning-document.md
reference/project-filters.md
reference/project-import.md
reference/project-mode.md
reference/project-modules.md
reference/quality-checklist.md
reference/self-diagnostic.md
reference/ssot-check.md
reference/testing-framework.md
reference/virtual-testing.md
scripts/ssot-check.sh
```

---

## Validation Results

| Script | Result |
|--------|--------|
| validate-skill.sh | ✅ PASS |
| validate-naming.sh | ✅ PASS |
| ssot-check.sh | ✅ PASS |

---

*02-DIFF v1.0.0 | skill-architect v8.0.1*
