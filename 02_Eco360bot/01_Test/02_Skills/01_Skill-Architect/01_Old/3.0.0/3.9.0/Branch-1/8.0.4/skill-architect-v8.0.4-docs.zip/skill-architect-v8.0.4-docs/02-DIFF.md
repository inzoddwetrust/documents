# Diff Report: v8.0.3 → v8.0.4

---

## Metrics

| Metric | v8.0.3 | v8.0.4 | Δ |
|--------|--------|--------|---|
| SKILL.md lines | 200 | 238 | +38 |
| Total files | 39 | 39 | 0 |

---

## Added

### New Section: ⛔ Protocol First, Always

```markdown
**Every response:**
1. Where am I? → P00-router
2. Which protocol? → file_read it
3. What to do? → Steps from protocol
4. Do ONLY what protocol says

**Forbidden:**
- "I know what to do" → NO, read protocol
- "Faster to show result" → NO, follow process
- "Simple change" → NO, plan required
- Skipping file_read → BLOCKER

**Following = Work. No following = no work.**
```

### New Section: Iteration Principles

```markdown
### Gradient Feedback
1. One small step → verify result
2. Success? → continue. Fail? → rollback + analyze
3. Explicit checkpoint after each change

### Single Component Rule
- Don't change >1 component per iteration
- Changed SKILL.md? → verify → then README
- Violation → can't determine error cause

### Context Regularization
- One protocol at a time
- One file in focus when editing
- Complete current step → confirm → next
```

---

## Changed

| File | Change |
|------|--------|
| SKILL.md | +38 lines, 2 new sections |
| MANIFEST.md | Version bump, changelog entry |

---

## Preserved

- Purpose section
- ⛔ NEVER DEGRADE
- ⛔ FIRST STEP
- ⛔ BEFORE EVERY RESPONSE
- Context Anchor
- Protocol Router
- Quick Start
- Output table
- Modes
- Resources (all 39 files)

---

## Validation

| Validator | Status |
|-----------|--------|
| validate-skill.sh | ✅ PASSED |
| validate-naming.sh | ✅ PASSED |
| ssot-check.sh | ✅ OK (2 warnings) |

---

*02-DIFF.md v1.0.0 | skill-architect v8.0.4*
