# BACKLOG: skill-architect

Current and future work items.

---

## ✅ Completed in v8.3.0

| ID | Item | Status |
|----|------|--------|
| B-006 | Version sync check in validate-skill.sh | ✅ Done (L8) |
| B-007 | Footer update automation | ✅ Done (update-version.sh) |
| B-017 | Project Mode evaluations | ✅ Done (E-006, E-007, E-008) |
| R-001 | Restore active prompting | ✅ Done (P01, P02) |
| R-002 | Restore Diff Report format | ✅ Done (diff-report.md) |
| R-003 | Consolidate Critical Rules | ✅ Done (SKILL.md) |

---

## 🔜 Planned for v8.4.0

| ID | Item | Priority | Effort |
|----|------|----------|--------|
| B-008 | Blocking points gene validation | Medium | 2h |
| B-009 | Auto-CHANGELOG from commits | Low | 4h |
| B-010 | Skill dependency graph (mermaid) | Low | 3h |

---

## 📋 Future Ideas

| ID | Item | Notes |
|----|------|-------|
| B-100 | Multi-skill dependency management | v9.0.0 ecosystem |
| B-101 | Shared reference library | Common patterns extraction |
| B-102 | Real-time token counter integration | Platform-dependent |
| B-103 | Web UI for validation | Out of scope for CLI |

---

## 🐛 Known Issues

| ID | Issue | Workaround | Target |
|----|-------|------------|--------|
| I-001 | SSOT warnings for `bash scripts/` | Acceptable, documented | — |
| I-002 | Section header repetition in protocols | By design (modularity) | — |
| I-003 | genetic-audit.sh exit code 1 on partial | Check output, not code | v8.4.0 |

---

## 📊 Metrics

### v8.3.0 Release Stats

| Metric | Value |
|--------|-------|
| Files | 45 |
| Lines (md) | ~3,100 |
| Lines (sh) | ~2,000 |
| Total | ~5,100 |
| Size (.skill) | 59 KB |

### Quality Gates

| Gate | v8.2.2 | v8.3.0 |
|------|--------|--------|
| Structure (L1) | ✅ | ✅ |
| Content (L2) | ✅ | ✅ |
| Logic (L3) | ✅ | ✅ |
| Naming (L4) | ✅ | ✅ |
| Integration (L5) | ✅ | ✅ |
| Testing (L6) | ✅ | ✅ |
| Redundancy (L7) | ✅ | ✅ |
| Version Sync (L8) | — | ✅ NEW |

---

## 🎯 Version Roadmap

### v8.4.0 "Polish"
- [ ] I-003: Fix genetic-audit exit codes
- [ ] B-008: Blocking points validation
- [ ] Documentation improvements

### v9.0.0 "Ecosystem"
- [ ] Multi-skill dependency management
- [ ] Shared reference library
- [ ] Ecosystem-wide validation

---

*05-BACKLOG.md v1.0.0 | skill-architect v8.3.0*
