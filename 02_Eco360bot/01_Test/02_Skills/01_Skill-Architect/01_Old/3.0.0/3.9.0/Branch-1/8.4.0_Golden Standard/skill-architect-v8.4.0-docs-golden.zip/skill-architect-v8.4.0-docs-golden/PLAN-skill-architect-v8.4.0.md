# PLAN: skill-architect v8.3.0 → v8.4.0 "Golden Standard"

**Date:** 2025-12-12  
**Sources:** V1/V2 comparison, Claude Opus enhancement proposals

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | User's language |
| Confirmation | explicit "да/yes/go" |

---

## Problems Addressed

| ID | Problem | Source | Priority |
|----|---------|--------|----------|
| P-001 | Context drift after web search | Opus analysis | 🔴 |
| P-002 | No PRE-BUILD CHECKPOINT | Opus proposal | 🔴 |
| P-003 | Context Anchor без rule reminder | Opus proposal | 🔴 |
| P-004 | Blocking points визуально не выделены | Opus proposal | 🟡 |
| P-005 | No Common Mistakes section | Opus proposal | 🟡 |
| P-006 | No Self-Check in protocols | Opus proposal | 🟡 |
| P-007 | RETROSPECTIVE missing in V2 | V1 analysis | 🟡 |

---

## Changes

### Added

| File | What | Lines |
|------|------|-------|
| SKILL.md | `## ⛔ PRE-BUILD CHECKPOINT` | +12 |
| SKILL.md | `## ⚠️ Common Mistakes` | +10 |
| SKILL.md | Enhanced Context Anchor | +3 |
| reference/retrospective.md | Evolution history | +140 |
| P00-router.md | Enhanced Recovery | +30 |
| All P0X protocols | Self-Check section | +10 each |

### Changed

| File | Change |
|------|--------|
| Context Anchor | Added `📋 SKILL.md=EN \| README=[LANG] \| <300` |
| Blocking markers | `⛔` → `════ ⛔ BLOCKING ════` |
| evaluations.md | Added inline example for E-001 |

### Removed

Nothing. NEVER DEGRADE respected.

---

## Key Decisions

| Decision | Rationale |
|----------|-----------|
| Base = V2 | More complete (12 rules vs 8, L8, all 5 principles) |
| Add RETROSPECTIVE from V1 | Evolution context valuable |
| PRE-BUILD CHECKPOINT in SKILL.md | Must be visible, not buried in protocols |
| Rule reminder in Context Anchor | Every response reinforces rules |

---

## Chat Verification

| # | Topic | Status |
|---|-------|--------|
| 1 | V2 as base (12 rules) | ✅ |
| 2 | Add retrospective.md | ✅ |
| 3 | PRE-BUILD CHECKPOINT | ✅ |
| 4 | Enhanced Context Anchor | ✅ |
| 5 | Visual blocking markers | ✅ |
| 6 | Common Mistakes | ✅ |
| 7 | Enhanced Recovery | ✅ |
| 8 | Self-Check in protocols | ✅ |
| 9 | NEVER DEGRADE | ✅ |

---

## Risks

| Risk | Probability | Mitigation |
|------|-------------|------------|
| SKILL.md > 300 lines | Low | Current ~166, buffer exists |
| Context Anchor verbose | Medium | Can shorten if needed |

---

## Deliverables

| # | Deliverable | Format |
|---|-------------|--------|
| 1 | skill-architect-v8.4.0.skill | .skill archive |
| 2 | skill-architect-v8.4.0-docs.zip | docs archive |
| 3 | Diff Report | in docs |

---

**Confirmation required:** "да", "yes", "go"

---

*PLAN-skill-architect-v8.4.0.md | skill-architect v8.4.0*
