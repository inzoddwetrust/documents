#!/bin/bash
# Self-Diagnostic Script for skill-architect
# Usage: bash self-diagnostic.sh /path/to/skill-architect [/path/to/old-version]

set -e

SKILL_PATH="${1:-/mnt/skills/user/skill-architect}"
OLD_PATH="$2"

echo "╔══════════════════════════════════════════╗"
echo "║     SKILL-ARCHITECT SELF-DIAGNOSTIC      ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "Target: $SKILL_PATH"
echo "Date: $(date '+%Y-%m-%d %H:%M')"
echo ""

PASS=0
FAIL=0

check() {
  if [ "$1" = "true" ]; then
    echo "✅ $2"
    PASS=$((PASS + 1))
  else
    echo "❌ $2"
    FAIL=$((FAIL + 1))
  fi
}

# === STRUCTURE ===
echo "═══ STRUCTURE ═══"

SKILL_LINES=$(wc -l < "$SKILL_PATH/SKILL.md" 2>/dev/null || echo "0")
check "$([ "$SKILL_LINES" -lt 300 ] && echo true)" "SKILL.md: $SKILL_LINES lines (< 300)"

check "$(test -f "$SKILL_PATH/README.md" && echo true)" "README.md exists"
check "$(test -f "$SKILL_PATH/MANIFEST.md" && echo true)" "MANIFEST.md exists"

REF_COUNT=$(ls "$SKILL_PATH/reference/" 2>/dev/null | wc -l)
check "$([ "$REF_COUNT" -ge 10 ] && echo true)" "reference/: $REF_COUNT files (≥ 10)"

SCRIPT_COUNT=$(ls "$SKILL_PATH/scripts/" 2>/dev/null | wc -l)
check "$([ "$SCRIPT_COUNT" -ge 5 ] && echo true)" "scripts/: $SCRIPT_COUNT files (≥ 5)"

echo ""

# === CORE SECTIONS ===
echo "═══ CORE SECTIONS ═══"

SKILL="$SKILL_PATH/SKILL.md"

check "$(grep -q '## Activation' "$SKILL" && echo true)" "Activation"
check "$(grep -q '## Config' "$SKILL" && echo true)" "Config"
check "$(grep -q '## Clean Skill' "$SKILL" && echo true)" "Clean Skill Principles"
check "$(grep -q '## REFACTOR Protocol' "$SKILL" && echo true)" "REFACTOR Protocol"
check "$(grep -q '## UPDATE Protocol' "$SKILL" && echo true)" "UPDATE Protocol"
check "$(grep -q 'Diff Report' "$SKILL" && echo true)" "Diff Report"
check "$(grep -q '## Critical Rules' "$SKILL" && echo true)" "Critical Rules"
check "$(grep -q '## Versioning' "$SKILL" && echo true)" "Versioning"
check "$(grep -q '## Resources' "$SKILL" && echo true)" "Resources"

echo ""

# === PROTECTION SECTIONS ===
echo "═══ PROTECTION SECTIONS ═══"

check "$(grep -q 'NEVER DEGRADE' "$SKILL" && echo true)" "NEVER DEGRADE rule"
check "$(grep -q 'Reference Reading' "$SKILL" && echo true)" "Reference Reading trigger"
check "$(grep -q 'Context Tracking' "$SKILL" && echo true)" "Context Tracking"
check "$(grep -q 'PRE-BUILD CHECKPOINT' "$SKILL" && echo true)" "PRE-BUILD CHECKPOINT"

echo ""

# === MODE SUPPORT ===
echo "═══ MODE SUPPORT ═══"

check "$(grep -q '## Modes' "$SKILL" && echo true)" "Modes table"
check "$(grep -q 'Project Mode' "$SKILL" && echo true)" "Project Mode support"
check "$(grep -q 'Quick Start' "$SKILL" && echo true)" "Quick Start"

echo ""

# === PROTOCOL CONTENT ===
echo "═══ PROTOCOL CONTENT ═══"

REFACTOR_CONTENT=$(grep -A 15 "## REFACTOR Protocol" "$SKILL")
check "$(echo "$REFACTOR_CONTENT" | grep -q 'unzip' && echo true)" "REFACTOR: unzip command"
check "$(echo "$REFACTOR_CONTENT" | grep -q 'audit-skill.sh' && echo true)" "REFACTOR: audit-skill.sh"

UPDATE_CONTENT=$(grep -A 12 "## UPDATE Protocol" "$SKILL")
check "$(echo "$UPDATE_CONTENT" | grep -q 'Snapshot' && echo true)" "UPDATE: Snapshot step"
check "$(echo "$UPDATE_CONTENT" | grep -q 'cp -r' && echo true)" "UPDATE: cp -r command"

DIFF_CONTENT=$(grep -A 15 "Diff Report" "$SKILL")
check "$(echo "$DIFF_CONTENT" | grep -q 'Deviation' && echo true)" "Diff Report: Deviation from plan"

echo ""

# === SCRIPTS ===
echo "═══ SCRIPTS ═══"

check "$(test -f "$SKILL_PATH/scripts/audit-skill.sh" && echo true)" "audit-skill.sh"
check "$(test -f "$SKILL_PATH/scripts/audit-project.sh" && echo true)" "audit-project.sh"
check "$(test -f "$SKILL_PATH/scripts/validate-skill.sh" && echo true)" "validate-skill.sh"
check "$(test -f "$SKILL_PATH/scripts/validate-naming.sh" && echo true)" "validate-naming.sh"
check "$(test -f "$SKILL_PATH/scripts/generate-manifest.sh" && echo true)" "generate-manifest.sh"

echo ""

# === REGRESSION (if old version provided) ===
if [ -n "$OLD_PATH" ] && [ -d "$OLD_PATH" ]; then
  echo "═══ REGRESSION vs $OLD_PATH ═══"
  
  # Extract real sections (not examples in code blocks)
  # Also normalize by removing emoji prefixes and MANDATORY
  OLD_SECTIONS=$(grep "^## " "$OLD_PATH/SKILL.md" 2>/dev/null | \
    grep -v "skill-name\|vX.Y.Z\|Changelog\|Integrity" | \
    sed 's/## ⚠️ MANDATORY: /## /g; s/## ⚠️ /## /g; s/## ⛔ /## /g' | sort)
  NEW_SECTIONS=$(grep "^## " "$SKILL" | \
    sed 's/## ⚠️ MANDATORY: /## /g; s/## ⚠️ /## /g; s/## ⛔ /## /g' | sort)
  
  # Known intentional changes (not regressions)
  # 5-Phase Process → integrated into Activation line
  LOST=$(comm -23 <(echo "$OLD_SECTIONS") <(echo "$NEW_SECTIONS") | \
    grep -v "5-Phase Process")
  
  if [ -z "$LOST" ]; then
    check "true" "No sections lost"
  else
    check "false" "LOST SECTIONS: $LOST"
  fi
  echo ""
fi

# === SUMMARY ===
echo "╔══════════════════════════════════════════╗"
TOTAL=$((PASS + FAIL))
echo "║  RESULT: $PASS/$TOTAL passed"

if [ "$FAIL" -eq 0 ]; then
  echo "║  STATUS: ✅ PASS"
else
  echo "║  STATUS: ❌ FAIL ($FAIL issues)"
fi
echo "╚══════════════════════════════════════════╝"

exit $FAIL
