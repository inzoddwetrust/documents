# Backlog

Future improvements and known issues for skill-architect.

---

## Active (no version assigned)

| # | Task | Priority | Source |
|---|------|----------|--------|
| B-001 | Auto-detect protocol from context | Medium | v6.2.0 |
| B-002 | Protocol execution logging | Low | v6.2.0 |
| B-003 | Template generator script | Low | v6.2.0 |
| B-004 | MANIFEST.md generation — add descriptions | Medium | v6.2.0 |

---

## Known Issues

| # | Issue | Severity | Workaround |
|---|-------|----------|------------|
| I-001 | validate-skill.sh warns on "." folder | Low | Use full path |
| I-002 | MANIFEST check looks for files without paths | Low | Cosmetic, ignore |

---

## Done

### v7.2.0

| # | Task | Implemented |
|---|------|-------------|
| B-012 | P07↔P08 swap | P07-scan.md, P08-docs-closure.md, P00-router.md |
| B-013 | Flat numbered docs | docs-packaging.md |
| B-014 | Add 06-SCAN.md | docs-packaging.md |
| B-015 | Remove decisions/ subfolder | docs-packaging.md |
| B-016 | Create validate-docs.sh | scripts/validate-docs.sh |
| B-017 | Fix Context Anchor format | templates.md, SKILL.md, P01-activation.md |

### v7.1.1

| # | Task | Implemented |
|---|------|-------------|
| B-010 | Dynamic token counter colors | templates.md, SKILL.md |
| B-011 | Context Anchor for recovery | templates.md, quality-checklist.md |
| FIX | P01 Standard Activation Response | P01-activation.md |

### v7.1.0

| # | Task | Implemented |
|---|------|-------------|
| B-007 | Geo-bias rule | templates.md, quality-checklist.md |
| B-008 | Token counter sync | 5 templates |
| B-009 | Standard Activation template | templates.md |

### v7.0.1

| # | Task | Implemented |
|---|------|-------------|
| B-005 | Footer version drift | All 21 files |
| B-006 | self-diagnostic.sh false negative | Pattern fixed |

---

*05-BACKLOG v1.0.0 | skill-architect v7.2.0*
