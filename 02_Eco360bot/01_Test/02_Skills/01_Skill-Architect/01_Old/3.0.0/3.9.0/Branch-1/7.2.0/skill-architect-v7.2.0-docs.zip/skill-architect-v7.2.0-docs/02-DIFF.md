# Diff Report: v7.1.1 → v7.2.0

## Summary

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Files | 41 | 42 | +1 |
| Lines | ~6600 | ~6800 | +200 |
| Protocols | 9 | 9 | 0 |
| Scripts | 7 | 8 | +1 |

---

## Added

| File | Lines | Purpose |
|------|-------|---------|
| scripts/validate-docs.sh | 110 | Docs structure validation |
| P07-scan.md | 98 | Chat scan protocol |
| P08-docs-closure.md | 134 | Docs + closure protocol |

---

## Changed

| File | Change |
|------|--------|
| P00-router.md | State machine P07↔P08 swap, decision table |
| P01-activation.md | Standard Activation with code block anchor |
| SKILL.md | Protocol Router table, Context Tracking format |
| templates.md | Context Anchor = code block, Dynamic Token Counter |
| docs-packaging.md | Complete rewrite: 8-file flat structure |

---

## Removed

| File | Replaced By |
|------|-------------|
| P07-delivery-docs.md | P07-scan.md |
| P08-scan.md | P08-docs-closure.md |
| decisions/ subfolder | Flat 04-DECISIONS.md |

---

## Preserved

- P02-config.md through P06-delivery-skill.md (logic unchanged)
- All testing files (virtual-testing, personas, adversarial, etc.)
- All project mode files
- All other scripts (7 unchanged)
- engines.md, packaging.md, naming-convention.md

---

## Validation

| Check | Result |
|-------|--------|
| validate-skill.sh | ✅ VALID |
| validate-naming.sh | ✅ VALID |

---

*02-DIFF v1.0.0 | skill-architect v7.2.0*
