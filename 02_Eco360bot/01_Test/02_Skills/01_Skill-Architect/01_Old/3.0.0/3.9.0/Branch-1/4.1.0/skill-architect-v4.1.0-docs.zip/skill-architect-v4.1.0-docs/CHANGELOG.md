# CHANGELOG: skill-architect

Все значимые изменения документируются здесь.

Формат основан на [Keep a Changelog](https://keepachangelog.com/).

---

## [4.1.0] "Delivery Protocol" — 2025-11-30

### Added
- **3-Step Delivery Protocol** — SKILL → да → DOCS → да → SCAN
- **PRE-BUILD CHECKPOINT** — защита от context drift после web_search/длинных сессий
- **reference/evaluations.md** — 5 тестовых сценариев (E-001 до E-005)
- **Constraints Reminder** — таблица правил в planning-document.md

### Changed
- Docs Workflow интегрирован в Delivery Protocol
- README.md обновлён с новым процессом

### Removed
- Development Cycle diagram (заменён на Delivery Protocol)

### Sources
- B-002, B-003, B-004 из BACKLOG
- PATCH: Context Loss After Web Search
- P-001: Document naming convention

---

## [4.0.0] "Unified + Docs" — 2025-11-30

### Added
- **Mandatory Token Counter** с Self-test
- **Quick Start** секция
- **Unified Workflow** — один процесс для CREATE/UPDATE/REFACTOR
- **Single Responsibility** правило
- **Output Separation** — runtime vs docs
- **Evaluation Mindset** секция
- **Docs Workflow** — цикл версионирования

### Changed
- Убрана Activation Ceremony
- REFACTOR + UPDATE протоколы объединены

### Removed
- "Skill Architect ready" сообщение
- Отдельные протоколы для разных типов задач

---

## [3.9.0] "Clean + MANIFEST" — 2025-11-29

### Added
- Clean Skill Principles
- MANIFEST.md tracking
- generate-manifest.sh script

### Changed
- Planning Document улучшен

---

## [3.8.0] "Planning Document First" — 2025-11

### Added
- Planning Document как обязательный шаг
- Chat Verification
- Diff Report

---

*CHANGELOG v1.2.0 | skill-architect*
