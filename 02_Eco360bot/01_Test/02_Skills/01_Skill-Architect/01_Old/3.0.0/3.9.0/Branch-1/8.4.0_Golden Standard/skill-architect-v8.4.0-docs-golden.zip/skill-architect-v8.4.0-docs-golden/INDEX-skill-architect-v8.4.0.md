# INDEX: skill-architect v8.4.0 Documentation

**Generated:** 2025-12-12  
**Codename:** "Golden Standard"

---

## Document Map

| # | Document | Purpose | Lines |
|---|----------|---------|-------|
| 1 | README-skill-architect.md | User documentation | ~115 |
| 2 | CHANGELOG-skill-architect.md | Version history | ~95 |
| 3 | PLAN-skill-architect-v8.4.0.md | Release planning | ~130 |
| 4 | DIFF-skill-architect-v8.4.0.md | Version delta | ~75 |
| 5 | DECISIONS-skill-architect-v8.4.0.md | ADRs | ~95 |
| 6 | BACKLOG-skill-architect-v8.4.0.md | Open items | ~80 |
| 7 | SCAN-skill-architect-v8.4.0.md | Validation results | ~90 |
| 8 | LOGIC-TREE-skill-architect-v8.4.0.md | Flow diagram | ~135 |

**Total:** 8 documents, ~815 lines

---

## Naming Convention

```
{TYPE}-{skill-name}[-v{X.Y.Z}].md

Examples:
- README-skill-architect.md        (no version, always current)
- CHANGELOG-skill-architect.md     (no version, cumulative)
- PLAN-skill-architect-v8.4.0.md   (version-specific)
- DIFF-skill-architect-v8.4.0.md   (version-specific)
```

### Document Types

| Type | Versioned | Purpose |
|------|-----------|---------|
| README | No | User documentation |
| CHANGELOG | No | Cumulative history |
| PLAN | Yes | Release planning |
| DIFF | Yes | Version changes |
| DECISIONS | Yes | ADRs for version |
| BACKLOG | Yes | Open items snapshot |
| SCAN | Yes | Validation snapshot |
| LOGIC-TREE | Yes | Flow at version |
| INDEX | Yes | This file |

---

## Quick Links

**For Users:**
- Start here → README-skill-architect.md
- What changed → DIFF-skill-architect-v8.4.0.md

**For Developers:**
- Why decisions → DECISIONS-skill-architect-v8.4.0.md
- What's next → BACKLOG-skill-architect-v8.4.0.md

**For Validation:**
- Scan results → SCAN-skill-architect-v8.4.0.md
- Flow check → LOGIC-TREE-skill-architect-v8.4.0.md

---

## Archive Structure

```
skill-architect-v8.4.0-docs/
├── INDEX-skill-architect-v8.4.0.md     ← You are here
├── README-skill-architect.md
├── CHANGELOG-skill-architect.md
├── PLAN-skill-architect-v8.4.0.md
├── DIFF-skill-architect-v8.4.0.md
├── DECISIONS-skill-architect-v8.4.0.md
├── BACKLOG-skill-architect-v8.4.0.md
├── SCAN-skill-architect-v8.4.0.md
└── LOGIC-TREE-skill-architect-v8.4.0.md
```

---

*INDEX-skill-architect-v8.4.0.md | skill-architect v8.4.0*
