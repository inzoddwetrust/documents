# skill-architect: План v8.0.3 → v8.0.4

## Date | Context

**Дата:** 2025-12-12  
**Контекст:** Патч на основе исследования параллелей ИИ ↔ аутистическое мышление

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | User's language |
| Frontmatter | name + description + version |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

При работе над статьёй о параллелях нейронных сетей и аутистического мышления выявлены паттерны, применимые к процессу создания скиллов:

- **ABA ↔ Reinforcement Learning** → принцип Gradient Feedback
- **Dropout ↔ Context focus** → Context Regularization (неявно используется, сделать явным)
- **TEACCH → Prompt Engineering** → Single Component Rule

Сам факт того, что я пропустил чтение P03 перед планированием — демонстрация проблемы, которую эти принципы должны решать.

---

## 2. Проблемы / Задачи

| # | Проблема | Следствие |
|---|----------|-----------|
| 1 | "Знаю что делать" — пропуск file_read | Нарушение протоколов, переделки |
| 2 | "Быстрее покажу результат" | Сжигание токенов на исправления |
| 3 | Нет явного "Protocol First" rule | Claude "торопится" |
| 4 | Нет правила "один компонент за раз" | Трудно определить причину ошибки |
| 5 | Нет правила проверки после каждого шага | Ошибки накапливаются |
| 6 | Context Regularization только неявно | Легко нарушить |

---

## 3. План изменений

### Добавляем

```markdown
## ⛔ Protocol First, Always

**Каждый ход:**
1. Где я? → P00-router
2. Какой протокол? → file_read
3. Что делать? → Steps из протокола
4. Делаю ТОЛЬКО то, что в протоколе

**Запрещено:**
- "Знаю что делать" → НЕТ, читай протокол
- "Быстрее покажу результат" → НЕТ, следуй процессу
- "Это простое изменение" → НЕТ, план обязателен
- Пропуск file_read → БЛОКЕР

**Следование = Работа. Нет следования = нет работы.**
```

```markdown
## Iteration Principles

### Gradient Feedback
При итерации/отладке скилла:
1. Один маленький шаг → проверка результата
2. Успех? → продолжить. Провал? → откат + анализ
3. Explicit checkpoint после каждого изменения

### Single Component Rule
- Не менять >1 компонента за итерацию
- Изменил SKILL.md? → проверь → потом README
- Нарушение → невозможно определить причину проблемы

### Context Regularization
- Один протокол за раз (формализация existing)
- Один файл в фокусе при редактировании
- Завершить текущий шаг → confirm → следующий
```

### Изменяем

| Что | Было | Стало |
|-----|------|-------|
| description | v8.0.3 | v8.0.4 |
| version footer | v8.0.3 | v8.0.4 |

### Удаляем

Ничего

### Не трогаем

- Protocol Router
- Purpose section
- NEVER DEGRADE section
- FIRST STEP section
- BEFORE EVERY RESPONSE section
- Context Anchor
- Quick Start
- Output table
- Modes
- Resources (все reference files)
- Scripts

---

## 4. Было → Стало

### Было (структура)

```
# Skill Architect v8.0.3
├── Purpose
├── ⛔ NEVER DEGRADE
├── ⛔ FIRST STEP
├── ⛔ BEFORE EVERY RESPONSE
├── ⚠️ Context Anchor
├── Protocol Router
├── Quick Start
├── Output
├── Modes
└── Resources
```

### Стало (структура)

```
# Skill Architect v8.0.4
├── Purpose
├── ⛔ NEVER DEGRADE
├── ⛔ FIRST STEP
├── ⛔ BEFORE EVERY RESPONSE
├── ⛔ Protocol First, Always   ← NEW (anti-торопыга)
├── Iteration Principles        ← NEW
│   ├── Gradient Feedback       ← NEW
│   ├── Single Component Rule   ← NEW
│   └── Context Regularization  ← NEW
├── ⚠️ Context Anchor
├── Protocol Router
├── Quick Start
├── Output
├── Modes
└── Resources
```

---

## 5. Риски

| Риск | Вероятность | Влияние | Митигация |
|------|-------------|---------|-----------|
| SSOT дублирование | Medium | Medium | ssot-check.sh |
| Превышение 300 строк | Low | High | Секция компактная (~15 lines) |
| Противоречие с existing rules | Low | High | Review NEVER DEGRADE |
| Усложнение | Low | Low | Принципы краткие |

---

## 6. Чат-верификация

**Обсуждённые пункты:**

| # | Item | Статус | Источник |
|---|------|--------|----------|
| 1 | "Знаю что делать" = плохо | ✅ В плане | Чат: "зачем тебе быть уверенным и обсираться" |
| 2 | "Быстрее покажу результат" = плохо | ✅ В плане | Чат: "маркетинговую штуку нам как то зачистить" |
| 3 | Следование = Работа | ✅ В плане | Чат: "для меня следование = работа" |
| 4 | Protocol First rule | ✅ В плане | Чат: "каждый ход где я что делаю читаем протоколы" |
| 5 | Gradient Feedback | ✅ В плане | Чат: "Маленький шаг → проверка" |
| 6 | Single Component Rule | ✅ В плане | Чат: "Не менять >1 компонента" |
| 7 | Context Regularization | ✅ В плане | Чат: "сделать явным" |
| 8 | Запрет на пропуск file_read | ✅ В плане | Чат: "почему не читаю протоколы каждый ход" |

**Verified:** 8 items. Missing: none.

---

## 7. Чеклист подтверждения

- [ ] План понятен
- [ ] Изменения согласованы
- [ ] Риски приемлемы
- [ ] Можно начинать

---

**Ожидаю подтверждение: "да", "yes", "go", "делай"**

---

*skill-architect_PLAN.md | P03-planning | 2025-12-12*
-e 
---

*03-PLAN.md v1.0.0 | skill-architect v8.0.4*
