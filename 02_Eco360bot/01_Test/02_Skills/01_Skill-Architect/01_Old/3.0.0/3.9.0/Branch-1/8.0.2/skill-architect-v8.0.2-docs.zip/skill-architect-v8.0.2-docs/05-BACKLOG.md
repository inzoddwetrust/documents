# Backlog

## skill-architect

---

## Active

| # | Task | Priority | Added | Notes |
|---|------|----------|-------|-------|
| B-001 | 17 файлов на v8.0.1 | Low | 2025-12-08 | Не критично, обновить при следующем релизе |
| B-002 | clean-protocol — новый Context Anchor | Med | 2025-12-08 | Зависимость, нужен sync |
| B-003 | **P07+P08 merge + Simulation Mode** | High | 2025-12-08 | См. детали ниже |

---

## B-003: P07+P08 Merge + Simulation Mode

### Проблема
После сборки скилла иногда всплывают минорные баги которые можно было бы поймать автоматически. Сейчас нет "smoke test" перед финальной доставкой.

### Решение
1. **Объединить P07 (Scan) + P08 (Docs)** в один шаг
2. **Добавить Simulation Mode** в финальный шаг:
   - Dry-run через все шаги скилла
   - Логическая проверка без реального выполнения
   - Выявление inconsistencies

### Архитектура (draft)

```
P07-closure (merged):
├── 1. Scan (current P07)
├── 2. Simulation Test ← NEW
│   ├── Load skill SKILL.md
│   ├── Simulate activation → check menu
│   ├── Simulate each protocol step
│   ├── Check cross-references
│   └── Report: PASS/FAIL + issues
├── 3. Docs generation (current P08)
└── 4. Final delivery
```

### Применимость
- Новые скиллы: после P06
- Рефакторинг: после P06
- Self-update: после P06

### Status
🔵 Planned — требует отдельной сессии

---

## Ideas

| # | Idea | Added | Notes |
|---|------|-------|-------|
| I-001 | Auto-sync versions across all files | 2025-12-08 | Script для массового обновления footers |
| I-002 | SSOT validation for Context Anchor format | 2025-12-08 | Проверка единого формата |

---

## Completed (this session)

- [x] Purpose блок
- [x] Context Anchor унификация
- [x] Code-to-artifact правило
- [x] P01 меню sync
- [x] Version sync 7 файлов

---

*05-BACKLOG v1.0.0 | skill-architect v8.0.2*
