# Logic Tree

---

## Protocol Router Flow

```
[USER MESSAGE]
        │
        ▼
┌───────────────────────────────────┐
│ ⛔ FIRST STEP                     │
│ file_read → P00-router.md         │
└───────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────┐
│ P00 DECISION TABLE                │
├───────────────────────────────────┤
│ No skill context? → P01           │
│ Purpose unclear?  → P02           │
│ Need plan?        → P03 ⛔        │
│ Plan confirmed?   → P04           │
│ Build done?       → P05           │
│ Validated?        → P06 ⛔        │
│ Delivered?        → P07 ⛔        │
│ Simulation?       → P08           │
└───────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────┐
│ ⛔ Protocol First, Always         │
├───────────────────────────────────┤
│ 1. Where am I? → P00-router       │
│ 2. Which protocol? → file_read    │
│ 3. What to do? → Steps            │
│ 4. Do ONLY what protocol says     │
└───────────────────────────────────┘
        │
        ▼
    [EXECUTE PROTOCOL]
        │
        ▼
┌───────────────────────────────────┐
│ Iteration Principles              │
├───────────────────────────────────┤
│ □ One small step?                 │
│ □ Verified result?                │
│ □ Single component changed?       │
│ □ One file in focus?              │
└───────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────┐
│ ⛔ BEFORE EVERY RESPONSE          │
├───────────────────────────────────┤
│ □ file_read protocol?             │
│ □ At blocking point? → STOP       │
│ □ Names follow convention?        │
│ □ Code >3 lines → artifact?       │
│ □ Token counter at end?           │
└───────────────────────────────────┘
        │
        ▼
    [RESPONSE]
        │
        ▼
┌───────────────────────────────────┐
│ Context Anchor (MANDATORY)        │
│ ⚙️ skill-architect · P0X · status │
│ 🟢 XXXk | ~XXk 🟡                 │
└───────────────────────────────────┘
```

---

## Protocol Flow

```
P01-activation
    │
    ▼
P02-config
    │
    ▼
P03-planning ⛔ BLOCKING
    │ (explicit "да/yes/go")
    ▼
P04-build
    │
    ▼
P05-validate
    │
    ▼
P06-delivery ⛔ BLOCKING
    │ (user confirms)
    ▼
P07-closure ⛔ BLOCKING
    │
    ├── "да" → P08-simulation
    │
    └── "нет" → END
```

---

## Iteration Decision Tree

```
Making a change?
    │
    ├── Multiple components? 
    │   └── YES → ⛔ STOP, split into steps
    │
    ├── Read protocol?
    │   └── NO → ⛔ STOP, file_read first
    │
    ├── Previous step verified?
    │   └── NO → ⛔ STOP, verify first
    │
    └── All YES → Proceed
```

---

## Forbidden Patterns

```
"I know what to do"
    └── ❌ NO → file_read protocol

"Faster to show result"
    └── ❌ NO → follow process

"Simple change"
    └── ❌ NO → plan required

Skip file_read
    └── ❌ BLOCKER
```

---

*08-LOGIC-TREE.md v1.0.0 | skill-architect v8.0.4*
