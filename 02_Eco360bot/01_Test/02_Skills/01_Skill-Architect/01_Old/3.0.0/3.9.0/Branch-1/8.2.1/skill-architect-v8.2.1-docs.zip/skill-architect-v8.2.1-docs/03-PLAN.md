# PLAN: skill-architect v8.2.0 → v8.2.1

**Date:** 2025-12-12
**Type:** Self-Audit Patch
**Trigger:** `чекап` command

---

## Constraints

| Rule | Value |
|------|-------|
| SKILL.md language | English |
| SKILL.md max lines | 300 |
| README language | Russian |
| Frontmatter | name + description |
| Confirmation | explicit "да/yes/go" |

---

## 1. Контекст

Self-audit (P09-full-audit) выявил, что skill-architect v8.2.0 не проходит собственные критерии валидации. Это нарушает принцип "eat your own dog food".

---

## 2. Проблемы

| # | Проблема | Severity | Source |
|---|----------|----------|--------|
| 1 | 9 файлов с футером v8.0.3 вместо v8.2.0 | 🔴 Critical | L5 Integration |
| 2 | Gene `protocol_first` не документирован для наследования | 🟡 Important | Genetics |
| 3 | genetic-audit.sh не проверяет protocol_first | 🟡 Important | Script gap |

---

## 3. План изменений

### Добавляем
- [ ] Section "Protocol-First (MANDATORY)" в templates.md
- [ ] Req 9 в genetic-audit.sh для проверки protocol_first

### Изменяем
- [ ] Футеры в 9 файлах: v8.0.3 → v8.2.1
- [ ] Версия во всех файлах: v8.2.0 → v8.2.1
- [ ] MANIFEST.md: регенерация
- [ ] README.md: добавить changelog entry

### Удаляем
- (ничего)

### Не трогаем
- Логику протоколов P00-P09
- Структуру reference/
- Скрипты валидации (кроме genetic-audit.sh)

---

## 4. Было → Стало

### Footer Sync
```
Before: 68% files at v8.2.0, 32% at v8.0.3
After:  100% files at v8.2.1
```

### Genetics
```
Before: 5/8 genes inherited (protocol_first LOST)
After:  6/8 genes inherited (protocol_first DOCUMENTED)
```

### Self-Audit Score
```
Before: 60/90 (REWORK)
After:  90/90 (PROCEED)
```

---

## 5. Риски

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Breaking existing child skills | Low | Medium | Only adds, doesn't remove |
| Version confusion | Low | Low | Clear changelog |

---

## 6. Чат-верификация

Items discussed:
1. ✅ Footer version mismatch (9 files)
2. ✅ Lost gene protocol_first
3. ✅ genetic-audit.sh gap
4. ✅ SSOT warnings (acceptable)
5. ✅ Redundancy score (~8% lean)

Verified: 5 items. Missing: none.

---

## 7. Чеклист подтверждения

- [x] План понятен
- [x] Изменения согласованы
- [x] Риски приемлемы
- [x] Можно начинать

**Подтверждение получено:** "да конечно внеси все найденные правки"

---

*03-PLAN.md v1.0.0 | skill-architect v8.2.1*
