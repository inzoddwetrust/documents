# Skill Architect v8.4.0 "Golden Standard"

Создание скиллов и проектов по протоколам с защитой от context drift.

---

## Быстрый старт

```
create skill: [назначение]
create project: [название]
чекап
```

---

## Команды

| Команда | Действие |
|---------|----------|
| `create skill: [цель]` | Новый скилл |
| `create project: [имя]` | Новый проект |
| `update: [изменения]` | Обновить скилл |
| `refactor` | Рефакторинг |
| `чекап` / `full-audit` | Полный аудит |
| `validate +vt` | Виртуальное тестирование |

---

## Что нового в v8.4.0

### Context Drift Protection
- **PRE-BUILD CHECKPOINT** — чеклист перед каждой сборкой
- **Enhanced Context Anchor** — правила в каждом ответе
- **Self-Check** — самопроверка в каждом протоколе

### Common Mistakes
- Таблица типичных ошибок прямо в SKILL.md
- Visual blocking markers `════ ⛔ BLOCKING ════`

### История эволюции
- retrospective.md с уроками из 18+ версий

---

## Протоколы

| Протокол | Назначение | Блок |
|----------|------------|------|
| P01 | Активация | |
| P02 | Конфигурация | |
| P03 | Планирование | ⛔ |
| P04 | Сборка | |
| P05 | Валидация | |
| P06 | Доставка | ⛔ |
| P07 | Закрытие | ⛔ |
| P08 | Симуляция | опц |
| P09 | Полный аудит | |

---

## Режимы

- **Tool Mode:** Инструменты для Claude (скиллы)
- **Project Mode:** Базы знаний (проекты)

---

## 12 Critical Rules

| # | Правило |
|---|---------|
| 1 | SKILL.md = English only |
| 2 | SKILL.md < 300 lines |
| 3 | Frontmatter: name + description + version |
| 4 | README.md required |
| 5 | MANIFEST.md if reference/ exists |
| 6 | Planning Document before changes |
| 7 | Chat Verification in plan |
| 8 | Diff Report after changes |
| 9 | NEVER remove working functionality |
| 10 | NEVER replace specific with abstract |
| 11 | Explicit confirmation required |
| 12 | Footer versions must match |

---

## Принцип Lean

Claude знает:
- Общие концепции (API, REST, SOLID)
- Стандартные паттерны (OWASP, design patterns)
- Форматы (JSON, YAML, markdown)

Скилл содержит ТОЛЬКО:
- Кастомные workflow
- Blocking points
- Platform constraints
- Ecosystem rules

---

## Changelog

### v8.4.0 "Golden Standard" (2025-12-12)
- ADD: PRE-BUILD CHECKPOINT в SKILL.md
- ADD: Common Mistakes секция
- ADD: Enhanced Context Anchor с rule reminder
- ADD: Self-Check в каждом протоколе
- ADD: Visual blocking markers
- ADD: retrospective.md с историей эволюции
- ADD: Enhanced Recovery в P00-router

### v8.3.0 "Restoration+" (2025-12-12)
- ADD: diff-report.md format restored
- ADD: evaluations.md E-001 to E-008
- ADD: L8 Version Integrity
- FIX: All footers synced

### v8.2.0 "Lean Core" (2025-12-10)
- ADD: L7 Knowledge Redundancy Check
- ADD: Frontmatter key validation
- CHANGE: -58% size (aggressive pruning)

---

*README-skill-architect.md | skill-architect v8.4.0*
