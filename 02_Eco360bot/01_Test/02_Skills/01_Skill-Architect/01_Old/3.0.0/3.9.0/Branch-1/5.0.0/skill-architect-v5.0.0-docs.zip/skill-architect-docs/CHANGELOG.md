# CHANGELOG: skill-architect

Все значимые изменения документируются здесь.

Формат основан на [Keep a Changelog](https://keepachangelog.com/).

---

## [5.0.0] "Project Mode" — 2025-12-01

### Added
- **Project Mode** — создание баз знаний проектов (SSOT)
- **reference/project-mode.md** — обзор Project Mode
- **reference/project-modules.md** — YAML схемы 10 модулей
- **reference/project-import.md** — импорт из документов
- **reference/project-filters.md** — фильтры генерации документов
- **reference/naming-convention.md** — единые правила именования (B-014)
- **scripts/validate-naming.sh** — проверка именования (B-014)

### Changed
- **SKILL.md** — dual-mode (Tool + Project), новые триггеры
- **README.md** — документация обоих режимов
- **MANIFEST.md** — трекинг новых файлов

### Fixed
- **Frontmatter** — убран недопустимый ключ `version` (допустимы только: name, description, license, allowed-tools, metadata)
- **PRE-BUILD CHECKPOINT** — исправлено правило про frontmatter

### Merged
- **Project Architect v2.1.0** → Project Mode
  - Modules, Import, Filters полностью перенесены
  - Project Architect deprecated

### Closed from BACKLOG
- B-014: Unified Naming Convention
- B-005: development-guide.md

---

## [4.1.0] "Delivery Protocol" — 2025-11-30

### Added
- **3-Step Delivery Protocol** — SKILL → confirm → DOCS → confirm → SCAN
- **PRE-BUILD CHECKPOINT** — защита от context drift
- **reference/evaluations.md** — 5 тестовых сценариев
- **Constraints Reminder** — таблица правил в planning-document.md

### Changed
- Docs Workflow интегрирован в Delivery Protocol
- README.md обновлён с новым процессом

### Removed
- Development Cycle diagram (заменён на Delivery Protocol)

### Sources
- B-002, B-003, B-004 из BACKLOG
- PATCH: Context Loss After Web Search

---

## [4.0.0] "Unified + Docs" — 2025-11-30

### Added
- **Mandatory Token Counter** с Self-test
- **Quick Start** секция
- **Unified Workflow** — один процесс для CREATE/UPDATE/REFACTOR
- **Single Responsibility** правило
- **Output Separation** — runtime vs docs
- **Evaluation Mindset** секция
- **Docs Workflow** — цикл версионирования

### Changed
- Убрана Activation Ceremony
- REFACTOR + UPDATE протоколы объединены

### Removed
- "Skill Architect ready" сообщение
- Отдельные протоколы для разных типов задач

---

## [3.9.0] "Clean + MANIFEST" — 2025-11-29

### Added
- Clean Skill Principles
- MANIFEST.md tracking
- generate-manifest.sh script

### Changed
- Planning Document улучшен

---

## [3.8.0] "Planning Document First" — 2025-11

### Added
- Planning Document как обязательный шаг
- Chat Verification
- Diff Report

---

*CHANGELOG v1.3.0 | skill-architect*
