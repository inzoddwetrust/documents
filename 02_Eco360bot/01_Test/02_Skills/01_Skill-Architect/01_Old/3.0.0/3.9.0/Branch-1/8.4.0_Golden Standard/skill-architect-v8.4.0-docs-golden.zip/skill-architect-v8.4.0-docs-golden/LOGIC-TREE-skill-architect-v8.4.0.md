# LOGIC-TREE: skill-architect v8.4.0

Business logic flow and decision points.

---

## Main Flow

```
┌─────────────────────────────────────────────────────────────┐
│                      ACTIVATION                              │
│  P01: "Skill Architect v8.4.0. Purpose? Triggers?"          │
│         ↓                                                    │
│  Purpose stated? → YES → P02                                │
│                   NO  → Wait                                 │
└────────────────────────┼────────────────────────────────────┘
                         ↓
┌────────────────────────┼────────────────────────────────────┐
│                      CONFIG                                  │
│  P02: Extract/Ask mode                                      │
│         ↓                                                    │
│  Mode? → TOOL / PROJECT                                     │
│         ↓                                                    │
│  Self-Check ✓                                               │
└────────────────────────┼────────────────────────────────────┘
                         ↓
┌────────────────────────┼────────────────────────────────────┐
│  ════════════════════════════════════════════════════════   │
│  ⛔ PLANNING — BLOCKING                                      │
│  ════════════════════════════════════════════════════════   │
│  P03: Create Planning Document                              │
│         ↓                                                    │
│  Chat Verification                                          │
│         ↓                                                    │
│  User confirms? → YES (да/yes/go) → P04                     │
│                  NO → Wait / Revise                          │
│                  "ок понял" → Re-ask!                        │
└────────────────────────┼────────────────────────────────────┘
                         ↓
┌────────────────────────┼────────────────────────────────────┐
│                      BUILD                                   │
│                                                              │
│  ⛔ PRE-BUILD CHECKPOINT                                    │
│  ┌────────────────────────────┐                             │
│  │ □ Plan confirmed?          │                             │
│  │ □ SKILL.md = English?      │                             │
│  │ □ README = User's lang?    │                             │
│  │ □ < 300 lines?             │                             │
│  └────────────────────────────┘                             │
│         ↓                                                    │
│  P04: NEVER DEGRADE check                                   │
│         ↓                                                    │
│  DEGRADE risk? → YES → ⛔ STOP                              │
│                 NO  → Implement                              │
│         ↓                                                    │
│  Self-Check ✓                                               │
└────────────────────────┼────────────────────────────────────┘
                         ↓
┌────────────────────────┼────────────────────────────────────┐
│                      VALIDATE                                │
│  P05: Run validators L1-L8                                  │
│         ↓                                                    │
│  All pass? → YES → Create Diff Report                       │
│             NO  → Fix, re-validate                          │
│         ↓                                                    │
│  Self-Check ✓                                               │
└────────────────────────┼────────────────────────────────────┘
                         ↓
┌────────────────────────┼────────────────────────────────────┐
│  ════════════════════════════════════════════════════════   │
│  ⛔ DELIVERY — BLOCKING                                      │
│  ════════════════════════════════════════════════════════   │
│  P06: Package .skill                                        │
│         ↓                                                    │
│  Present Diff Report + Download                             │
│         ↓                                                    │
│  Self-Check ✓                                               │
└────────────────────────┼────────────────────────────────────┘
                         ↓
┌────────────────────────┼────────────────────────────────────┐
│  ════════════════════════════════════════════════════════   │
│  ⛔ CLOSURE — BLOCKING                                       │
│  ════════════════════════════════════════════════════════   │
│  P07: Scan + Generate docs                                  │
│         ↓                                                    │
│  Package docs.zip                                           │
│         ↓                                                    │
│  Simulation? → YES → P08                                    │
│               NO  → END                                      │
└─────────────────────────────────────────────────────────────┘
```

---

## Context Drift Protection

```
Triggers: web search, long conversation, doubt
         ↓
PRE-BUILD CHECKPOINT
         ↓
Context Anchor in EVERY response:
┌─────────────────────────────────────────┐
│ ⚙️ skill v8.4.0 · P0X · status          │
│ 📋 SKILL.md=EN | README=[LANG] | <300   │  ← Rule reminder
│ 🟢 ~Xk | ~Yk 🟡                         │
└─────────────────────────────────────────┘
```

---

## Blocking Points (⛔)

| Protocol | Gate | Requires |
|----------|------|----------|
| P03 | Planning | "да/yes/go" |
| P06 | Delivery | Confirmation |
| P07 | Closure | All docs complete |

---

## Quality Gates

| Phase | Check |
|-------|-------|
| Activation | Purpose + Triggers asked |
| Config | Mode + Complexity determined |
| Planning | Chat Verification passed |
| Pre-Build | PRE-BUILD CHECKPOINT passed |
| Build | NEVER DEGRADE passed |
| Validate | L1-L8 all green |
| Delivery | ZIP verified, Diff Report |
| Closure | Scan clean, docs generated |

---

*LOGIC-TREE-skill-architect-v8.4.0.md | skill-architect v8.4.0*
