# Architectural Decisions

## skill-architect v8.1.0

---

## AD-001: Unified Full Audit Protocol (P09)

**Context:**
User pattern: "чекап" → базовый diagnostic → "нет, реально проверь" → + genetic → "ВКЛЮЧИСЬ НА МАКСИМУМ" → + web + VT. Требовалось 3 запроса для полного аудита.

**Decision:**
Создать P09-full-audit как единую точку входа для всех типов аудита.

**Rationale:**
- Single trigger для полного чекапа
- Флаги позволяют гибко выбирать глубину
- Не ломает existing protocols (P09 standalone)

**Consequences:**
- (+) "чекап" сразу запускает полный flow
- (+) Flags --web, --vt, --full для контроля
- (-) +1 protocol file to maintain

---

## AD-002: P09 Accessible from Any State

**Context:**
P01-P08 — sequential flow. P09 нужен в любой момент (чекап attached skill, self-audit mid-session).

**Decision:**
P09 доступен из любого состояния через P00-router, возвращает в предыдущее состояние или END.

**Rationale:**
- Аудит = utility function, не часть main flow
- Не блокирует текущую работу

**Consequences:**
- (+) Гибкость использования
- (-) Сложнее state machine diagram

---

## AD-003: Manual Phases for Web + VT

**Context:**
full-audit.sh может автоматизировать structure + genetics, но web search и VT требуют Claude reasoning.

**Decision:**
Phase 3 (Industry) и Phase 4 (VT) — manual prompts в скрипте.

**Rationale:**
- Web search = Claude tool, не bash
- VT personas/adversarial = reasoning task
- Script даёт checklist что делать

**Consequences:**
- (+) Честный automation boundary
- (-) Не fully automated для --full

---

## AD-004: Context Management as Reference Doc

**Context:**
VT adversarial выявил риск context overflow в long sessions.

**Decision:**
Отдельный reference/context-management.md вместо inline в SKILL.md.

**Rationale:**
- SKILL.md уже 240 строк (лимит 300)
- Context strategy = reference material, не core instruction
- Можно расширять без bloating main file

**Consequences:**
- (+) SKILL.md stays lean
- (+) Detailed strategy available
- (-) One more file to read

---

## AD-005: Keep Version Sync Manual

**Context:**
Version desync (footers v8.0.3 vs SKILL.md v8.0.4) was recurring issue.

**Decision:**
Массовый sed для sync, но не автоматизировать в script.

**Rationale:**
- Version bump = conscious decision
- Auto-sync может mask problems
- Manual = explicit checkpoint

**Consequences:**
- (+) Explicit version control
- (-) Manual work each release

---

## AD-006: Backward Compatible Triggers

**Context:**
Existing users use "self-audit", "genetic audit". New trigger "чекап".

**Decision:**
All triggers route to P09: чекап, self-audit, full-audit, diagnose, validate +full.

**Rationale:**
- NEVER DEGRADE — don't break existing usage
- New trigger = addition, not replacement

**Consequences:**
- (+) No breaking changes
- (+) Multiple entry points

---

## Rejected Alternatives

### Alt-1: Merge P09 into P05-validate
**Rejected:** P05 is part of build flow, P09 is standalone utility

### Alt-2: Auto web-search in script
**Rejected:** web_search is Claude tool, not available in bash

### Alt-3: Context compaction inline in SKILL.md
**Rejected:** Would push SKILL.md over 300 line limit

---

*04-DECISIONS v1.0.0 | skill-architect v8.1.0*
