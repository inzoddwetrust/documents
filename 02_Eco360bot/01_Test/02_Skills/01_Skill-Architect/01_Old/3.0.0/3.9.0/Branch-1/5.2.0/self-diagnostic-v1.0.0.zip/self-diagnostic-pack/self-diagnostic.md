# Self-Diagnostic Protocol

Post-update integrity verification for skill-architect.

---

## When to Run

- After MAJOR/MINOR version update
- After refactor
- On user request: `self-test`, `diagnose`, `проверь себя`

---

## Quick Check (30 sec)

```bash
skill="/mnt/skills/user/skill-architect"

echo "=== QUICK CHECK ==="
wc -l < "$skill/SKILL.md"              # Must be < 300
ls "$skill/scripts/" | wc -l           # Expected: 5
ls "$skill/reference/" | wc -l         # Expected: 12
test -f "$skill/MANIFEST.md" && echo "✅ MANIFEST" || echo "❌ MANIFEST"
```

---

## Full Diagnostic

### 1. Structure Check

| Component | Expected | Check |
|-----------|----------|-------|
| SKILL.md | < 300 lines | `wc -l` |
| README.md | exists | `test -f` |
| MANIFEST.md | exists | `test -f` |
| reference/ | 12 files | `ls \| wc -l` |
| scripts/ | 5 files | `ls \| wc -l` |

### 2. Core Sections (SKILL.md)

Must contain ALL:

```
□ ## Activation
□ ## Config  
□ ## Clean Skill Principles
□ ## REFACTOR Protocol
□ ## UPDATE Protocol
□ ## Diff Report
□ ## Critical Rules
□ ## Versioning
□ ## Resources
```

### 3. Protection Sections (v5.0+)

```
□ ⛔ NEVER DEGRADE
□ ⚠️ MANDATORY: Reference Reading
□ ⚠️ MANDATORY: Context Tracking
□ ⚠️ PRE-BUILD CHECKPOINT
```

### 4. Mode Support

```
□ ## Modes (Tool/Project table)
□ Quick Start covers both modes
□ Project Mode in Resources
```

### 5. Protocol Content (not empty)

| Protocol | Must contain |
|----------|--------------|
| REFACTOR | `unzip`, `audit-skill.sh`, `validate-skill.sh` |
| UPDATE | `Snapshot`, `cp -r` |
| Diff Report | `Deviation from plan`, `REASON` |

### 6. Scripts Presence

```
□ audit-skill.sh
□ audit-project.sh
□ validate-skill.sh
□ validate-naming.sh
□ generate-manifest.sh
```

### 7. Reference Sync

Check all reference files have:
- Consistent line limit (300)
- Current version in footer
- No 350/250 legacy values

---

## Regression Test

Compare with previous version:

```bash
# Extract sections from both versions
grep "^## " old/SKILL.md > /tmp/old-sections
grep "^## " new/SKILL.md > /tmp/new-sections

# Diff
diff /tmp/old-sections /tmp/new-sections
```

**Rule:** If section exists in OLD but not in NEW → BLOCKING issue.

---

## Report Format

```markdown
## Self-Diagnostic: vX.Y.Z

**Date:** YYYY-MM-DD
**Compared with:** vA.B.C

### Structure
- [ ] SKILL.md: X lines (< 300)
- [ ] reference/: X files
- [ ] scripts/: X files

### Sections: X/Y present
[list missing if any]

### Protocols: content verified
[list empty if any]

### Regression: 
[list lost sections if any]

### Status: ✅ PASS / ❌ FAIL
```

---

## Automated Script

Run full diagnostic:

```bash
bash scripts/self-diagnostic.sh /mnt/skills/user/skill-architect
```

---

*Self-Diagnostic Protocol v1.0.0 | skill-architect*
