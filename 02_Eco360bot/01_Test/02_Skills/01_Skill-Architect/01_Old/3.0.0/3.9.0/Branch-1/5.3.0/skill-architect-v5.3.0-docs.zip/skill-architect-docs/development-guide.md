# Development Guide: skill-architect

Как развивать skill-architect. Meta-документация для разработчиков.

---

## Principles

### 1. Evaluation-Driven Development

Перед изменениями:
1. Определи test scenarios в reference/evaluations.md
2. Убедись, что текущие сценарии проходят
3. Добавь сценарии для новой функциональности
4. Реализуй → проверь → итерируй

### 2. BACKLOG as Source of Truth

- Все идеи идут в BACKLOG.md
- Приоритизация: High → Medium → Low
- Перед релизом: review BACKLOG
- После релиза: move to Done или Rejected

### 3. Planning Document First

Никаких изменений без Planning Document:
- KEEP/REMOVE/ADD секции
- Chat Verification
- Explicit confirmation

---

## Versioning (SemVer)

| Change Type | Version | Examples |
|-------------|---------|----------|
| **MAJOR** | X.0.0 | Новые режимы, breaking changes |
| **MINOR** | x.Y.0 | Новые reference файлы, features |
| **PATCH** | x.y.Z | Bug fixes, typos, small improvements |

### Examples

- v5.0.0 — Project Mode (new mode)
- v4.1.0 — Delivery Protocol (new feature)
- v4.0.1 — Fix typo in SKILL.md

---

## Workflow

```
1. BACKLOG Review
   └── Pick items for version

2. Planning Document
   └── KEEP/REMOVE/ADD + Chat Verification

3. Implementation
   └── Create/update files

4. Validation
   └── validate-skill.sh + validate-naming.sh

5. Documentation
   └── DIFF, CHANGELOG, LOGIC-TREE, decisions/

6. Delivery
   └── 3-Step: SKILL → DOCS → SCAN
```

---

## Claude A/B Testing Pattern

**Claude A:** Creates/improves skill
**Claude B:** Tests on real tasks (fresh context)

### Process

1. Claude A создаёт/обновляет скилл
2. Загрузить .skill в новую сессию (Claude B)
3. Claude B выполняет реальные задачи
4. Записать наблюдения:
   - Что работает?
   - Где confusion?
   - Какие инструкции игнорируются?
5. Claude A итерирует на основе наблюдений

### Key Observations to Track

- Context drift after N messages
- Instruction following rate
- Edge case handling
- Token efficiency

---

## File Organization

### Runtime (ships with .skill)

```
skill-architect/
├── SKILL.md          # Claude reads this
├── README.md         # User reads this
├── MANIFEST.md       # Integrity tracking
├── reference/        # Detailed instructions
└── scripts/          # Automation
```

### Docs (ships with -docs.zip)

```
skill-architect-docs/
├── vX.Y.Z-PLAN.md    # Version plan
├── vX.Y.Z-DIFF.md    # What changed
├── CHANGELOG.md      # History
├── BACKLOG.md        # Future ideas
├── LOGIC-TREE.md     # Flow visualization
├── decisions/        # ADRs
└── development-guide.md  # This file
```

---

## Quality Checklist

Before release:

```
□ SKILL.md < 300 lines
□ SKILL.md English only
□ README.md in user's language
□ MANIFEST.md updated
□ Validation scripts pass
□ Naming convention followed
□ Planning Document created
□ Diff Report created
□ CHANGELOG updated
□ BACKLOG updated
□ LOGIC-TREE updated (if flow changed)
□ Decisions documented (if significant)
```

---

## Common Pitfalls

| Pitfall | Solution |
|---------|----------|
| SKILL.md too long | Move details to reference/ |
| Cyrillic in SKILL.md | English only, Cyrillic in README |
| Skipping Planning Doc | Always create, even for "small" changes |
| Forgetting validation | Run both validate-*.sh scripts |
| Missing Chat Verification | Scan entire chat before finalizing plan |

---

## Reference Files Guidelines

### When to Create New File

- Distinct responsibility
- >100 lines of content
- Reusable across scenarios

### When to Add to Existing

- Related to existing file's scope
- <50 lines addition
- Logical grouping

### Naming

- lowercase-kebab-case.md
- Descriptive verb-noun or topic

---

## Scripts Guidelines

### Validation Scripts

- Return 0 on success, 1 on failure
- Print colored output (green ✅, red ❌)
- Check specific rules, not generic linting

### Utility Scripts

- Single responsibility
- Clear usage message
- Idempotent where possible

---

*Development Guide v1.0.0 | skill-architect v5.0.0 | 2025-12-01*
