# Planning Document: skill-architect v3.9.0 → v4.0.0

**Date:** 2025-11-29  
**Type:** UPDATE (major - breaking changes)  
**Sources:** 2 independent audits (comparative + technical)

---

## Executive Summary

**Current State:** v3.9.0 — 70/100 (Opus) / 88/100 (comparative)  
**Target State:** v4.0.0 — 90-94/100  
**Approach:** Fix critical bugs (Opus) + add strategic improvements (comparative)

---

## KEEP (Preserve These — They Work)

### Architecture ✅
- Progressive disclosure (SKILL.md 223 lines + reference/)
- Validation scripts (validate-skill.sh, audit-skill.sh, generate-manifest.sh)
- 5-Phase Process
- MANIFEST.md integrity tracking
- Planning Document + Chat Verification workflow
- Diff Report pattern

### Files Structure ✅
- reference/ organization (6 files, one level deep)
- scripts/ with working utilities
- Clean Skill Principles section

**Reasoning:** These exceed Anthropic standards and work well in practice.

---

## REMOVE (Delete or Deprecate)

### Critical Bugs (Opus Audit)

1. **Version inconsistencies**
   - README.md says v3.8.0 → DELETE outdated
   - reference files mention v3.2.0, v3.3.0 → REMOVE version references
   
2. **Conflicting limits**
   - 300 vs 350 lines mentioned → UNIFY to 300
   
3. **Activation ceremony**
   - "Skill Architect ready. Purpose?" → REMOVE (wastes tokens)

### Code Duplication

4. **`zip -r` command repeated 8 times**
   - Consolidate packaging instructions

### Redundancy (Comparative Audit)

5. **Critical Rules table** (15 lines)
   - Convert to prose (save 7 lines)

6. **Versioning table** (7 lines)
   - Convert to compact list (save 2 lines)

**Reasoning:** Reduces maintenance burden, aligns with "concise is key" principle.

---

## ADD (New Features & Fixes)

### Priority 0: Critical Fixes (Opus)

1. **Sync all versions to v4.0.0**
   - README.md
   - All reference files
   - MANIFEST.md

2. **Update description (Anthropic pattern)**
   ```yaml
   FROM: "v3.9.0 | Professional skill creation with MANIFEST integrity..."
   TO: "Creates, refactors, and validates Claude Skills with MANIFEST tracking. 
        Use when creating/updating skills or user mentions: create skill, 
        refactor skill, architect skill, создай скилл."
   ```

3. **Add Evaluation Framework** (NEW section)
   ```markdown
   ## Evaluation-Driven Development
   
   Before extensive documentation:
   1. Identify gaps — what fails without this skill?
   2. Create 3+ test scenarios
   3. Establish baseline
   4. Write minimal instructions
   5. Iterate based on results
   
   Required evals: Create skill, Update skill, Refactor skill
   ```

4. **Add reference/evaluations.md** (NEW file)
   - 3 evaluation scenarios
   - Expected outputs
   - Pass/fail criteria

### Priority 1: Strategic Improvements (Comparative)

5. **Mandatory Token Counter** (move to top, add self-test)
   ```markdown
   ## ⚠️ MANDATORY: Token Counter
   
   NON-NEGOTIABLE — EVERY response MUST end with:
   ```
   🟡 -[cost] | ~[remaining] 🟢
   ```
   
   ### Self-Test
   Before responding, verify token counter WILL appear.
   ```

6. **Quick Start section**
   ```markdown
   ## Quick Start
   
   Create: "create skill: [purpose]"
   Update: [attach .skill] + "update: [changes]"
   Refactor: [attach .skill] + "refactor this skill"
   ```

7. **Model Testing Protocol**
   ```markdown
   ## Model Testing
   
   Test all target models:
   - Haiku: Enough guidance?
   - Sonnet: Clear and efficient?
   - Opus: Avoid over-explaining?
   ```

8. **Document Feedback Loop Pattern**
   ```markdown
   ## Validation Feedback Loop
   
   Pattern: Generate → Validate → Fix → Repeat
   
   1. Create/modify skill
   2. Run bash scripts/validate-skill.sh
   3. If errors: fix and return to step 1
   4. If pass: proceed to packaging
   ```

9. **Unify REFACTOR/UPDATE protocols** (single workflow)
   - Merge two 110-line sections into one 75-line workflow
   - Use conditional steps based on task type

### Priority 2: Polish

10. **Add concrete examples** (replace abstract ones in templates.md)
11. **Simplify Critical Rules table** → prose
12. **Add tips/notes/warnings** to main SKILL.md
13. **Update README.md** with v4.0.0 changelog

---

## CHANGE (Modify Existing)

### Content Changes

| Section | Before | After | Reason |
|---------|--------|-------|--------|
| Activation | "Response: `Skill Architect ready...`" | "Start immediately. If unclear, ask: `Purpose? Triggers?`" | Save tokens |
| Context Tracking | Optional, at end | Mandatory, with self-test at top | Prevent token loss |
| REFACTOR + UPDATE | 2 separate protocols (110 lines) | 1 unified workflow (75 lines) | Reduce complexity |
| Critical Rules | 15-line table | 8-line prose | Token efficiency |
| Versioning | 7-line table | 5-line list | Scannable |
| Config | "Ask: Purpose? Triggers?" | "Auto-derive from purpose" | Fewer questions |

### File Changes

| File | Change | Lines Impact |
|------|--------|--------------|
| SKILL.md | Add evals, token counter, Quick Start, compress tables | 223 → ~190 |
| README.md | Update to v4.0.0, add changelog | 67 → 80 |
| reference/evaluations.md | NEW FILE | +150 |
| reference/engines.md | Remove version references | 372 → 365 |
| reference/workflow.md | Remove version refs, unify limit to 300 | 286 → 280 |
| reference/quality-checklist.md | Remove version refs | 246 → 242 |
| reference/templates.md | Add concrete examples | 275 → 290 |
| MANIFEST.md | Update to v4.0.0 | 30 → 40 |

**Total:** ~2700 → ~2850 lines (+150 for evals, -100 from compression)

---

## Chat Verification

**Discussed items from both audits:**

### Opus Audit (Technical):
1. ✅ Version sync (README, reference files)
2. ✅ Unify 300-line limit
3. ✅ Update description
4. ✅ Add evaluation framework
5. ✅ Add evaluations.md
6. ✅ Remove time-sensitive versions
7. ✅ Fix `zip -r` duplication
8. ✅ Add concrete examples

### Comparative Audit (Strategic):
1. ✅ Mandatory token counter
2. ✅ Remove activation ceremony
3. ✅ Add Quick Start
4. ✅ Model testing protocol
5. ✅ Feedback loop documentation
6. ✅ Unify protocols
7. ✅ Compress tables
8. ✅ Improve description

**Verified: 16 items total. Missing: none**

---

## Implementation Strategy

### Phase 1: Critical Fixes (30 min)
1. Sync versions everywhere
2. Update description
3. Unify 300-line limit
4. Add mandatory token counter
5. Remove activation ceremony

### Phase 2: New Features (45 min)
6. Add Quick Start
7. Add Evaluation Framework section
8. Create reference/evaluations.md
9. Add Model Testing Protocol
10. Document Feedback Loop Pattern

### Phase 3: Compression (30 min)
11. Unify REFACTOR/UPDATE workflows
12. Compress tables to prose
13. Add concrete examples
14. Update README.md

### Phase 4: Validation (15 min)
15. Run validate-skill.sh
16. Generate MANIFEST.md
17. Create Diff Report

**Total Estimated Time:** 2 hours

---

## Expected Outcomes

| Metric | v3.9.0 | v4.0.0 | Change |
|--------|--------|--------|--------|
| Opus Score | 70/100 | 90/100 | +20 |
| Comparative Score | 88/100 | 94/100 | +6 |
| Anthropic Checklist | 64% (14/22) | 95% (21/22) | +31% |
| SKILL.md lines | 223 | ~190 | -15% |
| Total files | 12 | 13 | +1 (evals) |
| Total size | 86KB | ~92KB | +7% |

**Key Improvements:**
- ✅ All critical bugs fixed
- ✅ Evaluation framework added
- ✅ Mandatory token tracking
- ✅ 95% Anthropic compliance
- ✅ More efficient (190 vs 223 lines)

---

## Breaking Changes

1. **Token counter now mandatory** (was optional)
2. **No activation ceremony** (immediate start)
3. **Unified workflow** (REFACTOR/UPDATE merged)

**Migration:** Backward compatible. Old behavior still works if explicitly requested.

---

## Risk Assessment

| Change | Risk | Mitigation |
|--------|------|------------|
| Mandatory tracking | 🟢 Low | Self-test catches failures |
| No ceremony | 🟢 Low | Matches public skills |
| Unified workflow | 🟡 Medium | Document trigger mapping |
| New eval framework | 🟢 Low | Additive, doesn't break existing |
| Version bump to v4.0.0 | 🟢 Low | SemVer: breaking changes = MAJOR |

**Overall Risk:** 🟢 LOW

---

## Approval Request

This plan:
- ✅ Fixes all 3 critical bugs from Opus
- ✅ Implements 8 strategic improvements from comparative audit
- ✅ Achieves 90-94/100 target score
- ✅ Maintains backward compatibility
- ✅ Follows skill-architect's own protocols

**Ready to proceed?**

---

*Planning Document v1.0 — skill-architect self-update*  
*Follows: Planning Document protocol + Chat Verification*
