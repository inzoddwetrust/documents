# Skill Architect v2.1: Action Items Checklist

Пошаговый чеклист для обновления экосистемы

---

## 🎯 Phase 1: Compliance (12 часов)

### Task 1.1: skill-architect-templates [4h] 🔴🔴 КРИТИЧНО

- [ ] **[30 мин]** Создать backup
  ```bash
  cp -r skill-architect-templates-v2.0 skill-architect-templates-v2.0.backup
  ```

- [ ] **[90 мин]** Реструктурировать SKILL.md (735 → 155 строк)
  - [ ] Создать новую компактную версию SKILL.md
  - [ ] Убрать все 15 встроенных шаблонов
  - [ ] Удалить Core Behavior Rules дубликат (-80 строк)
  - [ ] Упростить Smart Routing Logic (-100 строк)
  - [ ] Оставить только overview + navigation

- [ ] **[60 мин]** Создать reference структуру
  - [ ] Создать `reference/templates/utilities/`
  - [ ] Создать `reference/templates/domain/`
  - [ ] Создать `reference/templates/analysis/`
  - [ ] Создать `reference/templates/content/`
  - [ ] Создать `reference/templates/integration/`

- [ ] **[90 мин]** Переместить шаблоны
  - [ ] Создать отдельный .md файл для каждого шаблона
  - [ ] Создать `reference/template-index.md`
  - [ ] Добавить cross-references между файлами

**Результат:** 735 → 155 строк (-79%) ✅

---

### Task 1.2: skill-architect-common [3h] 🔴

- [ ] **[30 мин]** Создать backup
  ```bash
  cp -r skill-architect-common-v2.0 skill-architect-common-v2.0.backup
  ```

- [ ] **[90 мин]** Оптимизировать SKILL.md (428 → 298 строк)
  - [ ] Сократить примеры в Core Behavior Rules
  - [ ] Переместить детальные примеры в reference/
  - [ ] Упростить форматы метрик (-30 строк)
  - [ ] Создать Quick Reference секцию

- [ ] **[60 мин]** Улучшить reference структуру
  - [ ] Создать `reference/behavior-rules-detailed.md`
  - [ ] Перенести полные примеры из SKILL.md
  - [ ] Добавить шаблоны для копирования в другие skills
  - [ ] Создать навигационный индекс

**Результат:** 428 → 298 строк (-30%) ✅

---

### Task 1.3: skill-architect (main) [3h] 🔴

- [ ] **[30 мин]** Создать backup
  ```bash
  cp -r skill-architect-v2.0 skill-architect-v2.0.backup
  ```

- [ ] **[60 мин]** Сократить SKILL.md (372 → 281 строка)
  - [ ] Заменить Core Behavior Rules на ссылку (-94 строки)
  - [ ] Упростить workflow description
  - [ ] Создать краткую Quick Start секцию

- [ ] **[90 мин]** Реорганизовать reference файлы
  - [ ] Разделить `best-practices.md` (650 → 2x350 строк)
    - [ ] `best-practices-part1.md` (Foundations + Structure)
    - [ ] `best-practices-part2.md` (Advanced + Optimization)
  - [ ] Разделить `examples-analysis.md` (780 → 2 файла)
    - [ ] `examples-venture-capital.md`
    - [ ] `examples-persona-assistant.md`
  - [ ] Создать `workflow/common.md` с общими правилами
  - [ ] Обновить индексы и cross-references

**Результат:** 372 → 281 строка (-25%) ✅

---

### Task 1.4: skill-architect-tester [2h] 🟡

- [ ] **[20 мин]** Создать backup
  ```bash
  cp -r skill-architect-tester skill-architect-tester.backup
  ```

- [ ] **[60 мин]** Оптимизировать SKILL.md (438 → 278 строк)
  - [ ] Удалить Core Behavior Rules дубликат (-70 строк)
  - [ ] Упростить workflow description (-50 строк)
  - [ ] Убрать встроенные примеры отчетов (-40 строк)
  - [ ] Заменить на ссылки в reference/

- [ ] **[40 мин]** Оптимизировать reference
  - [ ] Ссылаться на common для validation rules
  - [ ] Сократить примеры в criteria/
  - [ ] Создать индекс для быстрого доступа

**Результат:** 438 → 278 строк (-37%) ✅

---

## 🔄 Phase 2: Deduplication (6 часов)

### Task 2.1: Core Behavior Rules [2h]

- [ ] **[60 мин]** Анализ дублирования
  - [ ] Найти все копии Core Behavior Rules
  - [ ] Документировать различия между версиями
  - [ ] Определить canonical version в common

- [ ] **[60 мин]** Консолидация
  - [ ] Оставить только версию в common
  - [ ] Заменить все копии на 3-строчную ссылку:
    ```markdown
    ## Core Behavior
    Follow standardized rules from skill-architect-common:
    → See skill-architect-common for detailed guidelines
    ```
  - [ ] Проверить работоспособность ссылок

**Экономия:** -300 строк ✅

---

### Task 2.2: Validation Rules [2h]

- [ ] **[60 мин]** Централизация validation
  - [ ] Собрать все validation rules в common
  - [ ] Выделить специфичные правила для компонентов
  - [ ] Создать validation cheat sheet

- [ ] **[60 мин]** Обновление компонентов
  - [ ] tester: ссылаться на common validation
  - [ ] main: ссылаться на common validation
  - [ ] Удалить дубликаты

**Экономия:** -200 строк ✅

---

### Task 2.3: Examples & Patterns [2h]

- [ ] **[60 мин]** Категоризация examples
  - [ ] Общие примеры → в common
  - [ ] Специфичные примеры → в компонентах
  - [ ] Создать examples index

- [ ] **[60 мин]** Consolidation
  - [ ] Убрать partial duplicates
  - [ ] Добавить cross-references
  - [ ] Проверить полноту покрытия

**Экономия:** -150 строк ✅

---

## 🏗️ Phase 3: Structure (10 часов)

### Task 3.1: Progressive Context Loading [4h]

- [ ] **[90 мин]** Определить уровни контекста
  ```
  Level 1 (always): SKILL.md + quick-reference
  Level 2 (on-demand): workflow files
  Level 3 (as-needed): examples, templates
  Level 4 (rare): troubleshooting, advanced
  ```

- [ ] **[90 мин]** Реструктурировать файлы
  - [ ] Создать level-based directories
  - [ ] Переместить файлы по уровням
  - [ ] Добавить loading hints в SKILL.md

- [ ] **[60 мин]** Документация и тестирование
  - [ ] Создать loading strategy guide
  - [ ] Протестировать с разными сценариями
  - [ ] Измерить token savings

**Результат:** 30-50% token savings в simple scenarios ✅

---

### Task 3.2: Reference Hierarchy [3h]

- [ ] **[90 мин]** Создать иерархию
  ```
  reference/
  ├── essential/     (quick-reference, navigation)
  ├── common/        (behavior, validation)
  ├── advanced/      (optimization, troubleshooting)
  └── specialized/   (domain-specific)
  ```

- [ ] **[60 мин]** Стандартизация
  - [ ] Единообразное именование файлов
  - [ ] Consistent structure внутри файлов
  - [ ] Cross-reference format

- [ ] **[30 мин]** Индексация
  - [ ] Master index для каждого уровня
  - [ ] Quick navigation links
  - [ ] Search-friendly organization

**Результат:** Optimal hierarchy ✅

---

### Task 3.3: Split Large Files [3h]

- [ ] **[90 мин]** Идентификация и split
  - [ ] Найти все файлы > 500 строк
  - [ ] Определить logical split points
  - [ ] Разделить с сохранением связности

- [ ] **[60 мин]** Создание индексов
  - [ ] Master index для split files
  - [ ] Part 1 ↔ Part 2 navigation
  - [ ] Quick access to sections

- [ ] **[30 мин]** Проверка качества
  - [ ] Нет broken references
  - [ ] Logical flow maintained
  - [ ] Easy navigation

**Результат:** All files < 500 lines ✅

---

## 🤖 Phase 4: Automation (6 часов)

### Task 4.1: Ecosystem Validator [3h]

- [ ] **[90 мин]** Создать `validate_ecosystem.py`
  ```python
  checks:
  - SKILL.md < 350 lines
  - reference files < 500 lines
  - total size < 5000 lines per skill
  - no Core Behavior Rules duplication
  - version synchronization
  ```

- [ ] **[60 мин]** Интеграция
  - [ ] CI/CD pipeline integration
  - [ ] Pre-commit hooks
  - [ ] GitHub Actions workflow

- [ ] **[30 мин]** Документация
  - [ ] Usage guide
  - [ ] Error messages
  - [ ] Fix suggestions

**Результат:** Automated validation ✅

---

### Task 4.2: Pre-commit Hooks [1h]

- [ ] **[30 мин]** Создать hook script
  ```bash
  #!/bin/bash
  ./scripts/validate_ecosystem.py
  if [ $? -ne 0 ]; then
      echo "❌ Validation failed"
      exit 1
  fi
  ```

- [ ] **[30 мин]** Setup и тестирование
  - [ ] Install в .git/hooks/
  - [ ] Протестировать с valid changes
  - [ ] Протестировать с invalid changes
  - [ ] Документировать bypass process

**Результат:** Pre-commit validation ✅

---

### Task 4.3: Metrics Dashboard [2h]

- [ ] **[60 мин]** Создать metrics collector
  - [ ] Track SKILL.md sizes
  - [ ] Track duplication levels
  - [ ] Track total ecosystem size
  - [ ] Historical data collection

- [ ] **[60 мин]** Visualize metrics
  - [ ] Size trends dashboard
  - [ ] Compliance status
  - [ ] Duplication heatmap
  - [ ] Export to markdown/HTML

**Результат:** Metrics tracking ✅

---

## ✅ Verification Checklist

После завершения всех фаз:

### Compliance Check
- [ ] skill-architect: SKILL.md < 350 lines ✅
- [ ] skill-architect-common: SKILL.md < 350 lines ✅
- [ ] skill-architect-lite: SKILL.md < 350 lines ✅
- [ ] skill-architect-templates: SKILL.md < 350 lines ✅
- [ ] skill-architect-tester: SKILL.md < 350 lines ✅
- [ ] skill-architect-router: SKILL.md < 350 lines ✅

### Metrics Check
- [ ] Total size reduction: ≥40% ✅
- [ ] Duplication reduction: ≥80% ✅
- [ ] Average SKILL.md: <300 lines ✅
- [ ] All reference files: <500 lines ✅

### Quality Check
- [ ] Validator runs без errors ✅
- [ ] Все ссылки работают ✅
- [ ] Documentation полная ✅
- [ ] Backward compatibility ✅

### Automation Check
- [ ] CI/CD integration работает ✅
- [ ] Pre-commit hooks активны ✅
- [ ] Metrics dashboard функционирует ✅

---

## 🎓 Success Criteria

**Phase 1 Complete:**
- ✅ 100% compliance achieved
- ✅ 40% size reduction
- ✅ Quick wins delivered

**Full v2.1 Complete:**
- ✅ 46% total reduction
- ✅ 85% less duplication
- ✅ Automated validation
- ✅ Maintained quality

---

## 📅 Timeline

**Week 1:** Phase 1 (12h)
**Week 2:** Phase 2 (6h)
**Week 3:** Phase 3 (10h)
**Week 4:** Phase 4 (6h) + Release

**Total:** 34 hours over 4 weeks

---

**Начинаем? Отмечай выполненные задачи! ✅**
